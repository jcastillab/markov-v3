# Modelo Markov multifinca, versión 9.0

Proyecto para pronosticar tallos a corte de rosa FREEDOM en ALMER, PRADERA y SANTA HELENA.

La versión 9.0 congela las metodologías validadas para ingresos RC, extrapolación, bloques no muestreados y evaluación del error. Los controles se calculan de forma dinámica. Una actualización de los datos no se considera un error por cambiar el número de conteos, semanas o ventanas evaluables.

## Ejecución

Desde la carpeta raíz:

```powershell
python main.py
```

En Windows:

```text
ejecutar_modelo.bat
```

Salida principal:

```text
salidas/modelo_datos_power_bi_multifinca.xlsx
```

## Validación antes de refrescar Power BI

```powershell
python -m pytest -q
python scripts/validar_proyecto.py
python scripts/auditar_metricas.py
```

El primer comando valida unidades de código. El segundo comprueba invariantes matemáticas y estructurales. El tercero muestra las métricas de la actualización actual por finca y método.

## Unidad oficial de pronóstico

Un pronóstico directo se identifica por:

```text
Finca + Bloque + Fecha_conteo -> lunes a domingo de la semana objetivo
```

`Fact_Semanal` contiene únicamente pronósticos Markov que nacen de un conteo real del bloque. Las estimaciones de bloques no muestreados se almacenan en `Fact_Operacion_Semanal` y quedan fuera de WAPE, MAE y sesgo del modelo Markov.

## Ingreso RC oficial

No se reconstruyen ingresos históricos a partir del corte real.

Para cada conteo:

```text
b = alpha * RC_0
```

Con la configuración predeterminada:

```text
alpha = 0.20
```

`b` se agrega a RC cada día del horizonte. La dinámica es:

```text
C_d = r^T x_d
x_(d+1) = Q x_d + b e_RC
```

El escenario sin ingresos se conserva como sensibilidad. LS3 y los ingresos derivados de residuos no forman parte de la salida oficial.

## Extrapolación de muestra a bloque

Para un bloque muestreado:

```text
y_hat_b = y_hat_muestra_b * N_b / n_b
```

`N_b` es el número de camas activas del bloque y `n_b` es el número de camas muestreadas. Si `n_b > N_b`, el factor se fija en 1 y el evento queda auditado.

## Bloques no muestreados

La tasa oficial de finca se obtiene con los bloques muestreados:

```text
r_hat_f = sum(y_hat_b) / sum(N_b)
```

Para un bloque no muestreado `u`:

```text
y_hat_u = N_u * r_hat_f
```

La proyección total de finca es:

```text
y_hat_f = sum(y_hat_b muestreados) + sum(y_hat_u no muestreados)
```

Esta capa es operacional. No convierte un bloque sin conteo en un pronóstico Markov directo.

## Evaluación del error

Una ventana es evaluable cuando existen los 7 cortes reales de lunes a domingo. Un cero registrado es válido. Un dato vacío se considera faltante.

```text
Error = Proyectado - Real
Error absoluto = abs(Proyectado - Real)
WAPE = sum(Error absoluto) / sum(Real)
Sesgo = sum(Error) / sum(Real)
MAE = promedio(Error absoluto)
Acierto = 1 - WAPE
```

WAPE es la métrica principal. Acierto se conserva como indicador secundario.

## Semana usada en Power BI

En las tablas de proyección, `Semana_ID` representa la semana objetivo que se pronostica. `Semana_conteo_ID` se conserva para auditoría. Esto evita que un mismo segmentador represente semanas distintas entre desempeño y cobertura operacional.

## Documentación

* `METODOLOGIA_FINAL.md`, definición matemática completa.
* `AUDITORIA_FINAL.md`, verificaciones y resultados actuales.
* `POWER_BI_MODELO_FINAL.md`, relaciones, medidas DAX y diseño del tablero.
