"""Muestra las métricas de la actualización actual sin usar valores congelados.

Ejecutar desde la raíz del proyecto:
    python scripts/auditar_metricas.py
"""

from __future__ import annotations

import sys
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from modelo_markov import ConfiguracionModelo, ejecutar_modelo  # noqa: E402


def configuracion() -> ConfiguracionModelo:
    return ConfiguracionModelo(
        ruta_fenologia_abril=RAIZ / "datos/FENOLOGIAS ABRIL FREEDOM.xlsx",
        ruta_fenologia_julio=RAIZ / "datos/FENOLOGIAS JULIO FREEDOM.xlsx",
        ruta_conteos=RAIZ / "datos/conteos_vs_cortes_multifinca.xlsx",
        ruta_camas_muestreadas=RAIZ / "datos/camas_muestreadas_semana.xlsx",
        ruta_plano_siembra=RAIZ / "datos/plano_siembra.xlsx",
        ruta_calendario=RAIZ / "datos/calendario.xlsx",
        ruta_salida=RAIZ / "salidas/modelo_datos_power_bi_multifinca.xlsx",
    )


def pct(valor: float) -> str:
    return "NA" if valor != valor else f"{valor:.2%}"


def main() -> int:
    resultado = ejecutar_modelo(configuracion())
    tablas = resultado.tablas_power_bi
    semanal = tablas["Fact_Semanal"]
    causal = tablas["Fact_Backtest_Causal"]
    ingresos = tablas["Control_Ingresos"]
    imputacion = tablas["Control_Imputacion"]
    cobertura = tablas["Fact_Cobertura_Finca"]
    calidad = tablas["Control_Calidad"]

    print("AUDITORIA_METRICAS_ACTUAL")
    print(f"Ejecución: {resultado.ejecucion_id}")
    print(f"Pronósticos directos: {len(semanal)}")
    print(f"Ventanas evaluables: {int(semanal['Ventana_evaluable'].sum())}")
    print(f"Backtest causal evaluable: {int(causal['Ventana_evaluable'].sum())}")
    print(f"Semanas, finca de cobertura: {len(cobertura)}")
    print()

    print("DESEMPEÑO DIRECTO POR FINCA")
    evaluables = semanal.loc[semanal["Ventana_evaluable"]].copy()
    for finca, datos in evaluables.groupby("Finca", sort=True):
        real = float(datos["Corte_real_bloque"].sum())
        error = datos["Corte_proyectado_bloque"] - datos["Corte_real_bloque"]
        wape = float(error.abs().sum() / real) if real else float("nan")
        bias = float(error.sum() / real) if real else float("nan")
        mae = float(error.abs().mean())
        print(
            f"{finca}: n={len(datos)}, WAPE={pct(wape)}, "
            f"sesgo={pct(bias)}, MAE={mae:,.0f} tallos"
        )
    print()

    print("SENSIBILIDAD DE INGRESOS")
    for fila in ingresos.loc[ingresos["Alcance"].eq("TOTAL")].itertuples(index=False):
        print(
            f"{fila.Escenario_ingreso}: n={fila.N_ventanas_evaluables}, "
            f"WAPE={pct(fila.WAPE)}, sesgo={pct(fila.Sesgo_pct)}, "
            f"MAE={fila.MAE_tallos:,.0f} tallos"
        )
    print()

    print("IMPUTACIÓN DE BLOQUES NO MUESTREADOS")
    for fila in imputacion.loc[imputacion["Alcance"].eq("TOTAL")].itertuples(index=False):
        marca = "OFICIAL" if fila.Uso_oficial else "SENSIBILIDAD"
        print(
            f"{marca} | {fila.Metodo_imputacion}: "
            f"n={fila.N_bloques_semana_evaluables}, WAPE={pct(fila.WAPE)}"
        )
    print()

    controles_error = calidad.loc[calidad["Estado"].eq("ERROR")]
    if controles_error.empty:
        print("Control_Calidad: sin errores")
    else:
        print("Control_Calidad: ERROR")
        print(controles_error[["Categoria", "Metrica", "Valor", "Detalle"]].to_string(index=False))
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
