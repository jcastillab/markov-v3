"""Validación integral del proyecto antes de refrescar Power BI.

Ejecutar desde la raíz del proyecto:
    python scripts/validar_proyecto.py

El validador no compara contra conteos históricos congelados. Comprueba
invariantes matemáticas y estructurales para que una actualización de los
archivos de entrada no convierta cambios legítimos de datos en falsos errores.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))

from modelo_markov import ConfiguracionModelo, ejecutar_modelo  # noqa: E402


def config_predeterminada() -> ConfiguracionModelo:
    return ConfiguracionModelo(
        ruta_fenologia_abril=RAIZ / "datos/FENOLOGIAS ABRIL FREEDOM.xlsx",
        ruta_fenologia_julio=RAIZ / "datos/FENOLOGIAS JULIO FREEDOM.xlsx",
        ruta_conteos=RAIZ / "datos/conteos_vs_cortes_multifinca.xlsx",
        ruta_camas_muestreadas=RAIZ / "datos/camas_muestreadas_semana.xlsx",
        ruta_plano_siembra=RAIZ / "datos/plano_siembra.xlsx",
        ruta_calendario=RAIZ / "datos/calendario.xlsx",
        ruta_salida=RAIZ / "salidas/modelo_datos_power_bi_multifinca.xlsx",
    )


def exigir(condicion: bool, mensaje: str) -> None:
    if not condicion:
        raise AssertionError(mensaje)


def main() -> int:
    config = config_predeterminada()
    resultado = ejecutar_modelo(config)
    tablas = resultado.tablas_power_bi

    requeridas = {
        "Fact_Diaria", "Fact_Semanal", "Fact_Backtest_Causal",
        "Fact_Operacion_Diaria", "Fact_Operacion_Semanal",
        "Fact_Extrapolacion", "Fact_Cobertura_Finca",
        "Fact_Sensibilidad_Ingresos", "Control_Ingresos",
        "Control_Imputacion", "Control_Calidad", "Control_Matrices",
        "Dim_Fecha", "Dim_Semana", "Dim_Finca", "Dim_Bloque",
        "Dim_Periodo", "Dim_Modelo", "Matriz_Q", "Vectores_r_p",
        "Potencias_Q", "Relaciones",
    }
    faltantes = sorted(requeridas - set(tablas))
    exigir(not faltantes, f"Faltan tablas Power BI: {faltantes}")

    semanal = tablas["Fact_Semanal"]
    operacional = tablas["Fact_Operacion_Semanal"]
    causal = tablas["Fact_Backtest_Causal"]
    calidad = tablas["Control_Calidad"]
    matrices = tablas["Control_Matrices"]
    vectores = tablas["Vectores_r_p"]
    insumos = tablas["Control_Insumos"]
    ingresos = tablas["Control_Ingresos"]
    imputacion = tablas["Control_Imputacion"]
    cobertura = tablas["Fact_Cobertura_Finca"]
    extrapolacion = tablas["Fact_Extrapolacion"]

    seleccionados = int(resultado.auditoria_conteos_df["Conteo_seleccionado"].sum())
    exigir(len(semanal) == seleccionados,
           "Fact_Semanal debe tener una fila por conteo seleccionado")
    exigir(semanal["Pronostico_markov_directo"].all(),
           "Fact_Semanal contiene imputaciones")
    exigir(semanal["Dias_proyectados"].eq(7).all(),
           "Existe un pronóstico directo con horizonte distinto de 7 días")
    exigir((semanal.loc[semanal["Ventana_evaluable"], "Dias_con_corte_real"] == 7).all(),
           "Una ventana evaluable no tiene los 7 cortes reales")
    exigir(semanal.loc[~semanal["Ventana_evaluable"], "Corte_real_bloque"].isna().all(),
           "Una ventana no evaluable expone corte real semanal como evaluable")

    # Ingreso oficial fijo: b = alpha * RC_0 por día.
    exigir(semanal["Metodo_pronostico_ingreso"].eq("FIJO_PORCENTAJE_RC_CONTEO").all(),
           "Existe un pronóstico que no usa ingreso fijo")
    con_rc = semanal["Conteo_RC"].ne(0)
    exigir(np.allclose(
        semanal.loc[con_rc, "Ingreso_pronosticado_pct_RC_dia"].astype(float),
        config.porcentaje_ingreso_inicial,
        atol=1e-12,
    ), "El ingreso diario no coincide con el porcentaje fijo de RC")

    # Separación entre evaluación Markov e imputación operacional.
    directos_operacion = operacional.loc[operacional["Bloque_muestreado"]]
    exigir(len(directos_operacion) == len(semanal),
           "La capa operacional no conserva todos los pronósticos directos")
    imp = operacional.loc[~operacional["Bloque_muestreado"]]
    exigir(not imp["Semana_conteo_ID"].isna().any(),
           "Hay imputaciones sin Semana_conteo_ID")
    exigir(
        imp["Metodo_estimacion_bloque"].eq("TASA_PONDERADA_CAMAS_FINCA").all(),
        "Existe una imputación que no usa la tasa ponderada por camas",
    )

    # Coherencia temporal de las dimensiones del tablero. Semana_ID representa
    # siempre la semana objetivo del pronóstico en las tablas de proyección.
    if not cobertura.empty:
        semana_cobertura = cobertura["Fecha_inicio_proyeccion"].map(
            lambda x: int(pd.Timestamp(x).isocalendar().year * 100 + pd.Timestamp(x).isocalendar().week)
        )
        exigir(semana_cobertura.eq(cobertura["Semana_ID"].astype(int)).all(),
               "Fact_Cobertura_Finca no está alineada con la semana objetivo")
    if not extrapolacion.empty:
        exigir(
            extrapolacion["Semana_ID"].astype(int).eq(extrapolacion["Semana_objetivo_ID"].astype(int)).all(),
            "Fact_Extrapolacion usa una Semana_ID distinta de la semana objetivo",
        )

    # Fórmula finca validada: sum(y_hat_b) / sum(N_b).
    if not cobertura.empty:
        tasa_calc = (
            cobertura["Corte_proyectado_bloques_muestreados_semana"].astype(float)
            / cobertura["Camas_activas_bloques_muestreados"].astype(float)
        )
        exigir(np.allclose(
            tasa_calc,
            cobertura["Tasa_corte_proyectado_semanal_por_cama"].astype(float),
            atol=1e-10,
        ), "La tasa de finca no coincide con sum(proyección)/sum(camas)")
        no_m_calc = (
            cobertura["Tasa_corte_proyectado_semanal_por_cama"].astype(float)
            * cobertura["Camas_activas_bloques_no_muestreados"].astype(float)
        )
        exigir(np.allclose(
            no_m_calc,
            cobertura["Corte_proyectado_bloques_no_muestreados_semana"].astype(float),
            atol=1e-8,
        ), "La proyección de bloques no muestreados no coincide con la tasa de finca")
        finca_calc = (
            cobertura["Corte_proyectado_bloques_muestreados_semana"].astype(float)
            + cobertura["Corte_proyectado_bloques_no_muestreados_semana"].astype(float)
        )
        exigir(np.allclose(
            finca_calc,
            cobertura["Corte_proyectado_finca_semana"].astype(float),
            atol=1e-8,
        ), "La proyección total de finca no cierra")

    # Matrices y causalidad.
    exigir(matrices["Converge_Q"].all(), "Existe una matriz Q que no converge")
    exigir((matrices["Probabilidad_minima"] >= -1e-12).all(),
           "Existe probabilidad negativa")
    exigir((matrices["Desviacion_max_suma_columna"] <= 1e-10).all(),
           "Q+r+p no suma 1")
    exigir(vectores["Control_suma_uno"].all(),
           "Alguna columna de Q+r+p no suma 1")
    exigir(len(causal) <= len(semanal),
           "El backtest causal no puede tener más pronósticos que el retrospectivo")

    # Controles generales.
    errores = calidad.loc[calidad["Estado"].eq("ERROR")]
    exigir(errores.empty, f"Control_Calidad contiene errores: {errores.to_dict('records')}")
    errores_insumo = insumos.loc[insumos["Estado"].eq("ERROR")]
    exigir(errores_insumo.empty,
           f"Control_Insumos contiene errores: {errores_insumo.to_dict('records')}")

    escenarios = set(ingresos["Escenario_ingreso"].dropna())
    exigir(escenarios == {"SIN_INGRESOS", "INGRESO_FIJO_PCT_RC"},
           f"Escenarios de ingreso inesperados: {sorted(escenarios)}")
    if not imputacion.empty:
        oficiales = imputacion.loc[imputacion["Uso_oficial"]]
        exigir(oficiales["Metodo_imputacion"].eq("PONDERADA_POR_CAMAS_OFICIAL").all(),
               "Control_Imputacion marca un método oficial incorrecto")

    ev = semanal.loc[semanal["Ventana_evaluable"]]
    den = float(ev["Corte_real_bloque"].abs().sum())
    err = ev["Corte_proyectado_bloque"] - ev["Corte_real_bloque"]
    wape = float(err.abs().sum() / den) if den else float("nan")
    sesgo = float(err.sum() / den) if den else float("nan")

    print("VALIDACION_OK")
    print(f"Tablas Power BI: {len(tablas)}")
    print(f"Pronósticos directos: {len(semanal)}")
    print(f"Ventanas evaluables: {int(semanal['Ventana_evaluable'].sum())}")
    print(f"Backtest causal evaluable: {int(causal['Ventana_evaluable'].sum())}")
    print(f"Bloques-semana imputados: {len(imp)}")
    print(f"WAPE ingreso fijo: {wape:.2%}")
    print(f"Sesgo ingreso fijo: {sesgo:.2%}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
