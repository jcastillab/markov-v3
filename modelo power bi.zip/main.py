"""Punto de entrada del modelo Markov multifinca, metodología 3."""

import argparse
from pathlib import Path

from modelo_markov import ConfiguracionModelo, ejecutar_y_guardar


def construir_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Proyecta conteos y cortes de tres fincas para Power BI.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--fenologia-abril",
        default="datos/FENOLOGIAS ABRIL FREEDOM.xlsx",
        help="Excel de fenología para conteos hasta junio.",
    )
    parser.add_argument(
        "--fenologia-julio",
        default="datos/FENOLOGIAS JULIO FREEDOM.xlsx",
        help="Excel de fenología para conteos desde julio.",
    )
    parser.add_argument(
        "--conteos", default="datos/conteos_vs_cortes_multifinca.xlsx",
        help="Excel de conteos y cortes diarios."
    )
    parser.add_argument(
        "--camas-muestreadas",
        default="datos/camas_muestreadas_semana.xlsx",
        help="Excel de camas observadas por finca, bloque y semana.",
    )
    parser.add_argument(
        "--plano-siembra",
        default="datos/plano_siembra.xlsx",
        help="Excel con las camas y sus fechas de vigencia.",
    )
    parser.add_argument(
        "--calendario", default="datos/calendario.xlsx",
        help="Excel de calendario diario."
    )
    parser.add_argument("--hoja-fenologia-abril", default="Abril")
    parser.add_argument("--hoja-fenologia-julio", default="JULIO")
    parser.add_argument(
        "--fecha-cambio-matriz",
        default="2026-07-01",
        help="Primer día de conteo que usa las matrices de julio.",
    )
    parser.add_argument(
        "--fincas",
        default="ALMER,PRADERA,SANTA HELENA",
        help="Fincas separadas por coma.",
    )
    parser.add_argument("--flor", default="ROSE")
    parser.add_argument("--variedad", default="FREEDOM")
    parser.add_argument("--horizonte-matriz", type=int, default=20)
    parser.add_argument(
        "--ventana-ingresos-semanas",
        type=int,
        default=4,
        help="Compatibilidad con versiones anteriores. No interviene en el ingreso fijo oficial.",
    )
    parser.add_argument(
        "--porcentaje-ingreso-inicial",
        type=float,
        default=20.0,
        help="Porcentaje fijo del RC del conteo que ingresa a RC cada día del horizonte.",
    )
    parser.add_argument(
        "--salida",
        default="salidas/modelo_datos_power_bi_multifinca.xlsx",
        help="Único Excel generado por el proyecto.",
    )
    return parser


def main() -> int:
    args = construir_parser().parse_args()
    fincas = tuple(x.strip() for x in args.fincas.split(",") if x.strip())
    config = ConfiguracionModelo(
        ruta_fenologia_abril=Path(args.fenologia_abril),
        ruta_fenologia_julio=Path(args.fenologia_julio),
        ruta_conteos=Path(args.conteos),
        ruta_camas_muestreadas=Path(args.camas_muestreadas),
        ruta_plano_siembra=Path(args.plano_siembra),
        ruta_calendario=Path(args.calendario),
        ruta_salida=Path(args.salida),
        hoja_fenologia_abril=args.hoja_fenologia_abril,
        hoja_fenologia_julio=args.hoja_fenologia_julio,
        fecha_cambio_matriz=args.fecha_cambio_matriz,
        fincas=fincas,
        flor=args.flor,
        variedad=args.variedad,
        horizonte_matriz=args.horizonte_matriz,
        ventana_ingresos_semanas=args.ventana_ingresos_semanas,
        porcentaje_ingreso_inicial=args.porcentaje_ingreso_inicial / 100.0,
    )
    resultado = ejecutar_y_guardar(config)
    semanal = resultado.resumen_semanal_df
    print(f"Ejecución ID: {resultado.ejecucion_id}")
    print(f"Matrices por finca y periodo: {len(resultado.matrices_por_modelo)}")
    print("Método matriz: M3_EXPOSICIONES_GRUPO")
    print(
        "Ingreso oficial: FIJO_PORCENTAJE_RC_CONTEO "
        f"({config.porcentaje_ingreso_inicial:.2%} de RC por día)"
    )
    print("Extrapolación finca: TASA_PONDERADA_CAMAS_BLOQUES_MUESTREADOS")
    print(f"Conteos recibidos: {len(resultado.auditoria_conteos_df)}")
    print(
        "Conteos seleccionados: "
        f"{int(resultado.auditoria_conteos_df['Conteo_seleccionado'].sum())}"
    )
    print(f"Filas diarias: {len(resultado.resultados_diarios_df)}")
    imputados = int(resultado.cobertura_finca_df["N_bloques_no_muestreados"].sum())
    print(f"Bloques-semana imputados operacionales: {imputados}")
    print(f"Semanas-finca auditadas: {len(resultado.cobertura_finca_df)}")
    print(f"Bloques-semana proyectados: {len(semanal)}")
    print(f"Bloques-semana evaluables: {int(semanal['Ventana_evaluable'].sum())}")
    print(
        "Semanas calendario objetivo distintas: "
        f"{int(semanal['Semana_ID'].nunique())}"
    )
    print(
        "Factores fijados en 1: "
        f"{int(resultado.extrapolacion_df['Factor_ajustado'].sum())}"
    )
    control_causal = resultado.tablas_power_bi.get("Control_Causalidad")
    if control_causal is not None and not control_causal.empty:
        for fila in control_causal.itertuples(index=False):
            print(
                f"Backtest {fila.Escenario_backtest}: "
                f"n={fila.N_evaluables}, WAPE={fila.WAPE:.2%}, "
                f"sesgo={fila.Sesgo_pct:.2%}"
            )
    control_ingresos = resultado.tablas_power_bi.get("Control_Ingresos")
    if control_ingresos is not None and not control_ingresos.empty:
        total = control_ingresos.loc[control_ingresos["Alcance"].eq("TOTAL")]
        for fila in total.itertuples(index=False):
            print(
                f"Ingreso {fila.Escenario_ingreso}: "
                f"WAPE={fila.WAPE:.2%}, sesgo={fila.Sesgo_pct:.2%}"
            )
    print(f"Hojas generadas: {len(resultado.tablas_power_bi)}")
    print(f"Archivo: {config.ruta_salida.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
