# Auditoría de la versión 9.0

Fecha de auditoría: 2026-08-13.

## Metodologías verificadas

Se revisó el pipeline completo y se corrigieron cuatro puntos que afectaban la interpretación del tablero.

1. El ingreso oficial quedó fijado como `alpha * RC_0` por día. La configuración predeterminada usa `alpha = 20 %`. La reconstrucción histórica, LS3 y los residuos de corte dejaron de alimentar el pronóstico oficial.
2. La extrapolación de bloques no muestreados dejó de usar la media simple de tasas. La tasa oficial es `sum(proyección de bloques muestreados) / sum(camas activas de bloques muestreados)`.
3. Las imputaciones operacionales permanecen separadas de `Fact_Semanal`. WAPE, MAE y sesgo del Markov se calculan con pronósticos directos.
4. `Semana_ID` de las tablas de proyección representa la semana objetivo. `Semana_conteo_ID` conserva la semana del conteo.

## Validaciones automáticas

El archivo `scripts/validar_proyecto.py` ya no compara la actualización contra cantidades históricas fijas. Verifica invariantes.

Comprueba:

* una fila semanal por conteo seleccionado;
* horizonte de siete días;
* siete cortes reales para cada ventana evaluable;
* ingreso fijo coherente con el porcentaje configurado;
* separación entre pronóstico directo e imputación;
* tasa ponderada por camas y cierre de la proyección total de finca;
* coherencia de semana objetivo;
* convergencia de Q;
* ausencia de probabilidades negativas;
* suma `Q + r + p = 1` por columna;
* controles de insumos sin estado ERROR.

## Resultado de la actualización incluida

La ejecución actual entrega:

```text
Conteos recibidos: 447
Pronósticos directos: 445
Ventanas directas evaluables: 363
Bloques, semana imputados: 221
Backtest causal evaluable: 332
Matrices: 6
```

Desempeño retrospectivo con ingreso fijo del 20 %:

```text
WAPE: 32.72 %
Sesgo: +1.65 %
```

Desempeño causal:

```text
WAPE: 33.19 %
Sesgo: -0.21 %
```

Sensibilidad de ingresos:

```text
Ingreso fijo 20 %: WAPE 32.72 %, sesgo +1.65 %
Sin ingresos:       WAPE 38.14 %, sesgo -28.45 %
```

El escenario con ingreso fijo reduce el WAPE respecto al escenario sin ingresos. Esto no convierte el 20 % en un parámetro estimado estadísticamente. Sigue siendo un supuesto fijo del modelo.

## Desempeño directo por finca

```text
ALMER
N evaluables: 58
WAPE: 37.04 %
Sesgo: -30.85 %
MAE: 4,339 tallos

PRADERA
N evaluables: 267
WAPE: 31.91 %
Sesgo: +7.47 %
MAE: 5,227 tallos

SANTA HELENA
N evaluables: 38
WAPE: 33.78 %
Sesgo: -4.10 %
MAE: 5,160 tallos
```

## Auditoría de la imputación de bloques no muestreados

En las ventanas donde existe corte real completo para bloques imputados:

```text
Método oficial ponderado por camas: WAPE 35.11 %
Media simple, sensibilidad:         WAPE 34.21 %
Mediana, sensibilidad:              WAPE 31.85 %
```

La metodología ponderada se mantiene como oficial porque corresponde a la definición operacional validada: los bloques observados representan una producción agregada por cama de la finca. Las otras dos alternativas permanecen visibles para sensibilidad.

## Controles que deben revisarse después de cada actualización

Ejecutar:

```powershell
python -m pytest -q
python scripts/validar_proyecto.py
python scripts/auditar_metricas.py
```

La actualización es apta para Power BI cuando `validar_proyecto.py` termina con `VALIDACION_OK`. Los valores de WAPE, sesgo, conteos y ventanas pueden cambiar con los nuevos datos. Ese cambio no constituye por sí mismo una falla del pipeline.
