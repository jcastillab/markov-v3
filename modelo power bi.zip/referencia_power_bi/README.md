# PBIX de referencia

`tablero_control_modelo_markov_estructura_referencia.pbix` es el PBIX entregado por el usuario. Se conserva sin modificar para tomar como referencia la disposición de páginas, visuales, tarjetas y segmentadores.

Las definiciones correctas de métricas, relaciones y visuales para reconstruir el tablero están en `../POWER_BI_MODELO_FINAL.md`.
