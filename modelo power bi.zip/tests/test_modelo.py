import unittest

import numpy as np
import pandas as pd

from modelo_markov.entradas import (
    auditar_conteos_semanales,
    construir_extrapolacion,
    normalizar_estado,
    normalizar_finca,
    preparar_camas_muestreadas,
    preparar_fenologia,
)
from modelo_markov.metodologia import construir_potencias_q, estimar_metodologia_3
from modelo_markov.modelos import MatricesTransicion
from modelo_markov.proyeccion import completar_bloques_no_muestreados, generar_resultados_diarios
from modelo_markov.vigencias import asignar_modelo_a_conteos, periodo_modelo


def datos_conteos_base(fechas, cantidades, conteos):
    filas = []
    for fecha, cantidad in zip(fechas, cantidades):
        fila = {
            "Finca": "SANTA HELENA",
            "Bloque": "3",
            "Fecha": pd.Timestamp(fecha),
            "Cantidad": cantidad,
            "conteo_RC": np.nan,
            "conteo_SS": np.nan,
            "conteo_AP": np.nan,
            "conteo_CO": np.nan,
        }
        if pd.Timestamp(fecha) in conteos:
            valores = conteos[pd.Timestamp(fecha)]
            fila.update(
                {
                    "conteo_RC": valores[0],
                    "conteo_SS": valores[1],
                    "conteo_AP": valores[2],
                    "conteo_CO": 0.0,
                }
            )
        filas.append(fila)
    datos = pd.DataFrame(filas)
    datos["Semana_ID"] = datos["Fecha"].map(
        lambda x: int(x.isocalendar().year) * 100 + int(x.isocalendar().week)
    )
    return datos


class PruebasModeloMultifinca(unittest.TestCase):
    def test_normaliza_fincas_y_estados(self):
        self.assertEqual(normalizar_finca("LA PRADERA"), "PRADERA")
        self.assertEqual(normalizar_finca("SANTA HELENA BL 7"), "SANTA HELENA")
        self.assertEqual(normalizar_estado("RC4"), "RC")
        self.assertEqual(normalizar_estado("R4C"), "RC")
        self.assertEqual(normalizar_estado("S3S"), "SS")
        self.assertEqual(normalizar_estado("SP2"), "AP")

    def test_matriz_ponderada_suma_uno(self):
        datos = pd.DataFrame(
            {
                "FECHA": pd.date_range("2026-04-01", periods=5),
                "T1": ["RC", "RC", "SS", "AP", "PC"],
                "T2": ["RC", "SS", "SS", "AP", "PC"],
            }
        )
        estimacion = estimar_metodologia_3(datos, "FECHA", ["T1", "T2"])
        sumas = (
            estimacion.matrices.Q.sum(axis=0)
            + estimacion.matrices.r.ravel()
            + estimacion.matrices.p.ravel()
        )
        self.assertTrue(np.allclose(sumas, np.ones(3)))

    def test_probabilidad_grupo_se_estima_por_exposiciones(self):
        datos = pd.DataFrame(
            {
                "FECHA": pd.date_range("2026-04-01", periods=5),
                "T1": ["RC", "RC", "SS", "AP", "PC"],
                "T2": ["RC", "SS", "SS", "AP", "PC"],
            }
        )
        estimacion = estimar_metodologia_3(datos, "FECHA", ["T1", "T2"])
        detalle = estimacion.probabilidades_df
        rc = detalle.loc[detalle["Estado"].eq("RC")].iloc[0]
        self.assertEqual(int(rc["Exposiciones_dia"]), 3)
        self.assertEqual(int(rc["Transiciones_permanecer"]), 1)
        self.assertEqual(int(rc["Transiciones_avanzar"]), 2)
        self.assertAlmostEqual(float(rc["P_mantener_final"]), 1 / 3)
        self.assertAlmostEqual(float(rc["P_avanzar_final"]), 2 / 3)

    def test_potencias_llegan_a_20(self):
        potencias = construir_potencias_q(np.diag([0.8, 0.7, 0.6]), 20)
        self.assertEqual(len(potencias), 180)
        self.assertEqual(potencias["Exponente_Q"].max(), 20)

    def test_vigencia_se_define_por_fecha_del_conteo(self):
        cambio = pd.Timestamp("2026-07-01")
        self.assertEqual(periodo_modelo("2026-06-30", cambio), "ABRIL")
        self.assertEqual(periodo_modelo("2026-07-01", cambio), "JULIO")

    def test_fenologia_no_mezcla_tallos_repetidos_entre_cohortes(self):
        datos = pd.DataFrame(
            {
                "FINCA": ["ALMER BL 1"] * 3 + ["ALMER BL 2"] * 3,
                "FECHA": list(pd.date_range("2026-04-01", periods=3)) * 2,
                "1": ["RC1", "SS1", "PC", "RC1", "SS1", "PC"],
            }
        )
        _, _, tallos, _ = preparar_fenologia(datos, "ALMER")
        self.assertEqual(len(tallos), 2)
        self.assertEqual(len(set(tallos)), 2)

    def test_conserva_ultimo_conteo_de_la_semana(self):
        fechas = pd.to_datetime(["2026-07-06", "2026-07-08"])
        datos = datos_conteos_base(
            fechas,
            [100, 100],
            {fecha: (10, 20, 30) for fecha in fechas},
        )
        auditoria = auditar_conteos_semanales(datos)
        auditoria = asignar_modelo_a_conteos(
            auditoria, pd.Timestamp("2026-07-01")
        )
        self.assertEqual(int(auditoria["Conteo_seleccionado"].sum()), 1)
        seleccion = auditoria.loc[auditoria["Conteo_seleccionado"]].iloc[0]
        self.assertEqual(seleccion["Fecha"], pd.Timestamp("2026-07-08"))

    def test_descarta_fila_resultados_de_camas(self):
        camas = pd.DataFrame(
            {
                "Semana": ["Resultados", "S29"],
                "Finca": ["S21", "Santa Helena"],
                "Bloque": ["El Cerezo", 3],
                "Cantidad_csv": [16, 146],
            }
        )
        resultado = preparar_camas_muestreadas(
            camas, 2026, ("SANTA HELENA",)
        )
        self.assertEqual(len(resultado), 1)
        self.assertEqual(resultado.iloc[0]["Camas_muestreadas"], 146)

    def test_factor_se_fija_en_uno_si_muestra_supera_activas(self):
        fecha = pd.Timestamp("2026-07-13")
        datos = datos_conteos_base(
            [fecha], [100], {fecha: (10, 20, 30)}
        )
        auditoria = auditar_conteos_semanales(datos)
        camas = pd.DataFrame(
            {
                "Finca": ["SANTA HELENA"],
                "Bloque": ["3"],
                "Semana_ID": [202629],
                "Semana_numero": [29],
                "Camas_muestreadas": [146.0],
                "Finca_original": ["Santa Helena"],
                "Semana_original": ["S29"],
            }
        )
        plano = pd.DataFrame(
            {
                "Finca": ["SANTA HELENA"] * 142,
                "Bloque": ["3"] * 142,
                "Cama": [str(i) for i in range(142)],
                "Fecha_siembra": [pd.Timestamp("2020-01-01")] * 142,
                "Fecha_erradicacion": [pd.Timestamp("2030-01-01")] * 142,
            }
        )
        resultado = construir_extrapolacion(auditoria, camas, plano)
        self.assertEqual(resultado.iloc[0]["Factor_extrapolacion"], 1.0)
        self.assertTrue(resultado.iloc[0]["Factor_ajustado"])

    def test_ingreso_fijo_es_porcentaje_del_rc_del_conteo(self):
        fecha_conteo = pd.Timestamp("2026-07-06")
        fechas = pd.date_range("2026-07-06", "2026-07-19")
        datos = datos_conteos_base(
            fechas,
            [100.0] * len(fechas),
            {fecha_conteo: (10.0, 20.0, 30.0)},
        )
        auditoria = asignar_modelo_a_conteos(
            auditar_conteos_semanales(datos), pd.Timestamp("2026-07-01")
        )
        extrapolacion = pd.DataFrame(
            {
                "Conteo_ID": auditoria["Conteo_ID"],
                "Finca": auditoria["Finca"],
                "Bloque": auditoria["Bloque"],
                "Fecha_conteo": auditoria["Fecha"],
                "Semana_ID": auditoria["Semana_ID"],
                "Camas_totales_activas": [40],
                "Camas_muestreadas": [5],
                "Factor_extrapolacion_teorico": [8.0],
                "Factor_extrapolacion": [8.0],
                "Factor_ajustado": [False],
                "Motivo_factor": ["SIN_AJUSTE"],
            }
        )
        matrices = MatricesTransicion(
            Q=np.diag([0.5, 0.5, 0.5]),
            r=np.array([[0.5], [0.5], [0.5]]),
            p=np.zeros((3, 1)),
        )
        resultado = generar_resultados_diarios(
            datos, auditoria, extrapolacion,
            {"JULIO|SANTA HELENA": matrices},
            porcentaje_ingreso_inicial=0.20,
        )
        self.assertTrue(np.allclose(resultado["Ingreso_RC_pronosticado_muestra"], 2.0))
        self.assertTrue(np.allclose(resultado["Ingreso_RC_pronosticado_por_cama"], 0.4))
        self.assertTrue(
            resultado["Metodo_pronostico_ingreso"].eq(
                "FIJO_PORCENTAJE_RC_CONTEO"
            ).all()
        )

    def test_imputa_bloque_no_muestreado_con_tasa_ponderada_por_camas(self):
        fechas = pd.date_range("2026-07-13", periods=7)
        filas = []
        for fecha in fechas:
            for bloque, camas, corte in (("5", 10.0, 40.0), ("3", 20.0, 50.0)):
                filas.append(
                    {
                        "Conteo_ID": f"C|{bloque}",
                        "Modelo_clave": "JULIO|SANTA HELENA",
                        "Periodo_modelo": "JULIO",
                        "Finca": "SANTA HELENA",
                        "Bloque": bloque,
                        "Fecha_conteo": pd.Timestamp("2026-07-08"),
                        "Fecha": fecha,
                        "Camas_totales_activas": camas,
                        "Bloque_muestreado": True,
                        "Tipo_proyeccion": "BLOQUE_MUESTREADO",
                        "Metodo_estimacion_bloque": "MARKOV_MUESTRA_X_FACTOR_CAMAS",
                        "Ingreso_RC_pronosticado_bloque": 0.0,
                        "Conteo_RC_proyectado_bloque": 0.0,
                        "Conteo_SS_proyectado_bloque": 0.0,
                        "Conteo_AP_proyectado_bloque": 0.0,
                        "Conteo_total_proyectado_bloque": 0.0,
                        "Corte_proyectado_sin_ingresos_bloque": corte,
                        "Corte_proyectado_bloque": corte,
                        "Aporte_ingresos_corte_bloque": 0.0,
                        "Perdida_proyectada_bloque": 0.0,
                    }
                )
        resultados = pd.DataFrame(filas)
        datos_reales = pd.DataFrame(
            [
                {
                    "Finca": "SANTA HELENA",
                    "Bloque": "4",
                    "Fecha": fecha,
                    "Cantidad": 33.0,
                    "conteo_RC": np.nan,
                    "conteo_SS": np.nan,
                    "conteo_AP": np.nan,
                    "conteo_CO": np.nan,
                }
                for fecha in fechas
            ]
        )
        plano = pd.DataFrame(
            [
                {
                    "Finca": "SANTA HELENA",
                    "Bloque": bloque,
                    "Cama": str(i),
                    "Fecha_siembra": pd.Timestamp("2020-01-01"),
                    "Fecha_erradicacion": pd.Timestamp("2030-01-01"),
                }
                for bloque, n in (("5", 10), ("3", 20), ("4", 11))
                for i in range(n)
            ]
        )
        completos, cobertura = completar_bloques_no_muestreados(
            resultados, datos_reales, plano
        )
        imputado = completos.loc[
            completos["Tipo_proyeccion"].eq("BLOQUE_NO_MUESTREADO_IMPUTADO")
        ]
        self.assertEqual(len(imputado), 7)
        self.assertTrue(imputado["Metodo_estimacion_bloque"].eq("TASA_PONDERADA_CAMAS_FINCA").all())
        self.assertTrue(np.allclose(imputado["Corte_proyectado_bloque"], 33.0))
        self.assertTrue(imputado["Ventana_evaluable"].all())
        self.assertTrue(np.allclose(imputado["Error_tallos"], 0.0))
        self.assertEqual(int(cobertura.iloc[0]["N_bloques_no_muestreados"]), 1)
        self.assertAlmostEqual(
            float(cobertura.iloc[0]["Tasa_corte_proyectado_semanal_por_cama"]),
            21.0,
        )
        self.assertAlmostEqual(
            float(cobertura.iloc[0]["Corte_proyectado_bloques_no_muestreados_semana"]),
            231.0,
        )


    def test_corte_faltante_excluye_toda_la_ventana(self):
        fecha_conteo = pd.Timestamp("2026-07-06")
        fechas = pd.date_range("2026-07-06", "2026-07-19")
        cantidades = [100.0] * len(fechas)
        datos = datos_conteos_base(
            fechas,
            cantidades,
            {fecha_conteo: (10, 20, 30)},
        )
        datos = datos.loc[datos["Fecha"].ne(pd.Timestamp("2026-07-15"))]
        auditoria = auditar_conteos_semanales(datos)
        auditoria = asignar_modelo_a_conteos(
            auditoria, pd.Timestamp("2026-07-01")
        )
        extrapolacion = pd.DataFrame(
            {
                "Conteo_ID": auditoria["Conteo_ID"],
                "Finca": auditoria["Finca"],
                "Bloque": auditoria["Bloque"],
                "Fecha_conteo": auditoria["Fecha"],
                "Semana_ID": auditoria["Semana_ID"],
                "Camas_totales_activas": [40],
                "Camas_muestreadas": [5],
                "Factor_extrapolacion_teorico": [8],
                "Factor_extrapolacion": [8],
                "Factor_ajustado": [False],
                "Motivo_factor": ["SIN_AJUSTE"],
                "Filas_siembra_activas": [40],
                "Camas_activas_duplicadas": [0],
                "Extrapolacion_ID": auditoria["Conteo_ID"],
            }
        )
        matrices = MatricesTransicion(
            Q=np.diag([0.5, 0.5, 0.5]),
            r=np.array([[0.5], [0.5], [0.5]]),
            p=np.zeros((3, 1)),
        )
        resultado = generar_resultados_diarios(
            datos,
            auditoria,
            extrapolacion,
            {"JULIO|SANTA HELENA": matrices},
        )
        self.assertEqual(len(resultado), 7)
        self.assertFalse(resultado["Ventana_evaluable"].any())
        self.assertTrue(resultado["Error_tallos"].isna().all())
        self.assertEqual(resultado["Dias_faltantes_corte_ventana"].iloc[0], 1)


if __name__ == "__main__":
    unittest.main()
