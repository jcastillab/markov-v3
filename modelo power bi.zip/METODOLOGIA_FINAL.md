# Metodología validada del modelo Markov multifinca

## 1. Objetivo

El modelo pronostica el corte de la semana siguiente a cada conteo. La unidad mínima es un bloque con conteo real. El horizonte oficial va de lunes a domingo.

## 2. Matriz de transición

El flujo consolidado es:

```text
RC -> SS -> AP -> PC
                 -> L
```

`PC` representa corte y `L` representa pérdida. Las matrices se construyen con la metodología 3 por exposiciones observadas dentro de grupos de duración.

Para cada grupo `g` y estado transitorio `i`:

```text
P_g(i -> j) = N_transiciones(i -> j) / N_exposiciones(i)
```

Cada columna debe cumplir:

```text
sum_i Q_ij + r_j + p_j = 1
```

Las matrices por grupo se ponderan con el peso observado del grupo:

```text
Q = sum_g w_g Q_g
r = sum_g w_g r_g
p = sum_g w_g p_g
```

## 3. Vector inicial

Cada conteo entrega el vector inicial de la muestra:

```text
x_0 = [RC_0, SS_0, AP_0]^T
```

La proyección sin nuevos ingresos sigue:

```text
C_d^(0) = r^T x_d^(0)
x_(d+1)^(0) = Q x_d^(0)
```

## 4. Ingreso RC fijo

No existe una serie histórica observada que identifique cuántos tallos entraron a RC cada día después del conteo. Por esta razón, el modelo oficial no infiere ingresos a partir del corte real futuro.

Se define:

```text
b = alpha * RC_0
```

Con la configuración predeterminada:

```text
alpha = 0.20
```

`b` es constante durante todo el horizonte originado por ese conteo.

La proyección con ingresos sigue:

```text
C_d = r^T x_d
x_(d+1) = Q x_d + b e_RC
```

`e_RC` es el vector unitario que agrega la nueva cohorte al estado RC.

El pipeline conserva dos escenarios:

```text
INGRESO_FIJO_PCT_RC
SIN_INGRESOS
```

La diferencia entre ambos mide el aporte del supuesto de ingresos al corte proyectado. No representa un ingreso observado.

## 5. Extrapolación de la muestra al bloque

Sea `y_hat_muestra_b,d` el corte proyectado por Markov para las camas observadas del bloque `b` en el día `d`.

Definimos:

```text
N_b = camas activas del bloque
n_b = camas muestreadas del bloque
F_b = N_b / n_b
```

El corte del bloque es:

```text
y_hat_b,d = y_hat_muestra_b,d * F_b
```

Si `n_b > N_b`, el factor oficial se fija en 1:

```text
F_b = 1
```

El evento queda identificado mediante `Factor_ajustado` y `Motivo_factor`.

## 6. Extrapolación a bloques no muestreados

Sea `M_f` el conjunto de bloques muestreados de la finca `f` durante una semana objetivo.

Para cada día se calcula la tasa ponderada de corte por cama:

```text
r_hat_f,d = sum_(b in M_f) y_hat_b,d / sum_(b in M_f) N_b
```

Para un bloque activo `u` que no tuvo conteo:

```text
y_hat_u,d = N_u * r_hat_f,d
```

La proyección diaria de finca es:

```text
y_hat_f,d = sum_(b in M_f) y_hat_b,d + sum_(u not in M_f) y_hat_u,d
```

La semana se obtiene sumando los siete días:

```text
y_hat_f,sem = sum_d y_hat_f,d
```

Al nivel semanal, la fórmula equivalente es:

```text
r_hat_f,sem = sum_(b in M_f) y_hat_b,sem / sum_(b in M_f) N_b
```

La media simple y la mediana de tasas por bloque se conservan como sensibilidades. La metodología oficial es la tasa ponderada por camas.

## 7. Separación entre evaluación y operación

Un bloque muestreado tiene pronóstico Markov directo.

Un bloque no muestreado tiene estimación operacional basada en la tasa de finca.

Las métricas oficiales de desempeño del modelo Markov usan únicamente pronósticos directos. La imputación operacional se evalúa aparte cuando existe corte real completo para el bloque imputado.

## 8. Ventana evaluable

Una fila `Finca + Bloque + Conteo` es evaluable cuando la semana objetivo contiene los siete cortes reales.

```text
Dias_con_corte_real = 7
Ventana_evaluable = TRUE
```

Un corte igual a cero es un dato válido. Un valor faltante no se reemplaza por cero.

## 9. Métricas

Para cada ventana evaluable `i`:

```text
e_i = y_hat_i - y_i
AE_i = abs(e_i)
```

WAPE:

```text
WAPE = sum_i AE_i / sum_i y_i
```

Sesgo porcentual:

```text
Bias = sum_i e_i / sum_i y_i
```

MAE:

```text
MAE = sum_i AE_i / n
```

Acierto:

```text
Acierto = 1 - WAPE
```

WAPE es la métrica principal porque conserva ponderación por volumen de corte. El sesgo identifica sobreestimación o subestimación sistemática. MAE conserva la escala en tallos.

## 10. Causalidad

El resultado retrospectivo usa la regla de matriz asignada por periodo. El backtest causal usa la última matriz disponible en la fecha de cada conteo.

Ambos resultados deben permanecer separados. El backtest causal es la referencia para medir desempeño temporal sin información fenológica posterior al conteo.

## 11. Semanas y fechas

En tablas de pronóstico:

```text
Semana_ID = semana objetivo
Semana_conteo_ID = semana donde ocurrió el conteo
```

`Dim_Semana` debe relacionarse con `Semana_ID`. La fecha de conteo se filtra mediante su propia columna o mediante `Dim_Fecha` cuando la página está diseñada para auditar el origen del pronóstico.
