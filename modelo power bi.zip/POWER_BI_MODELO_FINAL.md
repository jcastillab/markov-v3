# Power BI, tablero definitivo del modelo Markov

## 1. Criterio de diseño

Se revisó el PBIX entregado como referencia. La estructura visual actual es útil y conviene conservarla: segmentadores en la columna izquierda, tarjetas en la zona superior, gráficos principales en el centro y matrices de detalle en la parte inferior.

El cambio principal no es visual. El tablero debe separar tres universos:

```text
Desempeño Markov directo
Operación de finca con bloques imputados
Auditoría matemática del modelo
```

No se deben mezclar pronósticos directos e imputados dentro de WAPE, MAE o sesgo.

## 2. Tablas principales

Para el tablero de desempeño:

```text
Dim_Finca
Dim_Bloque
Dim_Fecha
Dim_Semana
Dim_Periodo
Dim_Modelo
Fact_Semanal
Fact_Diaria
Fact_Backtest_Causal
Fact_Sensibilidad_Ingresos
```

Para extrapolación y operación:

```text
Fact_Operacion_Semanal
Fact_Operacion_Diaria
Fact_Cobertura_Finca
Fact_Extrapolacion
Control_Imputacion
```

Para auditoría matemática:

```text
Matriz_Q
Vectores_r_p
Potencias_Q
Control_Matrices
Control_Calidad
Control_Insumos
```

## 3. Relaciones

Usar dirección de filtro única desde dimensión hacia hechos.

Relaciones principales:

```text
Dim_Finca[Finca] -> Dim_Bloque[Finca]
Dim_Bloque[Bloque_ID] -> Fact_Semanal[Bloque_ID]
Dim_Bloque[Bloque_ID] -> Fact_Diaria[Bloque_ID]
Dim_Bloque[Bloque_ID] -> Fact_Operacion_Semanal[Bloque_ID]
Dim_Bloque[Bloque_ID] -> Fact_Extrapolacion[Bloque_ID]

Dim_Semana[Semana_ID] -> Fact_Semanal[Semana_ID]
Dim_Semana[Semana_ID] -> Fact_Diaria[Semana_ID]
Dim_Semana[Semana_ID] -> Fact_Operacion_Semanal[Semana_ID]
Dim_Semana[Semana_ID] -> Fact_Cobertura_Finca[Semana_ID]
Dim_Semana[Semana_ID] -> Fact_Extrapolacion[Semana_ID]

Dim_Periodo[Periodo_modelo] -> Fact_Semanal[Periodo_modelo]
Dim_Periodo[Periodo_modelo] -> Fact_Diaria[Periodo_modelo]
Dim_Periodo[Periodo_modelo] -> Fact_Operacion_Semanal[Periodo_modelo]
Dim_Periodo[Periodo_modelo] -> Fact_Cobertura_Finca[Periodo_modelo]
```

`Semana_ID` representa la semana objetivo. `Semana_conteo_ID` se usa para auditoría del origen.

Para matrices:

```text
Dim_Modelo[Modelo_ID] -> Matriz_Q[Modelo_ID]
Dim_Modelo[Modelo_ID] -> Vectores_r_p[Modelo_ID]
Dim_Modelo[Modelo_ID] -> Potencias_Q[Modelo_ID]
```

Evitar relaciones bidireccionales.

## 4. Ordenamiento

Configurar estas columnas con `Ordenar por columna`:

```text
Dim_Fecha[Dia_semana] por Dim_Fecha[Dia_semana_numero]
Dim_Bloque[Bloque_etiqueta] por Dim_Bloque[Bloque_orden]
Dim_Periodo[Periodo_etiqueta] por Dim_Periodo[Orden_periodo]
Matriz_Q[Estado_origen] por Matriz_Q[Orden_origen]
Matriz_Q[Estado_destino] por Matriz_Q[Orden_destino]
Vectores_r_p[Estado_origen] por Vectores_r_p[Orden_estado]
Potencias_Q[Estado_origen] por Potencias_Q[Orden_origen]
Potencias_Q[Estado_destino] por Potencias_Q[Orden_destino]
```

El orden de estados debe quedar `RC, SS, AP`.

## 5. Medidas DAX, desempeño directo

### Pronósticos y ventanas

```DAX
Pronosticos directos =
COUNTROWS ( Fact_Semanal )
```

```DAX
Ventanas evaluables =
CALCULATE (
    COUNTROWS ( Fact_Semanal ),
    KEEPFILTERS ( Fact_Semanal[Ventana_evaluable] = TRUE () )
)
```

```DAX
Cobertura evaluacion % =
DIVIDE ( [Ventanas evaluables], [Pronosticos directos] )
```

### Corte proyectado y real sobre el mismo universo evaluable

```DAX
Corte proyectado evaluable =
CALCULATE (
    SUM ( Fact_Semanal[Corte_proyectado_bloque] ),
    KEEPFILTERS ( Fact_Semanal[Ventana_evaluable] = TRUE () )
)
```

```DAX
Corte real evaluable =
CALCULATE (
    SUM ( Fact_Semanal[Corte_real_bloque] ),
    KEEPFILTERS ( Fact_Semanal[Ventana_evaluable] = TRUE () )
)
```

```DAX
Desviacion tallos =
[Corte proyectado evaluable] - [Corte real evaluable]
```

### WAPE

```DAX
Error absoluto total =
CALCULATE (
    SUM ( Fact_Semanal[Error_absoluto_tallos] ),
    KEEPFILTERS ( Fact_Semanal[Ventana_evaluable] = TRUE () )
)
```

```DAX
WAPE =
DIVIDE ( [Error absoluto total], [Corte real evaluable] )
```

### Sesgo

```DAX
Sesgo % =
DIVIDE ( [Desviacion tallos], [Corte real evaluable] )
```

### MAE

```DAX
MAE tallos =
CALCULATE (
    AVERAGE ( Fact_Semanal[Error_absoluto_tallos] ),
    KEEPFILTERS ( Fact_Semanal[Ventana_evaluable] = TRUE () )
)
```

### Acierto

```DAX
Acierto general % =
1 - [WAPE]
```

WAPE debe ser la tarjeta principal de precisión. `Acierto general %` queda como traducción secundaria.

## 6. Medidas DAX, análisis diario

```DAX
Corte proyectado diario =
SUM ( Fact_Diaria[Corte_proyectado_bloque] )
```

```DAX
Corte real observado diario =
SUM ( Fact_Diaria[Corte_real_bloque] )
```

```DAX
Error diario tallos =
SUM ( Fact_Diaria[Desviacion_tallos] )
```

```DAX
Aporte ingresos diario =
SUM ( Fact_Diaria[Aporte_ingresos_corte_bloque] )
```

Para una métrica diaria de error comparable con el WAPE semanal, filtrar la página o visual con `Ventana_evaluable = TRUE`.

## 7. Medidas DAX, ingreso RC

```DAX
Corte con ingreso fijo =
SUM ( Fact_Semanal[Corte_proyectado_bloque] )
```

```DAX
Corte sin ingresos =
SUM ( Fact_Semanal[Corte_proyectado_sin_ingresos_bloque] )
```

```DAX
Aporte ingresos corte =
SUM ( Fact_Semanal[Aporte_ingresos_corte_bloque] )
```

```DAX
Aporte ingresos % =
DIVIDE ( [Aporte ingresos corte], [Corte con ingreso fijo] )
```

```DAX
Ingreso RC diario muestra =
SUM ( Fact_Semanal[Ingreso_RC_pronosticado_promedio_dia_muestra] )
```

La página de ingresos debe mostrar claramente que el parámetro es fijo y que no representa una medición diaria observada.

## 8. Medidas DAX, extrapolación operacional

### Cobertura

```DAX
Camas activas finca =
SUM ( Fact_Cobertura_Finca[Camas_activas_total] )
```

```DAX
Camas representadas por muestreo =
SUM ( Fact_Cobertura_Finca[Camas_activas_bloques_muestreados] )
```

```DAX
Cobertura camas % =
DIVIDE ( [Camas representadas por muestreo], [Camas activas finca] )
```

```DAX
Bloques activos =
SUM ( Fact_Cobertura_Finca[N_bloques_activos] )
```

```DAX
Bloques muestreados =
SUM ( Fact_Cobertura_Finca[N_bloques_muestreados] )
```

```DAX
Bloques no muestreados =
SUM ( Fact_Cobertura_Finca[N_bloques_no_muestreados] )
```

```DAX
Cobertura bloques % =
DIVIDE ( [Bloques muestreados], [Bloques activos] )
```

### Tasa ponderada por camas

```DAX
Corte bloques muestreados =
SUM ( Fact_Cobertura_Finca[Corte_proyectado_bloques_muestreados_semana] )
```

```DAX
Tasa ponderada tallos por cama =
DIVIDE (
    [Corte bloques muestreados],
    [Camas representadas por muestreo]
)
```

### Bloques no muestreados y finca completa

```DAX
Corte bloques no muestreados =
SUM ( Fact_Cobertura_Finca[Corte_proyectado_bloques_no_muestreados_semana] )
```

```DAX
Corte proyectado finca =
SUM ( Fact_Cobertura_Finca[Corte_proyectado_finca_semana] )
```

```DAX
Participacion imputada % =
DIVIDE ( [Corte bloques no muestreados], [Corte proyectado finca] )
```

No calcular `Tasa ponderada tallos por cama` como `AVERAGE(Fact_Cobertura_Finca[Tasa_corte_proyectado_semanal_por_cama])` cuando hay varias semanas o fincas seleccionadas. La razón de sumas conserva la ponderación correcta.

## 9. Página 1, Resumen general

Conservar la estructura del PBIX actual.

Segmentadores de izquierda:

```text
Finca
Bloque
Periodo_modelo
Semana_etiqueta
Tipo_evaluacion_ventana, opcional
```

Tarjetas superiores:

```text
Corte proyectado evaluable
Corte real evaluable
Desviacion tallos
WAPE
Sesgo %
```

Gráfico principal de línea:

```text
Eje X: Dim_Semana[Semana_etiqueta]
Valores: Corte proyectado evaluable, Corte real evaluable
```

Gráfico de barras por finca:

```text
Eje: Dim_Finca[Finca]
Valores: Corte proyectado evaluable, Corte real evaluable
```

Matriz inferior:

```text
Filas: Finca, Bloque_etiqueta
Valores: Corte proyectado evaluable, Corte real evaluable, Desviacion tallos, WAPE, Sesgo %
```

Esta página debe trabajar con el mismo universo evaluable en todas las tarjetas de desempeño.

## 10. Página 2, Análisis diario

Mantener el diseño actual con segmentadores a la izquierda y tres áreas de análisis.

Segmentadores:

```text
Finca
Bloque
Periodo_modelo
Semana_etiqueta
Fecha_conteo
```

Gráfico de línea superior:

```text
Eje X: Dim_Fecha[Fecha]
Valores: Corte proyectado diario, Corte real observado diario
```

Gráfico central:

```text
Eje X: Dim_Fecha[Dia_semana]
Valores: Error diario tallos
```

Matriz inferior:

```text
Filas: Bloque_etiqueta
Columnas: Dim_Fecha[Dia_semana]
Valores: Corte proyectado diario, Corte real observado diario
```

En la matriz, `Dia_semana` debe estar ordenado por `Dia_semana_numero` para garantizar `Lunes, Martes, Miércoles, Jueves, Viernes, Sábado, Domingo`.

## 11. Página 3, Desempeño del pronóstico

Conservar la estructura actual.

Segmentadores:

```text
Ventana_evaluable
Finca
Bloque
Periodo_modelo
Semana_etiqueta
```

Tarjetas:

```text
WAPE
Sesgo %
MAE tallos
Cobertura evaluacion %
```

Línea semanal:

```text
Eje X: Semana_etiqueta
Valor: WAPE
```

Barras por bloque:

```text
Eje: Bloque_etiqueta
Valor: WAPE
```

Matriz inferior:

```text
Filas: Semana_etiqueta, Bloque_etiqueta
Valores: Corte real evaluable, Corte proyectado evaluable, Error absoluto total, WAPE, Sesgo %
```

Para evitar conclusiones erróneas, no usar promedio de porcentajes de error almacenados por fila para construir el WAPE agregado.

## 12. Página 4, Extrapolación y cobertura

Esta página debe sustituir la lectura antigua centrada únicamente en `N_b / n_b`.

Segmentadores:

```text
Finca
Periodo_modelo
Semana_etiqueta
```

El segmentador `Bloque` debe usarse únicamente en los visuales de detalle. La tasa de finca pierde sentido si la página completa queda filtrada a un bloque.

Tarjetas:

```text
Camas activas finca
Cobertura camas %
Bloques no muestreados
Tasa ponderada tallos por cama
Corte proyectado finca
```

Gráfico de barras por bloque, usando `Fact_Operacion_Semanal`:

```text
Eje: Bloque_etiqueta
Valor: Corte_proyectado_bloque
Leyenda: Tipo_proyeccion
```

El visual debe distinguir `BLOQUE_MUESTREADO` de `BLOQUE_NO_MUESTREADO`.

Gráfico de cobertura:

```text
Eje: Semana_etiqueta
Valores: Cobertura camas %, Cobertura bloques %
```

Tabla inferior:

```text
Finca
Semana_etiqueta
N_bloques_activos
N_bloques_muestreados
N_bloques_no_muestreados
Camas_activas_total
Camas_activas_bloques_muestreados
Tasa_corte_proyectado_semanal_por_cama
Corte_proyectado_bloques_muestreados_semana
Corte_proyectado_bloques_no_muestreados_semana
Corte_proyectado_finca_semana
```

## 13. Página 5, Ingresos RC

Agregar una página específica. Es importante porque el 20 % es un supuesto del modelo.

Segmentadores:

```text
Finca
Bloque
Periodo_modelo
Semana_etiqueta
```

Tarjetas:

```text
Ingreso RC diario muestra
Corte con ingreso fijo
Corte sin ingresos
Aporte ingresos corte
Aporte ingresos %
```

Gráfico de líneas:

```text
Eje X: Semana_etiqueta
Valores: Corte con ingreso fijo, Corte sin ingresos, Corte real evaluable
```

Tabla de sensibilidad:

```text
Control_Ingresos[Escenario_ingreso]
Control_Ingresos[N_ventanas_evaluables]
Control_Ingresos[WAPE]
Control_Ingresos[Sesgo_pct]
Control_Ingresos[MAE_tallos]
```

No denominar ninguna columna como `Ingreso real`. El pipeline no contiene un histórico observado de ingresos RC.

## 14. Página 6, Matrices Markov

Segmentadores:

```text
Finca
Periodo_modelo
Exponente_Q
```

Matriz Q:

```text
Filas: Matriz_Q[Estado_origen]
Columnas: Matriz_Q[Estado_destino]
Valores: Matriz_Q[Probabilidad]
```

Vector r:

```text
Filas: Vectores_r_p[Estado_origen]
Valor: Vectores_r_p[Probabilidad_corte_r]
```

Vector p:

```text
Filas: Vectores_r_p[Estado_origen]
Valor: Vectores_r_p[Probabilidad_perdida_p]
```

Potencia de Q:

```text
Filas: Potencias_Q[Estado_origen]
Columnas: Potencias_Q[Estado_destino]
Valores: Potencias_Q[Probabilidad]
Filtro: Potencias_Q[Exponente_Q]
```

Tarjetas de control:

```text
Radio espectral
Desviacion_max_suma_columna
Norma_Q_horizonte
Converge_Q
```

Estos campos están en `Control_Matrices`.

## 15. Página 7, Control de calidad

Esta página puede quedar oculta para uso técnico.

Mostrar:

```text
Control_Calidad
Control_Insumos
Control_Causalidad
```

La señal principal es `Estado`. Un valor `ERROR` debe bloquear el refresco del tablero hasta revisar el pipeline o los insumos. `CONTROL` identifica situaciones que requieren interpretación, pero no constituyen una falla matemática.

## 16. Segmentadores sincronizados

Sincronizar entre páginas:

```text
Finca
Periodo_modelo
Semana_etiqueta
```

No sincronizar `Bloque` con la página de extrapolación a nivel finca si el objetivo es mantener la tasa ponderada de toda la finca.

## 17. Formato recomendado

```text
WAPE, Sesgo, Acierto, Cobertura: porcentaje con 1 decimal
Cortes y errores: número entero con separador de miles
Tasa tallos por cama: 2 decimales
Factores de extrapolación: 2 decimales
Probabilidades Q, r, p: 4 decimales
```

Usar títulos que indiquen el universo. Ejemplo: `WAPE, pronósticos directos evaluables`. Esto evita interpretar una métrica operacional como desempeño Markov.
