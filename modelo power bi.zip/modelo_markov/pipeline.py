"""Orquestación del modelo multifinca final."""

from __future__ import annotations

import pandas as pd

from .auditorias import (
    asignar_modelo_causal,
    auditar_transiciones_fenologia,
    construir_control_insumos,
)
from .configuracion import ConfiguracionModelo
from .entradas import (
    auditar_conteos_semanales,
    construir_extrapolacion,
    leer_archivos,
    normalizar_finca,
    preparar_calendario,
    preparar_camas_muestreadas,
    preparar_conteos,
    preparar_fenologia,
    preparar_plano_siembra,
)
from .metodologia import METODO_MATRIZ, construir_potencias_q, estimar_metodologia_3
from .modelo_datos_power_bi import construir_tablas_power_bi
from .modelos import ResultadoIngresos, ResultadoModelo
from .proyeccion import completar_bloques_no_muestreados, generar_resultados_diarios
from .reporte_excel import guardar_reporte_excel
from .vigencias import asignar_modelo_a_conteos, clave_modelo


def ejecutar_modelo(config: ConfiguracionModelo) -> ResultadoModelo:
    """Ejecuta matrices, ingresos, pronóstico, extrapolación y auditorías."""

    fenologias, conteos, camas, plano, calendario = leer_archivos(config)
    fincas = tuple(normalizar_finca(finca) for finca in config.fincas)
    datos_conteos = preparar_conteos(
        conteos,
        fincas=fincas,
        flor=config.flor,
        variedad=config.variedad,
    )
    auditoria_base = auditar_conteos_semanales(datos_conteos)

    anios = sorted(pd.to_datetime(auditoria_base["Fecha"]).dt.isocalendar().year.unique())
    if len(anios) != 1:
        raise ValueError(
            "El archivo de camas no tiene año y los conteos abarcan más de uno."
        )
    datos_camas = preparar_camas_muestreadas(camas, int(anios[0]), fincas)
    datos_plano = preparar_plano_siembra(
        plano,
        fincas=fincas,
        flor=config.flor,
        variedad=config.variedad,
    )
    datos_calendario = preparar_calendario(calendario)

    # Las matrices se estiman antes de asignarlas a conteos para conocer su
    # fecha real de disponibilidad y auditar fuga temporal.
    matrices_por_modelo: dict = {}
    potencias: list[pd.DataFrame] = []
    estadisticas: list[dict[str, object]] = []
    auditorias_fenologia: list[pd.DataFrame] = []
    transiciones_fenologia: list[pd.DataFrame] = []
    grupos_duracion: list[pd.DataFrame] = []
    probabilidades_grupo: list[pd.DataFrame] = []
    clasificaciones_tallos: list[pd.DataFrame] = []
    especificaciones = {
        "ABRIL": (config.ruta_fenologia_abril.name, config.hoja_fenologia_abril),
        "JULIO": (config.ruta_fenologia_julio.name, config.hoja_fenologia_julio),
    }

    for periodo, fenologia in fenologias.items():
        archivo, hoja = especificaciones[periodo]
        for finca in fincas:
            datos_feno, columna_fecha, tallos, auditoria_feno = preparar_fenologia(
                fenologia, finca
            )
            estimacion = estimar_metodologia_3(datos_feno, columna_fecha, tallos)
            modelo_clave = clave_modelo(finca, periodo)
            matrices_por_modelo[modelo_clave] = estimacion.matrices

            potencia = construir_potencias_q(
                estimacion.matrices.Q, config.horizonte_matriz
            )
            potencia.insert(0, "Modelo_clave", modelo_clave)
            potencia.insert(1, "Periodo_modelo", periodo)
            potencia.insert(2, "Finca", finca)
            potencias.append(potencia)

            fecha_inicio_feno = pd.Timestamp(datos_feno[columna_fecha].min()).normalize()
            fecha_fin_feno = pd.Timestamp(datos_feno[columna_fecha].max()).normalize()
            n_cohortes = len({str(tallo).split("|", 1)[0] for tallo in tallos})
            estadisticas.append(
                {
                    "Modelo_clave": modelo_clave,
                    "Periodo_modelo": periodo,
                    "Finca": finca,
                    "Metodo_matriz": METODO_MATRIZ,
                    "Archivo_fenologia": archivo,
                    "Hoja_fenologia": hoja,
                    "Fecha_inicio_fenologia": fecha_inicio_feno,
                    "Fecha_fin_fenologia": fecha_fin_feno,
                    "Fecha_disponibilidad_matriz": fecha_fin_feno,
                    "N_cohortes": int(n_cohortes),
                    "N_tallos": len(tallos),
                    "N_tallos_completos": int(
                        estimacion.clasificacion_df["Incluido_grupo"].sum()
                    ),
                    "N_grupos": int(len(estimacion.grupos_df)),
                    "N_ajustes_fenologia": int(len(auditoria_feno)),
                }
            )

            for df, destino in (
                (estimacion.grupos_df, grupos_duracion),
                (estimacion.probabilidades_df, probabilidades_grupo),
                (estimacion.clasificacion_df, clasificaciones_tallos),
            ):
                d = df.copy()
                d.insert(0, "Modelo_clave", modelo_clave)
                d.insert(1, "Periodo_modelo", periodo)
                d.insert(2, "Finca", finca)
                destino.append(d)

            transiciones_fenologia.append(
                auditar_transiciones_fenologia(
                    datos_feno,
                    columna_fecha,
                    tallos,
                    modelo_clave,
                    periodo,
                    finca,
                )
            )

            if not auditoria_feno.empty:
                auditoria_feno = auditoria_feno.copy()
                auditoria_feno.insert(0, "Modelo_clave", modelo_clave)
                auditoria_feno.insert(1, "Periodo_modelo", periodo)
                auditoria_feno.insert(2, "Archivo_fenologia", archivo)
                auditoria_feno.insert(3, "Hoja_fenologia", hoja)
                auditorias_fenologia.append(auditoria_feno)

    potencias_df = pd.concat(potencias, ignore_index=True)
    estadisticas_df = pd.DataFrame(estadisticas)
    grupos_duracion_df = pd.concat(grupos_duracion, ignore_index=True)
    probabilidades_grupo_df = pd.concat(probabilidades_grupo, ignore_index=True)
    clasificaciones_tallos_df = pd.concat(clasificaciones_tallos, ignore_index=True)
    transiciones_fenologia_df = pd.concat(transiciones_fenologia, ignore_index=True)
    auditoria_fenologia_df = (
        pd.concat(auditorias_fenologia, ignore_index=True)
        if auditorias_fenologia
        else pd.DataFrame(
            columns=[
                "Modelo_clave", "Periodo_modelo", "Archivo_fenologia",
                "Hoja_fenologia", "Finca", "Cohorte", "Fecha", "Tallo",
                "Tipo_ajuste", "Estado_original", "Estado_corregido",
                "Estado_modelo",
            ]
        )
    )

    # Backtest retrospectivo por regla calendario. Se mantiene para poder
    # revisar todos los pronósticos históricos tal como se venía trabajando.
    auditoria_conteos = asignar_modelo_a_conteos(
        auditoria_base,
        config.fecha_cambio_matriz,
    )
    seleccionados = auditoria_conteos.loc[auditoria_conteos["Conteo_seleccionado"]]
    for i, fila in estadisticas_df.iterrows():
        eventos = seleccionados.loc[seleccionados["Modelo_clave"].eq(fila["Modelo_clave"])]
        estadisticas_df.loc[i, "Vigencia_desde"] = (
            pd.Timestamp(eventos["Fecha"].min()) if not eventos.empty else pd.NaT
        )
        estadisticas_df.loc[i, "Vigencia_hasta"] = (
            pd.Timestamp(eventos["Fecha"].max()) if not eventos.empty else pd.NaT
        )
        estadisticas_df.loc[i, "N_conteos_asignados"] = int(len(eventos))

    extrapolacion = construir_extrapolacion(
        auditoria_conteos, datos_camas, datos_plano
    )

    # Metodología validada de ingresos: en cada conteo se fija una entrada
    # diaria b = alpha * RC_0. No se reconstruyen ingresos históricos a partir
    # de cortes o conteos posteriores, porque no existe una serie observada de
    # ingresos RC que permita identificarlos de forma independiente.
    ingresos = ResultadoIngresos(
        diario_df=pd.DataFrame(),
        semanal_df=pd.DataFrame(),
        intervalos_df=pd.DataFrame(),
    )
    resultados_muestreados = generar_resultados_diarios(
        datos_conteos,
        auditoria_conteos,
        extrapolacion,
        matrices_por_modelo,
        ingresos_diarios=None,
        ingresos_semanales=None,
        porcentaje_ingreso_inicial=config.porcentaje_ingreso_inicial,
    )
    resultados_operacionales, cobertura_finca = completar_bloques_no_muestreados(
        resultados_muestreados,
        datos_conteos,
        datos_plano,
    )

    # Backtest causal. Cada conteo usa únicamente la matriz que ya estaba
    # disponible en su fecha. Los primeros conteos sin matriz previa quedan
    # fuera de esta tabla.
    auditoria_causal = asignar_modelo_causal(auditoria_base, estadisticas_df)
    extrapolacion_causal = construir_extrapolacion(
        auditoria_causal, datos_camas, datos_plano
    )
    resultados_causales = generar_resultados_diarios(
        datos_conteos,
        auditoria_causal,
        extrapolacion_causal,
        matrices_por_modelo,
        ingresos_diarios=None,
        ingresos_semanales=None,
        porcentaje_ingreso_inicial=config.porcentaje_ingreso_inicial,
    )

    control_insumos = construir_control_insumos(
        datos_conteos, datos_camas, datos_plano, datos_calendario, extrapolacion
    )

    ejecucion_id, modelos_id, tablas = construir_tablas_power_bi(
        config=config,
        matrices_por_modelo=matrices_por_modelo,
        potencias=potencias_df,
        resultados=resultados_muestreados,
        resultados_operacionales=resultados_operacionales,
        resultados_causales=resultados_causales,
        datos_conteos=datos_conteos,
        auditoria_conteos=auditoria_conteos,
        auditoria_causal=auditoria_causal,
        extrapolacion=extrapolacion,
        cobertura_finca=cobertura_finca,
        calendario=datos_calendario,
        estadisticas_fenologia=estadisticas_df,
        ingresos_diarios=ingresos.diario_df,
        ingresos_semanales=ingresos.semanal_df,
        ingresos_intervalos=ingresos.intervalos_df,
        auditoria_fenologia=auditoria_fenologia_df,
        grupos_duracion=grupos_duracion_df,
        probabilidades_grupo=probabilidades_grupo_df,
        clasificaciones_tallos=clasificaciones_tallos_df,
        transiciones_fenologia=transiciones_fenologia_df,
    )
    tablas["Control_Insumos"] = control_insumos
    return ResultadoModelo(
        matrices_por_modelo=matrices_por_modelo,
        potencias_df=potencias_df,
        resultados_diarios_df=resultados_muestreados,
        resultados_operacionales_df=resultados_operacionales,
        resumen_semanal_df=tablas["Fact_Semanal"],
        resumen_semanal_finca_df=pd.DataFrame(),
        ingresos_diarios_df=ingresos.diario_df,
        ingresos_semanales_df=ingresos.semanal_df,
        ingresos_intervalos_df=ingresos.intervalos_df,
        extrapolacion_df=extrapolacion,
        cobertura_finca_df=cobertura_finca,
        auditoria_conteos_df=auditoria_conteos,
        tablas_power_bi=tablas,
        ejecucion_id=ejecucion_id,
        modelos_id=modelos_id,
        estadisticas_fenologia=estadisticas_df,
        auditoria_fenologia_df=auditoria_fenologia_df,
        horizonte_matriz=config.horizonte_matriz,
    )


def ejecutar_y_guardar(config: ConfiguracionModelo) -> ResultadoModelo:
    resultado = ejecutar_modelo(config)
    guardar_reporte_excel(resultado, config.ruta_salida)
    return resultado
