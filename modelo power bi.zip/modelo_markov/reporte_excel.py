"""Escritura del libro tabular que consumirá Power BI."""

from __future__ import annotations

from pathlib import Path

import pandas as pd
import xlsxwriter

from .modelos import ResultadoModelo


COLOR_HECHOS = "#1F5D42"
COLOR_DIMENSIONES = "#356A8A"
COLOR_MODELO = "#9A6B22"
COLOR_GUIA = "#5E6670"
COLOR_TEXTO = "#23312B"

NOMBRES_TABLAS = {
    "Fact_Diaria": "tblFactDiaria",
    "Fact_Semanal": "tblFactSemanal",
    "Fact_Sensibilidad_Ingresos": "tblFactSensibilidadIngresos",
    "Fact_Backtest_Causal": "tblFactBacktestCausal",
    "Fact_Benchmark": "tblFactBenchmark",
    "Fact_Operacion_Diaria": "tblFactOperacionDiaria",
    "Fact_Operacion_Semanal": "tblFactOperacionSemanal",
    "Fact_Conteos": "tblFactConteos",
    "Fact_Extrapolacion": "tblFactExtrapolacion",
    "Fact_Cobertura_Finca": "tblFactCoberturaFinca",
    "Fact_Ingreso_Diario": "tblFactIngresoDiario",
    "Fact_Ingreso_Semanal": "tblFactIngresoSemanal",
    "Fact_Ingreso_Intervalo": "tblFactIngresoIntervalo",
    "Dim_Fecha": "tblDimFecha",
    "Dim_Semana": "tblDimSemana",
    "Dim_Periodo": "tblDimPeriodo",
    "Dim_Finca": "tblDimFinca",
    "Dim_Bloque": "tblDimBloque",
    "Dim_Modelo": "tblDimModelo",
    "Matriz_Q": "tblMatrizQ",
    "Vectores_r_p": "tblVectoresRP",
    "Potencias_Q": "tblPotenciasQ",
    "Control_Fenologia": "tblControlFenologia",
    "Control_Ingresos": "tblControlIngresos",
    "Control_Extrapolacion": "tblControlExtrapolacion",
    "Grupos_Duracion": "tblGruposDuracion",
    "Probabilidades_Grupo": "tblProbabilidadesGrupo",
    "Clasificacion_Tallos": "tblClasificacionTallos",
    "Transiciones_Fenologia": "tblTransicionesFenologia",
    "Control_Transiciones": "tblControlTransiciones",
    "Control_Imputacion": "tblControlImputacion",
    "Control_Benchmark": "tblControlBenchmark",
    "Control_Causalidad": "tblControlCausalidad",
    "Control_Matrices": "tblControlMatrices",
    "Control_Duracion_Estados": "tblControlDuracionEstados",
    "Control_Ingreso_Diagnostico": "tblControlIngresoDiagnostico",
    "Control_Cobertura_Error": "tblControlCoberturaError",
    "Control_Insumos": "tblControlInsumos",
    "Control_Calidad": "tblControlCalidad",
    "Relaciones": "tblRelaciones",
}


def _color_pestana(nombre: str) -> str:
    if nombre.startswith("Fact_"):
        return COLOR_HECHOS
    if nombre.startswith("Dim_"):
        return COLOR_DIMENSIONES
    if nombre in {"Matriz_Q", "Vectores_r_p", "Potencias_Q"}:
        return COLOR_MODELO
    return COLOR_GUIA


def _ancho_columna(nombre: str, datos: pd.Series) -> int:
    """Calcula un ancho legible sin expandir columnas de claves largas."""

    anchos_fijos = {
        "Proyeccion_ID": 58,
        "Resumen_semanal_ID": 58,
        "Sensibilidad_ingreso_ID": 72,
        "Control_ingreso_ID": 42,
        "Resumen_finca_semana_ID": 42,
        "Conteo_ID": 38,
        "Extrapolacion_ID": 38,
        "Cobertura_ID": 34,
        "Ingreso_Diario_ID": 58,
        "Ingreso_Semanal_ID": 58,
        "Ingreso_Intervalo_ID": 66,
        "Intervalo_ID": 44,
        "Matriz_Q_ID": 54,
        "Potencia_Q_ID": 58,
        "Vector_ID": 44,
        "Modelo_ID": 38,
        "Modelo_clave": 28,
        "Ejecucion_ID": 22,
        "Bloque_ID": 24,
        "Bloque_etiqueta": 28,
        "Formula_corte": 28,
        "Formula_estado_con_ingreso": 38,
        "Formula_perdida": 28,
        "Formula_ingreso_intervalo": 64,
        "Regla_ingreso_historico": 48,
        "Regla_pronostico_ingreso": 48,
        "Convencion_conteo_diario": 55,
        "Formula_extrapolacion": 34,
        "Orientacion_matriz_Q": 34,
        "Metodologia": 40,
        "Condicion_vigencia": 32,
        "Regla_seleccion_matriz": 28,
        "Archivo_fenologia": 34,
        "Hoja_fenologia": 22,
        "Tipo_ajuste": 28,
        "Estados_transitorios": 22,
        "Direccion_filtro": 32,
        "Factor_extrapolacion_aplicado": 31,
        "Factor_extrapolacion_teorico": 31,
        "Motivo_factor": 36,
        "Tipo_proyeccion": 38,
        "Metodo_estimacion_bloque": 46,
        "Escenario_ingreso": 30,
        "Metodo_pronostico_ingreso_LS3": 52,
        "Metodo_extrapolacion_finca": 52,
        "Bloques_muestreados": 48,
        "Bloques_no_muestreados": 48,
        "Motivo_no_evaluable": 48,
        "Motivo_no_evaluable_finca": 52,
        "Relacion_activa_sugerida": 29,
        "Corte_real_disponible": 23,
        "Ventana_real_completa": 25,
        "Ventana_evaluable": 22,
        "Control_suma_uno": 20,
    }
    if nombre in anchos_fijos:
        return anchos_fijos[nombre]
    if "Fecha" in nombre or nombre.endswith("_semana"):
        return max(16, min(42, len(nombre) + 2))
    if nombre.endswith("_ID"):
        return max(15, min(36, len(nombre) + 2))
    if "Probabilidad" in nombre or nombre.endswith("_pct"):
        return max(22, min(44, len(nombre) + 2))
    if nombre.startswith((
        "Corte_",
        "Conteo_",
        "Ingreso_",
        "Perdida_",
        "Aporte_",
        "Estado_",
    )):
        return max(24, min(52, len(nombre) + 2))
    if nombre.startswith(("Error_", "Desviacion_", "Residual_", "RMSE_")):
        return max(22, min(52, len(nombre) + 2))
    if pd.api.types.is_bool_dtype(datos.dtype):
        return max(14, min(44, len(nombre) + 2))
    maximo = len(nombre)
    if not datos.empty:
        muestra = datos.dropna().astype(str).head(200)
        if not muestra.empty:
            maximo = max(maximo, int(muestra.map(len).max()))
    return max(10, min(48, maximo + 2))


def _formato_columna(libro, nombre: str, datos: pd.Series):
    if pd.api.types.is_datetime64_any_dtype(datos.dtype):
        return libro.add_format({"num_format": "yyyy-mm-dd"})
    if "Probabilidad" in nombre or nombre in {
        "Suma_columna_Q_r_p",
        "Factor_extrapolacion",
        "Factor_extrapolacion_aplicado",
        "Factor_extrapolacion_teorico",
    }:
        return libro.add_format({"num_format": "0.000000"})
    if nombre.endswith("_pct"):
        return libro.add_format({"num_format": "0.00%"})
    if nombre.startswith((
        "Corte_",
        "Conteo_",
        "Ingreso_",
        "Perdida_",
        "Aporte_",
        "Estado_",
        "Residual_",
        "RMSE_",
        "Desviacion_",
        "Error_absoluto_",
    )) or nombre in {
        "Desviacion_tallos",
        "Error_absoluto_tallos",
    }:
        return libro.add_format({"num_format": "#,##0.00"})
    if pd.api.types.is_integer_dtype(datos.dtype):
        return libro.add_format({"num_format": "0"})
    if pd.api.types.is_float_dtype(datos.dtype):
        return libro.add_format({"num_format": "#,##0.00"})
    return None


def _preparar_hoja(writer, nombre: str, datos: pd.DataFrame) -> None:
    """Escribe una tabla de Excel sin títulos, gráficos ni celdas combinadas."""

    datos.to_excel(writer, sheet_name=nombre, index=False)
    hoja = writer.sheets[nombre]
    hoja.hide_gridlines(2)
    hoja.freeze_panes(1, 0)
    hoja.set_zoom(90)
    hoja.set_tab_color(_color_pestana(nombre))
    hoja.set_default_row(18)

    estilo = "Table Style Medium 4"
    if nombre.startswith("Dim_"):
        estilo = "Table Style Medium 2"
    elif nombre in {"Matriz_Q", "Vectores_r_p", "Potencias_Q"}:
        estilo = "Table Style Medium 7"
    elif nombre.startswith("Control_") or nombre == "Relaciones":
        estilo = "Table Style Medium 1"

    if datos.empty:
        hoja.write_row(0, 0, list(datos.columns))
    else:
        hoja.add_table(
            0,
            0,
            len(datos),
            len(datos.columns) - 1,
            {
                "name": NOMBRES_TABLAS[nombre],
                "style": estilo,
                "columns": [{"header": columna} for columna in datos.columns],
            },
        )

    for indice, columna in enumerate(datos.columns):
        formato = _formato_columna(writer.book, columna, datos[columna])
        hoja.set_column(
            indice,
            indice,
            _ancho_columna(columna, datos[columna]),
            formato,
        )

    hoja.set_row(0, 34)


def guardar_reporte_excel(
    resultado: ResultadoModelo,
    ruta_salida: Path,
) -> None:
    """Guarda el Excel tabular con escritura por filas de alto rendimiento."""

    ruta = Path(ruta_salida)
    ruta.parent.mkdir(parents=True, exist_ok=True)
    ruta_temporal = ruta.with_name(ruta.name + ".tmp")
    try:
        libro = xlsxwriter.Workbook(
            str(ruta_temporal),
            {"nan_inf_to_errors": False, "default_date_format": "yyyy-mm-dd"},
        )
        libro.set_properties(
            {
                "title": "Modelo Markov, datos para Power BI",
                "subject": "Metodología 3 por exposiciones, ingresos RC y auditorías",
                "author": "Juan",
                "comments": "Libro tabular final para Power BI.",
            }
        )
        formato_fecha = libro.add_format({"num_format": "yyyy-mm-dd"})
        formato_numero = libro.add_format({"num_format": "#,##0.00"})
        formato_entero = libro.add_format({"num_format": "0"})
        formato_pct = libro.add_format({"num_format": "0.00%"})
        formato_prob = libro.add_format({"num_format": "0.000000"})

        for nombre, datos in resultado.tablas_power_bi.items():
            hoja = libro.add_worksheet(nombre[:31])
            hoja.hide_gridlines(2)
            hoja.freeze_panes(1, 0)
            hoja.set_zoom(90)
            hoja.set_tab_color(_color_pestana(nombre))
            hoja.set_default_row(18)
            columnas = list(datos.columns)
            hoja.write_row(0, 0, columnas)

            # Conversión a object permite reemplazar NaN/NaT por celdas vacías
            # y evita el lento bucle por celda de pandas.to_excel.
            objeto = datos.astype(object).where(pd.notna(datos), None)
            for indice, fila in enumerate(
                objeto.itertuples(index=False, name=None), start=1
            ):
                hoja.write_row(indice, 0, fila)

            estilo = "Table Style Medium 4"
            if nombre.startswith("Dim_"):
                estilo = "Table Style Medium 2"
            elif nombre in {"Matriz_Q", "Vectores_r_p", "Potencias_Q", "Probabilidades_Grupo"}:
                estilo = "Table Style Medium 7"
            elif nombre.startswith("Control_") or nombre == "Relaciones":
                estilo = "Table Style Medium 1"

            if len(datos) > 0 and columnas:
                hoja.add_table(
                    0,
                    0,
                    len(datos),
                    len(columnas) - 1,
                    {
                        "name": NOMBRES_TABLAS[nombre],
                        "style": estilo,
                        "columns": [{"header": c} for c in columnas],
                    },
                )

            for j, columna in enumerate(columnas):
                serie = datos[columna]
                hoja.set_column(j, j, _ancho_columna(columna, serie))
            hoja.set_row(0, 34)

        libro.close()
        ruta_temporal.replace(ruta)
    finally:
        if ruta_temporal.exists():
            ruta_temporal.unlink()
