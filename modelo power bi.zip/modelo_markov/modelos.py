"""Estructuras de datos usadas por el flujo."""

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class MatricesTransicion:
    """Matriz transitoria y vectores de salida."""

    Q: np.ndarray
    r: np.ndarray
    p: np.ndarray


@dataclass
class ResultadoEstimacion:
    """Resultado interno de la estimación por grupos de duración."""

    matrices: MatricesTransicion
    matrices_por_grupo: dict[int, MatricesTransicion]
    clasificacion_df: pd.DataFrame
    grupos_df: pd.DataFrame
    probabilidades_df: pd.DataFrame = field(default_factory=pd.DataFrame)


@dataclass
class ResultadoIngresos:
    """Ingresos RC históricos estimados en tres granularidades."""

    diario_df: pd.DataFrame
    semanal_df: pd.DataFrame
    intervalos_df: pd.DataFrame


@dataclass
class ResultadoModelo:
    """Datos que alimentan el libro final multifinca."""

    matrices_por_modelo: dict[str, MatricesTransicion]
    potencias_df: pd.DataFrame
    resultados_diarios_df: pd.DataFrame
    resultados_operacionales_df: pd.DataFrame
    resumen_semanal_df: pd.DataFrame
    resumen_semanal_finca_df: pd.DataFrame
    ingresos_diarios_df: pd.DataFrame
    ingresos_semanales_df: pd.DataFrame
    ingresos_intervalos_df: pd.DataFrame
    extrapolacion_df: pd.DataFrame
    cobertura_finca_df: pd.DataFrame
    auditoria_conteos_df: pd.DataFrame
    tablas_power_bi: dict[str, pd.DataFrame]
    ejecucion_id: str
    modelos_id: dict[str, str]
    estadisticas_fenologia: pd.DataFrame
    auditoria_fenologia_df: pd.DataFrame
    horizonte_matriz: int

    @property
    def modelo_id(self) -> str:
        """Alias estable para integraciones que esperan una sola clave."""

        return self.ejecucion_id

    @property
    def matrices(self) -> MatricesTransicion:
        """Devuelve la primera matriz para compatibilidad de lectura."""

        return next(iter(self.matrices_por_modelo.values()))

    @property
    def matrices_por_finca(self) -> dict[str, MatricesTransicion]:
        """Entrega las matrices más recientes por finca para compatibilidad."""

        recientes: dict[str, MatricesTransicion] = {}
        for clave, matrices in self.matrices_por_modelo.items():
            _, finca = clave.split("|", 1)
            if clave.startswith("JULIO|") or finca not in recientes:
                recientes[finca] = matrices
        return recientes
