"""Estimación histórica y pronóstico del ingreso diario a RC."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .entradas import COLUMNAS_CONTEO
from .modelos import MatricesTransicion, ResultadoIngresos
from .vigencias import obtener_matriz


VECTOR_ENTRADA_RC = np.array([1.0, 0.0, 0.0], dtype=float)


def _etiqueta_semana(fecha: pd.Timestamp) -> str:
    iso = pd.Timestamp(fecha).isocalendar()
    return f"{int(iso.year)}-S{int(iso.week):02d}"


def _semana_id(fecha: pd.Timestamp) -> int:
    iso = pd.Timestamp(fecha).isocalendar()
    return int(iso.year) * 100 + int(iso.week)


def _acumulador_entrada(matriz_q: np.ndarray, dias: int) -> np.ndarray:
    """Calcula suma(Q^l u), con l desde cero hasta dias menos uno."""

    acumulador = np.zeros(len(VECTOR_ENTRADA_RC), dtype=float)
    for exponente in range(dias):
        acumulador += np.linalg.matrix_power(
            matriz_q, exponente
        ) @ VECTOR_ENTRADA_RC
    return acumulador


def _mapas_reales(datos_conteos: pd.DataFrame) -> tuple[dict, dict]:
    cortes = (
        datos_conteos.groupby(["Finca", "Bloque", "Fecha"], as_index=False)[
            "Cantidad"
        ]
        .sum(min_count=1)
    )
    mapa_cortes = {
        (fila.Finca, fila.Bloque, pd.Timestamp(fila.Fecha)): fila.Cantidad
        for fila in cortes.itertuples(index=False)
    }
    mascara = datos_conteos[list(COLUMNAS_CONTEO)].notna().all(axis=1)
    mapa_conteos = {
        (fila.Finca, fila.Bloque, pd.Timestamp(fila.Fecha)): np.array(
            [fila.conteo_RC, fila.conteo_SS, fila.conteo_AP], dtype=float
        )
        for fila in datos_conteos.loc[mascara].itertuples(index=False)
    }
    return mapa_cortes, mapa_conteos


def _resumir_ingresos_semanales(diario: pd.DataFrame) -> pd.DataFrame:
    """Promedia los ingresos diarios estimados por semana calendario."""

    if diario.empty:
        return pd.DataFrame()
    filas: list[dict[str, object]] = []
    for (modelo_clave, periodo, finca, bloque, semana_id), grupo in diario.groupby(
        ["Modelo_clave", "Periodo_modelo", "Finca", "Bloque", "Semana_ID"],
        sort=True,
        dropna=False,
    ):
        grupo = grupo.sort_values("Fecha")
        inicio = pd.Timestamp(grupo["Inicio_semana"].iloc[0])
        fin = pd.Timestamp(grupo["Fin_semana"].iloc[0])
        dias = int(grupo["Fecha"].nunique())
        filas.append(
            {
                "Modelo_clave": modelo_clave,
                "Periodo_modelo": periodo,
                "Finca": finca,
                "Bloque": bloque,
                "Semana_ID": int(semana_id),
                "Semana_etiqueta": _etiqueta_semana(inicio),
                "Inicio_semana": inicio,
                "Fin_semana": fin,
                "Fecha_disponibilidad": pd.Timestamp(
                    grupo["Fecha_disponibilidad"].max()
                ),
                "Dias_estimados": dias,
                "Cobertura_semana_pct": dias / 7.0,
                "Semana_completa": bool(dias == 7),
                "N_intervalos": int(grupo["Intervalo_ID"].nunique()),
                "Ingreso_RC_estimado_crudo_por_cama_dia": float(
                    grupo["Ingreso_RC_estimado_crudo_por_cama_dia"].mean()
                ),
                "Ingreso_RC_estimado_por_cama_dia": float(
                    grupo["Ingreso_RC_estimado_por_cama_dia"].mean()
                ),
                "Ingreso_RC_estimado_LS3_por_cama_dia": float(
                    grupo["Ingreso_RC_estimado_LS3_por_cama_dia"].mean()
                ),
                "Ingreso_RC_estimado_promedio_dia_muestra": float(
                    grupo["Ingreso_RC_estimado_muestra"].mean()
                ),
                "Ingreso_RC_estimado_acumulado_muestra": float(
                    grupo["Ingreso_RC_estimado_muestra"].sum()
                ),
                "Ingreso_RC_estimado_promedio_dia_bloque": float(
                    grupo["Ingreso_RC_estimado_bloque"].mean()
                ),
                "Ingreso_RC_estimado_acumulado_bloque": float(
                    grupo["Ingreso_RC_estimado_bloque"].sum()
                ),
                "Dias_ingreso_negativo_truncado": int(
                    grupo["Ingreso_negativo_truncado"].sum()
                ),
            }
        )
    return pd.DataFrame(filas).sort_values(
        ["Finca", "Bloque", "Inicio_semana"]
    ).reset_index(drop=True)


def estimar_ingresos_historicos(
    datos_conteos: pd.DataFrame,
    auditoria_conteos: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    matrices_por_modelo: dict[str, MatricesTransicion],
) -> ResultadoIngresos:
    """Estima ingresos por cama entre conteos seleccionados consecutivos."""

    observados = auditoria_conteos.loc[
        auditoria_conteos["Conteo_seleccionado"]
    ].copy()
    observados = observados.merge(
        extrapolacion[
            [
                "Conteo_ID",
                "Camas_totales_activas",
                "Camas_muestreadas",
                "Factor_extrapolacion",
                "Factor_ajustado",
                "Motivo_factor",
            ]
        ],
        on="Conteo_ID",
        how="left",
        validate="one_to_one",
    )
    if observados["Camas_muestreadas"].isna().any():
        raise ValueError("Falta extrapolación para estimar ingresos históricos.")

    mapa_cortes, mapa_conteos = _mapas_reales(datos_conteos)
    filas_diarias: list[dict[str, object]] = []
    filas_intervalos: list[dict[str, object]] = []

    for (finca, bloque), grupo in observados.groupby(
        ["Finca", "Bloque"], sort=True
    ):
        grupo = grupo.sort_values("Fecha").reset_index(drop=True)
        for indice in range(len(grupo) - 1):
            origen = grupo.iloc[indice]
            destino = grupo.iloc[indice + 1]
            modelo_clave = str(origen["Modelo_clave"])
            periodo_modelo = str(origen["Periodo_modelo"])
            matriz = obtener_matriz(matrices_por_modelo, modelo_clave)
            Q = matriz.Q
            r = matriz.r.ravel()
            p = matriz.p.ravel()
            fecha_origen = pd.Timestamp(origen["Fecha"])
            fecha_destino = pd.Timestamp(destino["Fecha"])
            dias = int((fecha_destino - fecha_origen).days)
            if dias < 1:
                continue

            camas_origen = float(origen["Camas_muestreadas"])
            camas_destino = float(destino["Camas_muestreadas"])
            totales_origen = float(origen["Camas_totales_activas"])
            x0_muestra = origen[list(COLUMNAS_CONTEO)].to_numpy(dtype=float)
            x1_muestra = destino[list(COLUMNAS_CONTEO)].to_numpy(dtype=float)
            x0 = x0_muestra / camas_origen
            x1 = x1_muestra / camas_destino
            base_final = np.linalg.matrix_power(Q, dias) @ x0
            acumulador = _acumulador_entrada(Q, dias)
            denominador = float(acumulador[0])
            if denominador <= 0:
                raise ValueError(
                    f"La matriz Q de {finca} no identifica ingresos en RC."
                )
            ingreso_crudo = float((x1[0] - base_final[0]) / denominador)
            ingreso_por_cama = max(0.0, ingreso_crudo)
            truncado = bool(ingreso_crudo < 0)
            pred_final = base_final + acumulador * ingreso_por_cama
            residual = pred_final - x1

            # Auditoría alternativa. Ajusta una única tasa de ingreso a RC
            # minimizando el error conjunto en RC, SS y AP del conteo destino.
            # No reemplaza el método oficial, se conserva como sensibilidad.
            delta = x1 - base_final
            denominador_ls3 = float(acumulador @ acumulador)
            ingreso_ls3_crudo = (
                float((acumulador @ delta) / denominador_ls3)
                if denominador_ls3 > 0
                else 0.0
            )
            ingreso_ls3_por_cama = max(0.0, ingreso_ls3_crudo)
            pred_final_ls3 = base_final + acumulador * ingreso_ls3_por_cama
            residual_ls3 = pred_final_ls3 - x1
            intervalo_id = (
                f"{finca}|{bloque}|{fecha_origen:%Y%m%d}|"
                f"{fecha_destino:%Y%m%d}"
            )

            estado = x0.copy()
            estado_base = x0.copy()
            cortes_reales: list[float] = []
            cortes_modelo: list[float] = []
            cortes_base: list[float] = []
            for desplazamiento in range(1, dias + 1):
                fecha = fecha_origen + pd.Timedelta(days=desplazamiento)
                corte_modelo_por_cama = float(r @ estado)
                corte_base_por_cama = float(r @ estado_base)
                perdida_por_cama = float(p @ estado)
                estado = Q @ estado + VECTOR_ENTRADA_RC * ingreso_por_cama
                estado_base = Q @ estado_base
                corte_real = mapa_cortes.get((finca, bloque, fecha), np.nan)
                conteo_real_muestra = mapa_conteos.get((finca, bloque, fecha))
                inicio_semana = fecha - pd.Timedelta(days=fecha.weekday())
                filas_diarias.append(
                    {
                        "Intervalo_ID": intervalo_id,
                        "Modelo_clave": modelo_clave,
                        "Periodo_modelo": periodo_modelo,
                        "Finca": finca,
                        "Bloque": bloque,
                        "Fecha": fecha,
                        "Semana_ID": _semana_id(fecha),
                        "Semana_etiqueta": _etiqueta_semana(fecha),
                        "Inicio_semana": inicio_semana,
                        "Fin_semana": inicio_semana + pd.Timedelta(days=6),
                        "Fecha_conteo_origen": fecha_origen,
                        "Fecha_conteo_destino": fecha_destino,
                        "Fecha_disponibilidad": fecha_destino,
                        "Dias_intervalo": dias,
                        "Orden_dia_intervalo": desplazamiento,
                        "Camas_totales_referencia": totales_origen,
                        "Camas_muestreadas_referencia": camas_origen,
                        "Ingreso_RC_estimado_crudo_por_cama_dia": ingreso_crudo,
                        "Ingreso_RC_estimado_por_cama_dia": ingreso_por_cama,
                        "Ingreso_RC_estimado_LS3_crudo_por_cama_dia": ingreso_ls3_crudo,
                        "Ingreso_RC_estimado_LS3_por_cama_dia": ingreso_ls3_por_cama,
                        "Ingreso_RC_estimado_muestra": (
                            ingreso_por_cama * camas_origen
                        ),
                        "Ingreso_RC_estimado_bloque": (
                            ingreso_por_cama * totales_origen
                        ),
                        "Ingreso_negativo_truncado": truncado,
                        "Metodo_estimacion": (
                            "DIRECTO_DIARIO_RC_POR_CAMA"
                            if dias == 1
                            else "PROMEDIO_INTERVALO_RC_POR_CAMA"
                        ),
                        "Corte_teorico_sin_ingresos_por_cama": (
                            corte_base_por_cama
                        ),
                        "Corte_reconstruido_con_ingresos_por_cama": (
                            corte_modelo_por_cama
                        ),
                        "Perdida_reconstruida_por_cama": perdida_por_cama,
                        "Corte_real_bloque": (
                            float(corte_real) if pd.notna(corte_real) else np.nan
                        ),
                        "Conteo_RC_reconstruido_por_cama": float(estado[0]),
                        "Conteo_SS_reconstruido_por_cama": float(estado[1]),
                        "Conteo_AP_reconstruido_por_cama": float(estado[2]),
                        "Conteo_RC_real_muestra": (
                            float(conteo_real_muestra[0])
                            if conteo_real_muestra is not None
                            else np.nan
                        ),
                        "Conteo_SS_real_muestra": (
                            float(conteo_real_muestra[1])
                            if conteo_real_muestra is not None
                            else np.nan
                        ),
                        "Conteo_AP_real_muestra": (
                            float(conteo_real_muestra[2])
                            if conteo_real_muestra is not None
                            else np.nan
                        ),
                    }
                )
                cortes_modelo.append(corte_modelo_por_cama)
                cortes_base.append(corte_base_por_cama)
                if pd.notna(corte_real):
                    cortes_reales.append(float(corte_real))

            filas_intervalos.append(
                {
                    "Intervalo_ID": intervalo_id,
                    "Modelo_clave": modelo_clave,
                    "Periodo_modelo": periodo_modelo,
                    "Finca": finca,
                    "Bloque": bloque,
                    "Fecha_conteo_origen": fecha_origen,
                    "Fecha_conteo_destino": fecha_destino,
                    "Fecha_disponibilidad": fecha_destino,
                    "Dias_intervalo": dias,
                    "Camas_muestreadas_origen": camas_origen,
                    "Camas_muestreadas_destino": camas_destino,
                    "Camas_totales_referencia": totales_origen,
                    "Conteo_RC_origen_por_cama": float(x0[0]),
                    "Conteo_SS_origen_por_cama": float(x0[1]),
                    "Conteo_AP_origen_por_cama": float(x0[2]),
                    "Conteo_RC_destino_real_por_cama": float(x1[0]),
                    "Conteo_SS_destino_real_por_cama": float(x1[1]),
                    "Conteo_AP_destino_real_por_cama": float(x1[2]),
                    "Conteo_RC_destino_sin_ingresos_por_cama": float(
                        base_final[0]
                    ),
                    "Conteo_RC_destino_reconstruido_por_cama": float(
                        pred_final[0]
                    ),
                    "Residual_conteo_RC_por_cama": float(residual[0]),
                    "Residual_conteo_SS_por_cama": float(residual[1]),
                    "Residual_conteo_AP_por_cama": float(residual[2]),
                    "RMSE_conteos_destino_por_cama": float(
                        np.sqrt(np.mean(np.square(residual)))
                    ),
                    "Ingreso_RC_estimado_LS3_crudo_por_cama_dia": ingreso_ls3_crudo,
                    "Ingreso_RC_estimado_LS3_por_cama_dia": ingreso_ls3_por_cama,
                    "Conteo_RC_destino_reconstruido_LS3_por_cama": float(pred_final_ls3[0]),
                    "Conteo_SS_destino_reconstruido_LS3_por_cama": float(pred_final_ls3[1]),
                    "Conteo_AP_destino_reconstruido_LS3_por_cama": float(pred_final_ls3[2]),
                    "Residual_LS3_conteo_RC_por_cama": float(residual_ls3[0]),
                    "Residual_LS3_conteo_SS_por_cama": float(residual_ls3[1]),
                    "Residual_LS3_conteo_AP_por_cama": float(residual_ls3[2]),
                    "RMSE_LS3_conteos_destino_por_cama": float(
                        np.sqrt(np.mean(np.square(residual_ls3)))
                    ),
                    "Mejora_RMSE_LS3_vs_RC_por_cama": float(
                        np.sqrt(np.mean(np.square(residual)))
                        - np.sqrt(np.mean(np.square(residual_ls3)))
                    ),
                    "Ingreso_RC_estimado_crudo_por_cama_dia": ingreso_crudo,
                    "Ingreso_RC_estimado_por_cama_dia": ingreso_por_cama,
                    "Ingreso_RC_estimado_dia_muestra_origen": (
                        ingreso_por_cama * camas_origen
                    ),
                    "Ingreso_RC_estimado_dia_bloque": (
                        ingreso_por_cama * totales_origen
                    ),
                    "Ingreso_negativo_truncado": truncado,
                    "Corte_real_acumulado_bloque": (
                        float(sum(cortes_reales)) if cortes_reales else np.nan
                    ),
                    "Corte_teorico_sin_ingresos_acumulado_bloque": (
                        float(sum(cortes_base)) * totales_origen
                    ),
                    "Corte_reconstruido_con_ingresos_acumulado_bloque": (
                        float(sum(cortes_modelo)) * totales_origen
                    ),
                    "Dias_con_corte_real": int(len(cortes_reales)),
                    "Control_RC_reproducido": bool(
                        np.isclose(pred_final[0], x1[0], atol=1e-6)
                    ),
                }
            )

    diario = pd.DataFrame(filas_diarias)
    intervalos = pd.DataFrame(filas_intervalos)
    if not diario.empty:
        diario = diario.sort_values(["Finca", "Bloque", "Fecha"]).reset_index(
            drop=True
        )
    if not intervalos.empty:
        intervalos = intervalos.sort_values(
            ["Finca", "Bloque", "Fecha_conteo_origen"]
        ).reset_index(drop=True)
    return ResultadoIngresos(
        diario_df=diario,
        semanal_df=_resumir_ingresos_semanales(diario),
        intervalos_df=intervalos,
    )


def pronosticar_tasa_ingreso(
    ingresos_semanales: pd.DataFrame,
    finca: str,
    bloque: str,
    fecha_conteo: pd.Timestamp,
    conteo_rc: float,
    camas_muestreadas: float,
    ventana_semanas: int,
    porcentaje_inicial: float,
    columna_tasa: str = "Ingreso_RC_estimado_por_cama_dia",
    sufijo_metodo: str = "",
) -> dict[str, object]:
    """Pronostica el ingreso sin estimaciones disponibles después del conteo."""

    fecha = pd.Timestamp(fecha_conteo)
    historial = ingresos_semanales.copy()
    if not historial.empty:
        historial = historial.loc[
            historial["Fecha_disponibilidad"].le(fecha)
        ].copy()

    def seleccionar(datos: pd.DataFrame) -> tuple[pd.DataFrame, bool]:
        completas = datos.loc[datos["Semana_completa"]].copy()
        if not completas.empty:
            return completas, True
        return datos.copy(), False

    for nivel in ("BLOQUE", "FINCA"):
        if historial.empty:
            break
        candidatos = historial.loc[historial["Finca"].eq(finca)].copy()
        if nivel == "BLOQUE":
            candidatos = candidatos.loc[candidatos["Bloque"].eq(bloque)]
        candidatos, completas = seleccionar(candidatos)
        if candidatos.empty:
            continue
        semanas = (
            candidatos["Semana_ID"].drop_duplicates().sort_values().tail(
                ventana_semanas
            )
        )
        usados = candidatos.loc[candidatos["Semana_ID"].isin(semanas)].copy()
        pesos = usados["Dias_estimados"].to_numpy(dtype=float)
        if columna_tasa not in usados.columns:
            raise ValueError(f"No existe la columna histórica de ingreso {columna_tasa}.")
        valores = usados[columna_tasa].to_numpy(dtype=float)
        tasa_por_cama = float(np.average(valores, weights=pesos))
        return {
            "Ingreso_RC_pronosticado_por_cama": max(0.0, tasa_por_cama),
            "Ingreso_RC_pronosticado_muestra": max(
                0.0, tasa_por_cama * float(camas_muestreadas)
            ),
            "Metodo_pronostico_ingreso": (
                f"MEDIA_MOVIL_{len(semanas)}_SEMANAS_{nivel}"
                + ("" if completas else "_PARCIAL")
                + sufijo_metodo
            ),
            "N_semanas_historial_ingreso": int(len(semanas)),
            "N_dias_historial_ingreso": int(pesos.sum()),
            "Fecha_ultima_disponibilidad_ingreso": pd.Timestamp(
                usados["Fecha_disponibilidad"].max()
            ),
        }

    ingreso_muestra = max(0.0, float(conteo_rc) * float(porcentaje_inicial))
    return {
        "Ingreso_RC_pronosticado_por_cama": (
            ingreso_muestra / float(camas_muestreadas)
        ),
        "Ingreso_RC_pronosticado_muestra": ingreso_muestra,
        "Metodo_pronostico_ingreso": "PRIOR_PORCENTAJE_RC" + sufijo_metodo,
        "N_semanas_historial_ingreso": 0,
        "N_dias_historial_ingreso": 0,
        "Fecha_ultima_disponibilidad_ingreso": pd.NaT,
    }
