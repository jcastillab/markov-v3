"""Tablas planas para construir el modelo de datos en Power BI."""

from __future__ import annotations

import hashlib
import json

import numpy as np
import pandas as pd

from .configuracion import ESTADOS, ConfiguracionModelo
from .auditorias import (
    construir_control_benchmark, construir_control_causalidad,
    construir_control_transiciones, construir_fact_benchmark,
    enriquecer_causalidad_matriz,
)
from .metodologia import METODO_MATRIZ
from .modelos import MatricesTransicion


MESES = (
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
)
DIAS = ("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")


def _bloque_id(finca: object, bloque: object) -> str:
    return f"{str(finca).strip()}|{str(bloque).strip()}"


def _fecha_id(fecha: object) -> int:
    return int(pd.Timestamp(fecha).strftime("%Y%m%d"))


def _semana_id(fecha: object) -> int:
    iso = pd.Timestamp(fecha).isocalendar()
    return int(iso.year) * 100 + int(iso.week)


def crear_ids_modelo(
    config: ConfiguracionModelo,
    matrices_por_modelo: dict[str, MatricesTransicion],
    estadisticas: pd.DataFrame,
) -> tuple[str, dict[str, str]]:
    """Crea una ejecución global y una clave para cada periodo y finca."""

    modelos: dict[str, str] = {}
    metadatos = estadisticas.set_index("Modelo_clave").to_dict("index")
    for modelo_clave, matrices in sorted(matrices_por_modelo.items()):
        if modelo_clave not in metadatos:
            raise ValueError(
                f"Faltan metadatos para la matriz {modelo_clave}."
            )
        metadata = metadatos[modelo_clave]
        periodo = str(metadata["Periodo_modelo"])
        finca = str(metadata["Finca"])
        contenido = {
            "metodologia": METODO_MATRIZ,
            "periodo": periodo,
            "finca": finca,
            "archivo": str(metadata["Archivo_fenologia"]),
            "hoja": str(metadata["Hoja_fenologia"]),
            "Q": np.round(matrices.Q, 12).tolist(),
            "r": np.round(matrices.r, 12).tolist(),
            "p": np.round(matrices.p, 12).tolist(),
        }
        huella = hashlib.sha256(
            json.dumps(contenido, sort_keys=True).encode("utf-8")
        ).hexdigest()[:12]
        modelos[modelo_clave] = (
            f"M3_{periodo}_{finca.replace(' ', '_')}_{huella.upper()}"
        )
    ejecucion = {
        "modelos": modelos,
        "horizonte": config.horizonte_matriz,
        "ingreso_fijo_pct_rc": config.porcentaje_ingreso_inicial,
        "flor": config.flor,
        "variedad": config.variedad,
        "regla_seleccion_matriz": "FECHA_CONTEO",
        "metodo_extrapolacion_finca": "TASA_PONDERADA_CAMAS_BLOQUES_MUESTREADOS",
        "fecha_cambio_matriz": str(config.fecha_cambio_matriz),
    }
    huella = hashlib.sha256(
        json.dumps(ejecucion, sort_keys=True).encode("utf-8")
    ).hexdigest()[:12]
    return f"EJEC_{huella.upper()}", modelos


def construir_fact_diaria(
    resultados: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    # La evaluación del Markov se limita a pronósticos nacidos de un conteo
    # real del mismo bloque. Las imputaciones de bloques sin conteo pertenecen
    # a la capa operacional de extrapolación de finca y no entran aquí.
    datos = resultados.copy()
    if "Bloque_muestreado" in datos.columns:
        datos = datos.loc[datos["Bloque_muestreado"].fillna(True)].copy()
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay proyecciones sin Modelo_ID asignado.")
    datos["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Fecha_ID"] = datos["Fecha"].map(_fecha_id)
    datos["Fecha_conteo_ID"] = datos["Fecha_conteo"].map(_fecha_id)
    datos["Semana_ID"] = datos["Fecha"].map(_semana_id)
    datos["Semana_conteo_ID"] = datos["Fecha_conteo"].map(_semana_id)
    datos["Proyeccion_ID"] = [
        f"{conteo_id}|{fecha_id}"
        for conteo_id, fecha_id in zip(datos["Conteo_ID"], datos["Fecha_ID"])
    ]
    datos["Desviacion_tallos"] = datos["Error_tallos"]
    datos["Error_absoluto_tallos"] = datos["Error_tallos"].abs()
    datos["Error_absoluto_pct"] = datos["Error_pct"]
    claves = [
        "Proyeccion_ID", "Ejecucion_ID", "Modelo_ID", "Conteo_ID",
        "Modelo_clave", "Periodo_modelo", "Bloque_ID", "Fecha_ID",
        "Fecha_conteo_ID", "Semana_ID", "Semana_conteo_ID", "Finca",
        "Bloque", "Fecha", "Fecha_conteo", "Horizonte_dias", "Orden_dia",
    ]
    excluir = {"Semana_conteo", "Semana_proyectada", "Dia_semana", *claves}
    # El modelo oficial no usa ingresos históricos ni la variante LS3. Se
    # eliminan esas columnas de la capa Power BI para evitar interpretaciones
    # erróneas. El ingreso fijo queda en Ingreso_RC_pronosticado_* y el método
    # se etiqueta explícitamente.
    obsoletas = {
        c for c in datos.columns
        if "LS3" in c
        or "real_estimado" in c.lower()
        or "historial_ingreso" in c.lower()
        or c in {
            "Ventana_ingreso_real_completa",
            "Dias_con_ingreso_real_ventana",
            "Ingreso_real_estimado_disponible",
            "Desviacion_ingreso_muestra",
            "Error_absoluto_ingreso_pct",
            "Fecha_ultima_disponibilidad_ingreso",
        }
    }
    datos = datos.drop(columns=list(obsoletas), errors="ignore")
    datos["Metodo_pronostico_ingreso"] = "FIJO_PORCENTAJE_RC_CONTEO"
    metricas = [col for col in datos.columns if col not in excluir]
    return datos[claves + metricas].sort_values(
        ["Finca", "Bloque", "Fecha_conteo", "Fecha"]
    ).reset_index(drop=True)


def construir_fact_semanal(
    resultados: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    # Unidad oficial de evaluación: Finca + Bloque + Conteo semanal.
    # Se excluyen explícitamente las proyecciones imputadas de bloques sin
    # conteo, aunque lleguen por error en el DataFrame de entrada.
    datos = resultados.copy()
    if "Bloque_muestreado" in datos.columns:
        datos = datos.loc[datos["Bloque_muestreado"].fillna(True)].copy()
    filas: list[dict[str, object]] = []
    for conteo_id, grupo in datos.groupby("Conteo_ID", sort=True):
        grupo = grupo.sort_values("Fecha")
        primera = grupo.iloc[0]
        modelo_clave = str(primera["Modelo_clave"])
        finca = primera["Finca"]
        bloque = primera["Bloque"]
        fecha_conteo = pd.Timestamp(primera["Fecha_conteo"])
        inicio = pd.Timestamp(grupo["Fecha"].min())
        fin = pd.Timestamp(grupo["Fecha"].max())
        evaluable = bool(grupo["Ventana_evaluable"].all() and len(grupo) == 7)
        real_parcial = grupo["Corte_real_bloque"].sum(min_count=1)
        real = float(real_parcial) if evaluable else np.nan
        proyectado = float(grupo["Corte_proyectado_bloque"].sum())
        proyectado_muestra = float(
            grupo["Corte_proyectado_muestra"].sum(min_count=1)
        )
        sin_ingresos = float(
            grupo["Corte_proyectado_sin_ingresos_bloque"].sum()
        )
        proyectado_ls3 = float(grupo["Corte_proyectado_LS3_bloque"].sum())
        desviacion = proyectado - real if pd.notna(real) else np.nan
        error_abs = abs(desviacion) if pd.notna(desviacion) else np.nan
        error_pct = (
            error_abs / abs(real)
            if pd.notna(error_abs) and float(real) != 0
            else np.nan
        )
        desviacion_sin_ingresos = (
            sin_ingresos - real if pd.notna(real) else np.nan
        )
        error_abs_sin_ingresos = (
            abs(desviacion_sin_ingresos)
            if pd.notna(desviacion_sin_ingresos)
            else np.nan
        )
        error_pct_sin_ingresos = (
            error_abs_sin_ingresos / abs(real)
            if pd.notna(error_abs_sin_ingresos) and float(real) != 0
            else np.nan
        )
        desviacion_ls3 = proyectado_ls3 - real if pd.notna(real) else np.nan
        error_abs_ls3 = abs(desviacion_ls3) if pd.notna(desviacion_ls3) else np.nan
        error_pct_ls3 = (
            error_abs_ls3 / abs(real)
            if pd.notna(error_abs_ls3) and float(real) != 0
            else np.nan
        )
        mejora_error_ingresos = (
            error_abs_sin_ingresos - error_abs
            if pd.notna(error_abs_sin_ingresos) and pd.notna(error_abs)
            else np.nan
        )
        aporte_ingresos = proyectado - sin_ingresos
        aporte_ingresos_pct = (
            aporte_ingresos / proyectado if proyectado != 0 else np.nan
        )
        ingreso_pronosticado = float(
            grupo["Ingreso_RC_pronosticado_muestra"].mean()
        )
        ingreso_pronosticado_ls3 = float(
            grupo["Ingreso_RC_pronosticado_LS3_muestra"].mean()
        )
        ingreso_real = grupo["Ingreso_RC_real_estimado_muestra"].mean()
        dias_ingreso_real = int(
            grupo["Ingreso_RC_real_estimado_muestra"].notna().sum()
        )
        ingreso_real_evaluable = (
            float(ingreso_real) if dias_ingreso_real == 7 else np.nan
        )
        ultimo_conteo = grupo.loc[grupo["Conteo_real_disponible"]]
        ultimo = ultimo_conteo.iloc[-1] if not ultimo_conteo.empty else None
        bloque_id = _bloque_id(finca, bloque)
        semana_id = _semana_id(inicio)
        filas.append(
            {
                "Resumen_semanal_ID": f"{conteo_id}|{semana_id}",
                "Ejecucion_ID": ejecucion_id,
                "Modelo_ID": modelos_id[modelo_clave],
                "Modelo_clave": modelo_clave,
                "Periodo_modelo": primera["Periodo_modelo"],
                "Conteo_ID": conteo_id,
                "Bloque_ID": bloque_id,
                "Finca": finca,
                "Bloque": bloque,
                "Fecha_conteo_ID": _fecha_id(fecha_conteo),
                "Fecha_inicio_ID": _fecha_id(inicio),
                "Fecha_fin_ID": _fecha_id(fin),
                "Semana_ID": semana_id,
                "Semana_conteo_ID": _semana_id(fecha_conteo),
                "Fecha_conteo": fecha_conteo,
                "Fecha_inicio_semana": inicio,
                "Fecha_fin_semana": fin,
                "Conteo_RC": float(primera["Conteo_RC"]),
                "Conteo_SS": float(primera["Conteo_SS"]),
                "Conteo_AP": float(primera["Conteo_AP"]),
                "Conteo_CO": float(primera["Conteo_CO"]),
                "Camas_totales_activas": float(
                    primera["Camas_totales_activas"]
                ),
                "Camas_muestreadas": float(primera["Camas_muestreadas"]),
                "Factor_extrapolacion_teorico": float(
                    primera["Factor_extrapolacion_teorico"]
                ),
                "Factor_extrapolacion_aplicado": float(
                    primera["Factor_extrapolacion"]
                ),
                "Factor_ajustado": bool(primera["Factor_ajustado"]),
                "Motivo_factor": primera["Motivo_factor"],
                "Tipo_proyeccion": "BLOQUE_MUESTREADO",
                "Bloque_muestreado": True,
                "Pronostico_markov_directo": True,
                "Unidad_evaluacion": "FINCA_BLOQUE_SEMANA",
                "Metodo_estimacion_bloque": primera.get(
                    "Metodo_estimacion_bloque", "MARKOV_MUESTRA_X_FACTOR_CAMAS"
                ),
                "N_bloques_activos_semana": primera.get("N_bloques_activos_semana", np.nan),
                "N_bloques_muestreados_semana": primera.get("N_bloques_muestreados_semana", np.nan),
                "N_bloques_no_muestreados_semana": primera.get("N_bloques_no_muestreados_semana", np.nan),
                "Camas_activas_finca_semana": primera.get("Camas_activas_finca_semana", np.nan),
                "Camas_activas_bloques_muestreados_semana": primera.get(
                    "Camas_activas_bloques_muestreados_semana", np.nan
                ),
                "Camas_activas_bloques_no_muestreados_semana": primera.get(
                    "Camas_activas_bloques_no_muestreados_semana", np.nan
                ),
                "Cobertura_camas_pct": primera.get("Cobertura_camas_pct", np.nan),
                "Cobertura_bloques_pct": primera.get("Cobertura_bloques_pct", np.nan),
                "Ingreso_RC_pronosticado_promedio_dia_muestra": (
                    ingreso_pronosticado
                ),
                "Ingreso_RC_pronosticado_acumulado_muestra": (
                    ingreso_pronosticado * 7
                ),
                "Ingreso_RC_pronosticado_LS3_promedio_dia_muestra": (
                    ingreso_pronosticado_ls3
                ),
                "Ingreso_RC_pronosticado_LS3_acumulado_muestra": (
                    ingreso_pronosticado_ls3 * 7
                ),
                "Metodo_pronostico_ingreso_LS3": primera.get(
                    "Metodo_pronostico_ingreso_LS3", ""
                ),
                "Ingreso_RC_real_estimado_promedio_dia_muestra": (
                    ingreso_real_evaluable
                ),
                "Dias_con_ingreso_real": dias_ingreso_real,
                "Metodo_pronostico_ingreso": primera.get(
                    "Metodo_pronostico_ingreso", ""
                ),
                "Ingreso_pronosticado_pct_RC_dia": (
                    ingreso_pronosticado / float(primera["Conteo_RC"])
                    if float(primera["Conteo_RC"]) != 0
                    else np.nan
                ),
                "N_semanas_historial_ingreso": int(
                    primera.get("N_semanas_historial_ingreso", 0)
                ),
                "N_dias_historial_ingreso": int(
                    primera.get("N_dias_historial_ingreso", 0)
                ),
                "Fecha_ultima_disponibilidad_ingreso": primera.get(
                    "Fecha_ultima_disponibilidad_ingreso", pd.NaT
                ),
                "Conteo_total_proyectado_fin_semana_muestra": float(
                    grupo.iloc[-1]["Conteo_total_proyectado_muestra"]
                ),
                "Conteo_total_real_ultimo_semana_muestra": (
                    float(ultimo["Conteo_total_real_muestra"])
                    if ultimo is not None
                    else np.nan
                ),
                "Corte_proyectado_sin_ingresos_bloque": sin_ingresos,
                "Corte_proyectado_muestra": proyectado_muestra,
                "Corte_proyectado_bloque": proyectado,
                "Corte_proyectado_LS3_bloque": proyectado_ls3,
                "Aporte_ingresos_corte_bloque": aporte_ingresos,
                "Aporte_ingresos_LS3_corte_bloque": proyectado_ls3 - sin_ingresos,
                "Aporte_ingresos_pct_proyeccion": aporte_ingresos_pct,
                "Perdida_proyectada_bloque": float(
                    grupo["Perdida_proyectada_bloque"].sum()
                ),
                "Corte_real_parcial_bloque": (
                    float(real_parcial) if pd.notna(real_parcial) else np.nan
                ),
                "Corte_real_bloque": real,
                "Desviacion_tallos": desviacion,
                "Error_absoluto_tallos": error_abs,
                "Error_absoluto_pct": error_pct,
                "Desviacion_sin_ingresos_tallos": desviacion_sin_ingresos,
                "Error_absoluto_sin_ingresos_tallos": error_abs_sin_ingresos,
                "Error_absoluto_sin_ingresos_pct": error_pct_sin_ingresos,
                "Desviacion_LS3_tallos": desviacion_ls3,
                "Error_absoluto_LS3_tallos": error_abs_ls3,
                "Error_absoluto_LS3_pct": error_pct_ls3,
                "Mejora_error_por_ingresos_tallos": mejora_error_ingresos,
                "Ingreso_mejora_pronostico": (
                    bool(mejora_error_ingresos > 0)
                    if pd.notna(mejora_error_ingresos)
                    else np.nan
                ),
                "WAPE_numerador": error_abs,
                "WAPE_denominador": abs(real) if pd.notna(real) else np.nan,
                "Dias_proyectados": int(len(grupo)),
                "Dias_con_corte_real": int(
                    grupo["Corte_real_disponible"].sum()
                ),
                "Dias_faltantes_corte": int(
                    grupo["Dias_faltantes_corte_ventana"].iloc[0]
                ),
                "Cobertura_real_pct": float(
                    grupo["Corte_real_disponible"].sum() / 7.0
                ),
                "Ventana_evaluable": evaluable,
                "Ventana_real_completa": evaluable,
                "Motivo_no_evaluable": primera["Motivo_no_evaluable"],
                "Tipo_evaluacion_ventana": primera[
                    "Tipo_evaluacion_ventana"
                ],
            }
        )
    salida = pd.DataFrame(filas).sort_values(
        ["Finca", "Bloque", "Fecha_conteo"]
    ).reset_index(drop=True)
    salida["Metodo_pronostico_ingreso"] = "FIJO_PORCENTAJE_RC_CONTEO"
    obsoletas = {
        c for c in salida.columns
        if "LS3" in c
        or "real_estimado" in c.lower()
        or "historial_ingreso" in c.lower()
        or c in {
            "Dias_con_ingreso_real",
            "Fecha_ultima_disponibilidad_ingreso",
        }
    }
    return salida.drop(columns=list(obsoletas), errors="ignore")



def construir_fact_sensibilidad_ingresos(fact_semanal: pd.DataFrame) -> pd.DataFrame:
    """Compara el Markov base contra el supuesto validado de ingreso RC fijo."""

    if fact_semanal.empty:
        return pd.DataFrame()
    escenarios = (
        ("SIN_INGRESOS", "Corte_proyectado_sin_ingresos_bloque"),
        ("INGRESO_FIJO_PCT_RC", "Corte_proyectado_bloque"),
    )
    filas: list[dict[str, object]] = []
    for fila in fact_semanal.itertuples(index=False):
        real = fila.Corte_real_bloque
        for escenario, columna in escenarios:
            proyectado = float(getattr(fila, columna))
            evaluable = bool(fila.Ventana_evaluable)
            desviacion = proyectado - float(real) if evaluable and pd.notna(real) else np.nan
            error_abs = abs(desviacion) if pd.notna(desviacion) else np.nan
            filas.append(
                {
                    "Sensibilidad_ingreso_ID": f"{fila.Resumen_semanal_ID}|{escenario}",
                    "Ejecucion_ID": fila.Ejecucion_ID,
                    "Modelo_ID": fila.Modelo_ID,
                    "Modelo_clave": fila.Modelo_clave,
                    "Periodo_modelo": fila.Periodo_modelo,
                    "Conteo_ID": fila.Conteo_ID,
                    "Bloque_ID": fila.Bloque_ID,
                    "Finca": fila.Finca,
                    "Bloque": fila.Bloque,
                    "Semana_ID": fila.Semana_ID,
                    "Semana_conteo_ID": fila.Semana_conteo_ID,
                    "Fecha_conteo_ID": fila.Fecha_conteo_ID,
                    "Fecha_inicio_ID": fila.Fecha_inicio_ID,
                    "Fecha_conteo": fila.Fecha_conteo,
                    "Fecha_inicio_semana": fila.Fecha_inicio_semana,
                    "Escenario_ingreso": escenario,
                    "Corte_proyectado_bloque": proyectado,
                    "Corte_real_bloque": real if evaluable else np.nan,
                    "Desviacion_tallos": desviacion,
                    "Error_absoluto_tallos": error_abs,
                    "WAPE_numerador": error_abs,
                    "WAPE_denominador": abs(real) if evaluable and pd.notna(real) else np.nan,
                    "Ventana_evaluable": evaluable,
                }
            )
    return pd.DataFrame(filas).sort_values(
        ["Finca", "Bloque", "Fecha_conteo", "Escenario_ingreso"]
    ).reset_index(drop=True)


def construir_control_extrapolacion(fact_semanal: pd.DataFrame) -> pd.DataFrame:
    """Resume cobertura de camas, factores y error por finca y total."""

    if fact_semanal.empty:
        return pd.DataFrame()
    datos = fact_semanal.loc[fact_semanal["Ventana_evaluable"]].copy()
    datos["Cobertura_muestra_bloque_pct"] = (
        datos["Camas_muestreadas"] / datos["Camas_totales_activas"]
    )
    datos["APE"] = np.where(
        datos["Corte_real_bloque"].abs().gt(0),
        (datos["Corte_proyectado_bloque"] - datos["Corte_real_bloque"]).abs()
        / datos["Corte_real_bloque"].abs(),
        np.nan,
    )
    grupos = [("TOTAL", datos)]
    grupos.extend((finca, grupo.copy()) for finca, grupo in datos.groupby("Finca", sort=True))
    filas: list[dict[str, object]] = []
    for alcance, grupo in grupos:
        err = grupo["Corte_proyectado_bloque"] - grupo["Corte_real_bloque"]
        denom = float(grupo["Corte_real_bloque"].abs().sum())
        factores = grupo["Factor_extrapolacion_aplicado"].astype(float)
        coberturas = grupo["Cobertura_muestra_bloque_pct"].astype(float)
        validos_corr = grupo[["Factor_extrapolacion_aplicado", "APE"]].dropna()
        correlacion = (
            float(validos_corr.corr().iloc[0, 1])
            if len(validos_corr) > 1
            and validos_corr["Factor_extrapolacion_aplicado"].nunique() > 1
            and validos_corr["APE"].nunique() > 1
            else np.nan
        )
        filas.append(
            {
                "Control_extrapolacion_ID": alcance,
                "Alcance": alcance,
                "N_ventanas_evaluables": int(len(grupo)),
                "N_factores_ajustados": int(grupo["Factor_ajustado"].sum()),
                "Factor_min": float(factores.min()),
                "Factor_q25": float(factores.quantile(0.25)),
                "Factor_mediana": float(factores.median()),
                "Factor_q75": float(factores.quantile(0.75)),
                "Factor_max": float(factores.max()),
                "Cobertura_muestra_mediana_pct": float(coberturas.median()),
                "Cobertura_muestra_min_pct": float(coberturas.min()),
                "Cobertura_muestra_max_pct": float(coberturas.max()),
                "WAPE": float(err.abs().sum()) / denom if denom else np.nan,
                "Sesgo_pct": float(err.sum()) / denom if denom else np.nan,
                "APE_mediana": float(grupo["APE"].median()),
                "Correlacion_factor_APE": correlacion,
            }
        )
    return pd.DataFrame(filas)


def construir_control_ingresos(fact_sensibilidad: pd.DataFrame) -> pd.DataFrame:
    """Resume desempeño de cada estrategia de ingreso por finca y total."""

    if fact_sensibilidad.empty:
        return pd.DataFrame()
    evaluables = fact_sensibilidad.loc[fact_sensibilidad["Ventana_evaluable"]].copy()
    filas: list[dict[str, object]] = []
    grupos = [("TOTAL", evaluables)]
    grupos.extend((finca, grupo.copy()) for finca, grupo in evaluables.groupby("Finca", sort=True))
    for alcance, datos in grupos:
        for escenario, grupo in datos.groupby("Escenario_ingreso", sort=True):
            denominador = float(grupo["WAPE_denominador"].sum())
            numerador = float(grupo["WAPE_numerador"].sum())
            desviacion = float(grupo["Desviacion_tallos"].sum())
            filas.append(
                {
                    "Control_ingreso_ID": f"{alcance}|{escenario}",
                    "Alcance": alcance,
                    "Escenario_ingreso": escenario,
                    "N_ventanas_evaluables": int(len(grupo)),
                    "Corte_real_total": denominador,
                    "Corte_proyectado_total": float(grupo["Corte_proyectado_bloque"].sum()),
                    "Error_absoluto_total": numerador,
                    "WAPE": numerador / denominador if denominador else np.nan,
                    "Sesgo_pct": desviacion / denominador if denominador else np.nan,
                    "MAE_tallos": float(grupo["Error_absoluto_tallos"].mean()),
                }
            )
    return pd.DataFrame(filas)


def construir_fact_conteos(
    auditoria: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    datos = auditoria.merge(
        extrapolacion[
            [
                "Conteo_ID", "Camas_totales_activas", "Camas_muestreadas",
                "Factor_extrapolacion_teorico", "Factor_extrapolacion",
                "Factor_ajustado", "Motivo_factor",
            ]
        ],
        on="Conteo_ID",
        how="left",
        validate="one_to_one",
    )
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay conteos sin Modelo_ID asignado.")
    datos["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Fecha_ID"] = datos["Fecha"].map(_fecha_id)
    return datos.sort_values(["Finca", "Bloque", "Fecha"]).reset_index(drop=True)


def construir_fact_extrapolacion(
    extrapolacion: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    datos = extrapolacion.copy()
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay factores de extrapolación sin Modelo_ID asignado.")
    datos["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Fecha_conteo_ID"] = datos["Fecha_conteo"].map(_fecha_id)
    # En Power BI, Semana_ID siempre representa la semana que se pronostica.
    # Se conserva Semana_conteo_ID para auditoría del muestreo que originó el pronóstico.
    if "Semana_conteo_ID" not in datos.columns:
        datos["Semana_conteo_ID"] = datos["Semana_ID"]
    if "Semana_objetivo_ID" in datos.columns:
        datos["Semana_ID"] = datos["Semana_objetivo_ID"]
    return datos.sort_values(["Finca", "Bloque", "Fecha_conteo"]).reset_index(
        drop=True
    )


def construir_fact_cobertura_finca(
    cobertura: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    """Tabla de auditoría de cobertura e imputación por finca y semana."""

    if cobertura.empty:
        return cobertura.copy()
    datos = cobertura.copy()
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay coberturas de finca sin Modelo_ID asignado.")
    datos["Fecha_referencia_ID"] = datos["Fecha_referencia_conteo"].map(_fecha_id)
    datos["Fecha_inicio_ID"] = datos["Fecha_inicio_proyeccion"].map(_fecha_id)
    # La dimensión semanal del tablero se alinea con la semana objetivo, no con
    # la semana del conteo. Esto evita que un mismo segmentador represente
    # semanas distintas entre desempeño y cobertura operacional.
    datos["Semana_ID"] = datos["Fecha_inicio_proyeccion"].map(_semana_id)
    columnas_iniciales = [
        "Cobertura_ID", "Ejecucion_ID", "Modelo_ID", "Modelo_clave",
        "Periodo_modelo", "Finca", "Semana_ID", "Semana_conteo_ID",
        "Fecha_referencia_ID", "Fecha_inicio_ID",
    ]
    restantes = [c for c in datos.columns if c not in columnas_iniciales]
    return datos[columnas_iniciales + restantes].sort_values(
        ["Finca", "Semana_conteo_ID"]
    ).reset_index(drop=True)


def _agregar_claves_ingreso(
    datos: pd.DataFrame,
    tipo: str,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    if datos.empty:
        return datos.copy()
    salida = datos.copy()
    salida["Ejecucion_ID"] = ejecucion_id
    salida["Modelo_ID"] = salida["Modelo_clave"].map(modelos_id)
    if salida["Modelo_ID"].isna().any():
        raise ValueError(f"Hay ingresos {tipo.lower()} sin Modelo_ID asignado.")
    salida["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(salida["Finca"], salida["Bloque"])
    ]
    if tipo == "DIARIO":
        salida["Fecha_ID"] = salida["Fecha"].map(_fecha_id)
        salida["Ingreso_Diario_ID"] = [
            f"{b}|{f}|{m}"
            for b, f, m in zip(
                salida["Bloque_ID"], salida["Fecha_ID"], salida["Modelo_ID"]
            )
        ]
    elif tipo == "SEMANAL":
        salida["Inicio_semana_ID"] = salida["Inicio_semana"].map(_fecha_id)
        salida["Ingreso_Semanal_ID"] = [
            f"{b}|{s}|{m}"
            for b, s, m in zip(
                salida["Bloque_ID"], salida["Semana_ID"], salida["Modelo_ID"]
            )
        ]
    else:
        salida["Fecha_conteo_origen_ID"] = salida["Fecha_conteo_origen"].map(
            _fecha_id
        )
        salida["Fecha_conteo_destino_ID"] = salida[
            "Fecha_conteo_destino"
        ].map(_fecha_id)
        salida["Ingreso_Intervalo_ID"] = [
            f"{i}|{m}"
            for i, m in zip(salida["Intervalo_ID"], salida["Modelo_ID"])
        ]
    id_columna = {
        "DIARIO": "Ingreso_Diario_ID",
        "SEMANAL": "Ingreso_Semanal_ID",
        "INTERVALO": "Ingreso_Intervalo_ID",
    }[tipo]
    columnas_iniciales = [
        id_columna, "Ejecucion_ID", "Modelo_ID", "Modelo_clave",
        "Periodo_modelo", "Bloque_ID", "Finca", "Bloque",
    ]
    restantes = [
        columna for columna in salida.columns if columna not in columnas_iniciales
    ]
    return salida[columnas_iniciales + restantes].reset_index(drop=True)


def construir_dim_bloque(
    datos_conteos: pd.DataFrame,
    resultados: pd.DataFrame | None = None,
) -> pd.DataFrame:
    fuentes = [datos_conteos[["Finca", "Bloque"]]]
    if resultados is not None and not resultados.empty:
        fuentes.append(resultados[["Finca", "Bloque"]])
    datos = pd.concat(fuentes, ignore_index=True).drop_duplicates().copy()
    datos["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Bloque_etiqueta"] = [
        f"{f} | Bloque {b}" for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Bloque_orden"] = pd.to_numeric(datos["Bloque"], errors="coerce").astype(
        "Int64"
    )
    return datos[
        ["Bloque_ID", "Finca", "Bloque", "Bloque_etiqueta", "Bloque_orden"]
    ].sort_values(["Finca", "Bloque_orden", "Bloque"]).reset_index(drop=True)


def construir_dim_finca(datos_conteos: pd.DataFrame) -> pd.DataFrame:
    """Entrega una dimensión común para filtrar hechos y matrices."""

    fincas = sorted(datos_conteos["Finca"].dropna().unique().tolist())
    return pd.DataFrame(
        {
            "Finca_ID": fincas,
            "Finca": fincas,
            "Finca_orden": list(range(1, len(fincas) + 1)),
        }
    )


def construir_dim_fecha(
    calendario: pd.DataFrame,
    resultados: pd.DataFrame,
    ingresos_diarios: pd.DataFrame,
    auditoria_fenologia: pd.DataFrame | None = None,
) -> pd.DataFrame:
    fechas_requeridas = [
        resultados["Fecha"].min(), resultados["Fecha"].max(),
        resultados["Fecha_conteo"].min(), resultados["Fecha_conteo"].max(),
    ]
    if not ingresos_diarios.empty:
        fechas_requeridas.extend(
            [ingresos_diarios["Fecha"].min(), ingresos_diarios["Fecha"].max()]
        )
    if auditoria_fenologia is not None and not auditoria_fenologia.empty:
        fechas_requeridas.extend(
            [
                auditoria_fenologia["Fecha"].min(),
                auditoria_fenologia["Fecha"].max(),
            ]
        )
    fecha_min = pd.Timestamp(min(fechas_requeridas))
    fecha_min = fecha_min - pd.Timedelta(days=fecha_min.weekday())
    fecha_max = pd.Timestamp(max(fechas_requeridas))
    fecha_max = fecha_max + pd.Timedelta(days=6 - fecha_max.weekday())
    datos = calendario.loc[calendario["Fecha"].between(fecha_min, fecha_max)].copy()
    esperadas = pd.date_range(fecha_min, fecha_max, freq="D")
    if set(datos["Fecha"]) != set(esperadas):
        raise ValueError("El calendario no cubre todas las fechas del modelo.")
    filas: list[dict[str, object]] = []
    for fecha in datos["Fecha"].sort_values():
        iso = fecha.isocalendar()
        inicio = fecha - pd.Timedelta(days=fecha.weekday())
        filas.append(
            {
                "Fecha_ID": _fecha_id(fecha), "Fecha": fecha,
                "Anio": int(fecha.year), "Trimestre": f"T{int(fecha.quarter)}",
                "Mes_numero": int(fecha.month), "Mes": MESES[fecha.month - 1],
                "Anio_mes_ID": int(fecha.strftime("%Y%m")),
                "Anio_mes": fecha.strftime("%Y-%m"), "Dia_mes": int(fecha.day),
                "Dia_semana_numero": int(fecha.weekday() + 1),
                "Dia_semana": DIAS[fecha.weekday()],
                "Es_fin_semana": bool(fecha.weekday() >= 5),
                "Semana_ID": int(iso.year) * 100 + int(iso.week),
                "Anio_ISO": int(iso.year), "Semana_ISO": int(iso.week),
                "Semana_etiqueta": f"{int(iso.year)}-S{int(iso.week):02d}",
                "Inicio_semana": inicio,
                "Fin_semana": inicio + pd.Timedelta(days=6),
            }
        )
    return pd.DataFrame(filas)


def construir_dim_semana(dim_fecha: pd.DataFrame) -> pd.DataFrame:
    columnas = [
        "Semana_ID", "Semana_etiqueta", "Anio_ISO", "Semana_ISO",
        "Inicio_semana", "Fin_semana",
    ]
    return dim_fecha[columnas].drop_duplicates("Semana_ID").reset_index(drop=True)


def construir_dim_periodo() -> pd.DataFrame:
    """Dimensión mínima para filtrar ABRIL y JULIO sin rutas ambiguas."""

    return pd.DataFrame(
        [
            {"Periodo_modelo": "ABRIL", "Orden_periodo": 1, "Periodo_etiqueta": "ABRIL"},
            {"Periodo_modelo": "JULIO", "Orden_periodo": 2, "Periodo_etiqueta": "JULIO"},
        ]
    )


def construir_matrices(
    matrices_por_modelo: dict[str, MatricesTransicion],
    modelos_id: dict[str, str],
) -> tuple[pd.DataFrame, pd.DataFrame]:
    filas_q: list[dict[str, object]] = []
    filas_v: list[dict[str, object]] = []
    for modelo_clave, matrices in sorted(matrices_por_modelo.items()):
        periodo, finca = modelo_clave.split("|", 1)
        modelo_id = modelos_id[modelo_clave]
        for i_destino, destino in enumerate(ESTADOS):
            for i_origen, origen in enumerate(ESTADOS):
                filas_q.append(
                    {
                        "Matriz_Q_ID": f"{modelo_id}|Q|{origen}|{destino}",
                        "Modelo_ID": modelo_id,
                        "Modelo_clave": modelo_clave,
                        "Periodo_modelo": periodo,
                        "Finca": finca,
                        "Estado_origen": origen, "Estado_destino": destino,
                        "Orden_origen": i_origen + 1,
                        "Orden_destino": i_destino + 1,
                        "Probabilidad": float(matrices.Q[i_destino, i_origen]),
                    }
                )
        for i, estado in enumerate(ESTADOS):
            suma_q = float(matrices.Q[:, i].sum())
            corte = float(matrices.r[i, 0])
            perdida = float(matrices.p[i, 0])
            suma = suma_q + corte + perdida
            filas_v.append(
                {
                    "Vector_ID": f"{modelo_id}|{estado}", "Modelo_ID": modelo_id,
                    "Modelo_clave": modelo_clave,
                    "Periodo_modelo": periodo,
                    "Finca": finca, "Estado_origen": estado,
                    "Orden_estado": i + 1,
                    "Probabilidad_transitoria_Q": suma_q,
                    "Probabilidad_corte_r": corte,
                    "Probabilidad_perdida_p": perdida,
                    "Suma_columna_Q_r_p": suma,
                    "Control_suma_uno": bool(np.isclose(suma, 1.0)),
                }
            )
    return pd.DataFrame(filas_q), pd.DataFrame(filas_v)


def preparar_potencias(
    potencias: pd.DataFrame,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    datos = potencias.copy()
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay potencias Q sin Modelo_ID asignado.")
    datos["Potencia_Q_ID"] = [
        f"{m}|Q{e}|{o}|{d}"
        for m, e, o, d in zip(
            datos["Modelo_ID"], datos["Exponente_Q"],
            datos["Estado_origen"], datos["Estado_destino"],
        )
    ]
    return datos


def construir_dim_modelo(
    config: ConfiguracionModelo,
    ejecucion_id: str,
    modelos_id: dict[str, str],
    estadisticas: pd.DataFrame,
) -> pd.DataFrame:
    fecha = pd.Timestamp.now(tz="America/Bogota").tz_localize(None).normalize()
    fecha_cambio = pd.Timestamp(config.fecha_cambio_matriz)
    filas = []
    for fila in estadisticas.itertuples(index=False):
        periodo = str(fila.Periodo_modelo)
        if periodo == "ABRIL":
            fecha_inicio_regla = pd.NaT
            fecha_fin_regla = fecha_cambio - pd.Timedelta(days=1)
            condicion = (
                f"Fecha_conteo < {fecha_cambio:%Y-%m-%d}"
            )
        else:
            fecha_inicio_regla = fecha_cambio
            fecha_fin_regla = pd.NaT
            condicion = (
                f"Fecha_conteo >= {fecha_cambio:%Y-%m-%d}"
            )
        filas.append(
            {
                "Modelo_ID": modelos_id[fila.Modelo_clave],
                "Ejecucion_ID": ejecucion_id,
                "Modelo_clave": fila.Modelo_clave,
                "Periodo_modelo": periodo,
                "Finca": fila.Finca,
                "Metodologia_ID": "M3",
                "Metodologia": "Matriz ponderada por grupos de duración",
                "Version_salida": "9.0.0", "Fecha_generacion": fecha,
                "Regla_seleccion_matriz": "Fecha del conteo",
                "Fecha_cambio_matriz": fecha_cambio,
                "Fecha_inicio_regla": fecha_inicio_regla,
                "Fecha_fin_regla": fecha_fin_regla,
                "Condicion_vigencia": condicion,
                "Primer_conteo_asignado": fila.Vigencia_desde,
                "Ultimo_conteo_asignado": fila.Vigencia_hasta,
                "N_conteos_asignados": int(fila.N_conteos_asignados),
                "Hoja_fenologia": fila.Hoja_fenologia,
                "Archivo_fenologia": fila.Archivo_fenologia,
                "Archivo_conteos": config.ruta_conteos.name,
                "Archivo_camas_muestreadas": config.ruta_camas_muestreadas.name,
                "Archivo_plano_siembra": config.ruta_plano_siembra.name,
                "Archivo_calendario": config.ruta_calendario.name,
                "Flor": config.flor, "Variedad": config.variedad,
                "Estados_transitorios": "RC | SS | AP",
                "Orientacion_matriz_Q": "Columnas: origen | Filas: destino",
                "Formula_estado_con_ingreso": "x_(t+1) = Q x_t + b e_RC",
                "Formula_corte": "C_(t+1) = r^T x_t",
                "Formula_perdida": "L_(t+1) = p^T x_t",
                "Escala_ingreso": "Ingreso diario fijo calculado sobre RC del conteo de la muestra",
                "Metodo_ingreso": "FIJO_PORCENTAJE_RC_CONTEO",
                "Formula_ingreso": "b = alpha * RC_0; x_(t+1) = Q x_t + b e_RC",
                "Regla_factor_inconsistente": (
                    "Si camas muestreadas superan camas activas, factor = 1"
                ),
                "Regla_corte_faltante": (
                    "Si falta un día, toda la ventana queda fuera de evaluación"
                ),
                "Unidad_evaluacion_modelo": "Finca + Bloque + Fecha_conteo -> semana objetivo",
                "Regla_imputacion_evaluacion": (
                    "Bloques sin conteo se excluyen de métricas Markov"
                ),
                "Porcentaje_ingreso_RC_diario": config.porcentaje_ingreso_inicial,
                "Regla_ingresos": "No se estiman ingresos históricos; alpha se mantiene fijo durante todo el horizonte",
                "Horizonte_potencias_Q": config.horizonte_matriz,
                "N_cohortes_fenologia": int(fila.N_cohortes),
                "N_tallos_fenologia": int(fila.N_tallos),
                "N_tallos_completos": int(fila.N_tallos_completos),
                "N_grupos_duracion": int(fila.N_grupos),
                "N_ajustes_fenologia": int(fila.N_ajustes_fenologia),
            }
        )
    return pd.DataFrame(filas)


def construir_control_fenologia(
    auditoria_fenologia: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    """Expone las normalizaciones de fuente que afectan las matrices."""

    datos = auditoria_fenologia.copy()
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay ajustes fenológicos sin Modelo_ID asignado.")
    datos["Fecha_ID"] = datos["Fecha"].map(_fecha_id)
    datos.insert(
        0,
        "Ajuste_Fenologia_ID",
        [
            f"{modelo}|AJUSTE|{indice:04d}"
            for indice, modelo in enumerate(datos["Modelo_ID"], 1)
        ],
    )
    columnas_iniciales = [
        "Ajuste_Fenologia_ID", "Ejecucion_ID", "Modelo_ID",
        "Modelo_clave", "Periodo_modelo", "Finca", "Cohorte",
        "Fecha_ID", "Fecha", "Tallo", "Tipo_ajuste",
        "Estado_original", "Estado_corregido", "Estado_modelo",
        "Archivo_fenologia", "Hoja_fenologia",
    ]
    restantes = [
        columna for columna in datos.columns if columna not in columnas_iniciales
    ]
    return datos[columnas_iniciales + restantes].sort_values(
        ["Tipo_ajuste", "Periodo_modelo", "Finca", "Cohorte", "Fecha", "Tallo"]
    ).reset_index(drop=True)


def construir_control_calidad(
    auditoria: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    fact_semanal: pd.DataFrame,
    cobertura_finca: pd.DataFrame,
    vectores: pd.DataFrame,
    dim_modelo: pd.DataFrame,
    control_fenologia: pd.DataFrame,
    fecha_cambio_matriz: pd.Timestamp,
) -> pd.DataFrame:
    fecha_cambio_matriz = pd.Timestamp(fecha_cambio_matriz)
    seleccionados = auditoria.loc[auditoria["Conteo_seleccionado"]].copy()
    periodo_esperado = np.where(
        seleccionados["Fecha"].lt(fecha_cambio_matriz), "ABRIL", "JULIO"
    )
    violaciones_vigencia = int(
        (seleccionados["Periodo_modelo"].to_numpy() != periodo_esperado).sum()
    )
    conteos_abril = int(seleccionados["Periodo_modelo"].eq("ABRIL").sum())
    conteos_julio = int(seleccionados["Periodo_modelo"].eq("JULIO").sum())
    metricas = [
        ("CONTEOS", "Conteos recibidos", len(auditoria), "OK", ""),
        (
            "CONTEOS", "Conteos seleccionados", int(auditoria["Conteo_seleccionado"].sum()),
            "OK", "Se conserva el último conteo por bloque y semana",
        ),
        (
            "CONTEOS", "Conteos descartados por duplicidad semanal",
            int((~auditoria["Conteo_seleccionado"]).sum()), "CONTROL", "",
        ),
        (
            "VIGENCIA", "Conteos asignados a matriz ABRIL", conteos_abril,
            "OK", f"Fecha del conteo anterior a {fecha_cambio_matriz:%Y-%m-%d}",
        ),
        (
            "VIGENCIA", "Conteos asignados a matriz JULIO", conteos_julio,
            "OK", f"Fecha del conteo desde {fecha_cambio_matriz:%Y-%m-%d}",
        ),
        (
            "VIGENCIA", "Violaciones de la regla por fecha del conteo",
            violaciones_vigencia,
            "OK" if violaciones_vigencia == 0 else "ERROR",
            "El periodo se determina exclusivamente con Fecha_conteo",
        ),
        (
            "EXTRAPOLACION", "Factores fijados en 1",
            int(extrapolacion["Factor_ajustado"].sum()), "CONTROL",
            "Camas muestreadas superiores a camas activas",
        ),
        (
            "EXTRAPOLACION FINCA", "Bloques-semana imputados fuera de evaluación",
            int(cobertura_finca["N_bloques_no_muestreados"].sum())
            if not cobertura_finca.empty else 0,
            "CONTROL",
            "La imputación sirve para estimar finca y no entra en métricas Markov",
        ),
        (
            "EXTRAPOLACION FINCA", "Semanas-finca con cobertura parcial",
            int((cobertura_finca["N_bloques_no_muestreados"] > 0).sum())
            if not cobertura_finca.empty else 0,
            "CONTROL",
            "Semanas con al menos un bloque activo sin conteo",
        ),
        (
            "EVALUACION MARKOV", "Pronósticos Markov directos",
            int(len(fact_semanal)), "OK",
            "Una fila por Finca + Bloque + semana de conteo con conteo real de origen",
        ),
        (
            "EVALUACION MARKOV", "Ventanas Markov evaluables",
            int(fact_semanal["Ventana_evaluable"].sum()), "OK",
            "Pronóstico directo con los 7 cortes reales de la semana objetivo",
        ),
        (
            "EVALUACION MARKOV", "Ventanas Markov no evaluables",
            int((~fact_semanal["Ventana_evaluable"]).sum()), "CONTROL",
            "Incluye pronósticos directos con faltantes y semanas futuras",
        ),
        (
            "EVALUACION MARKOV", "Semanas calendario objetivo distintas",
            int(fact_semanal["Semana_ID"].nunique()), "OK",
            "Semanas ISO distintas presentes en los pronósticos directos",
        ),
        (
            "EVALUACION MARKOV", "Ventanas directas con corte diario faltante",
            int(fact_semanal["Tipo_evaluacion_ventana"].eq("NO_EVALUABLE").sum()),
            "CONTROL", "Al menos un corte diario faltante dentro del registro",
        ),
        (
            "EVALUACION MARKOV", "Ventanas directas futuras sin cortes registrados",
            int(fact_semanal["Tipo_evaluacion_ventana"].eq("FUTURA").sum()),
            "CONTROL", "La semana objetivo es posterior al último corte del bloque",
        ),
        (
            "MATRICES", "Columnas Q+r+p válidas",
            int(vectores["Control_suma_uno"].sum()),
            "OK" if vectores["Control_suma_uno"].all() else "ERROR",
            f"{len(vectores)} columnas revisadas",
        ),
        (
            "MATRICES", "Matrices ponderadas generadas", len(dim_modelo),
            "OK" if len(dim_modelo) == 6 else "ERROR",
            "Dos periodos por cada una de las tres fincas",
        ),
        (
            "FENOLOGIA", "Ajustes de etiquetas auditados",
            len(control_fenologia), "CONTROL" if len(control_fenologia) else "OK",
            "Incluye normalizaciones como R4C a RC4 y vacíos aislados",
        ),
        (
            "FENOLOGIA", "Normalizaciones de etiqueta",
            int(control_fenologia["Tipo_ajuste"].eq("NORMALIZACION_ETIQUETA").sum()),
            "CONTROL", "Correcciones explícitas conservadas en Control_Fenologia",
        ),
        (
            "FENOLOGIA", "Vacíos aislados rellenados",
            int(control_fenologia["Tipo_ajuste"].eq("VACIO_AISLADO").sum()),
            "CONTROL", "Se usa el estado anterior cuando hay observación antes y después",
        ),
    ]
    filas = []
    for i, (categoria, metrica, valor, estado, detalle) in enumerate(metricas, 1):
        filas.append(
            {
                "Control_ID": i, "Categoria": categoria, "Metrica": metrica,
                "Valor": float(valor), "Estado": estado, "Detalle": detalle,
            }
        )
    return pd.DataFrame(filas)


def construir_relaciones() -> pd.DataFrame:
    relaciones = []
    for tabla in (
        "Fact_Diaria", "Fact_Semanal", "Fact_Conteos", "Fact_Extrapolacion",
        "Fact_Ingreso_Diario", "Fact_Ingreso_Semanal", "Fact_Ingreso_Intervalo",
        "Fact_Sensibilidad_Ingresos",
    ):
        relaciones.append(
            ("Dim_Bloque", "Bloque_ID", tabla, "Bloque_ID", "1:*", True)
        )
    relaciones.extend(
        [
            ("Dim_Finca", "Finca", "Fact_Cobertura_Finca", "Finca", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Cobertura_Finca", "Semana_ID", "1:*", True),
            ("Dim_Modelo", "Modelo_ID", "Fact_Cobertura_Finca", "Modelo_ID", "1:*", False),
            ("Dim_Fecha", "Fecha_ID", "Fact_Cobertura_Finca", "Fecha_referencia_ID", "1:*", False),
            ("Dim_Finca", "Finca", "Dim_Bloque", "Finca", "1:*", True),
            ("Dim_Finca", "Finca", "Dim_Modelo", "Finca", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Diaria", "Fecha_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Diaria", "Fecha_conteo_ID", "1:*", False),
            ("Dim_Fecha", "Fecha_ID", "Fact_Semanal", "Fecha_inicio_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Semanal", "Fecha_conteo_ID", "1:*", False),
            ("Dim_Fecha", "Fecha_ID", "Fact_Conteos", "Fecha_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Extrapolacion", "Fecha_conteo_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Ingreso_Diario", "Fecha_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Ingreso_Semanal", "Inicio_semana_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Ingreso_Intervalo", "Fecha_conteo_origen_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Ingreso_Intervalo", "Fecha_conteo_destino_ID", "1:*", False),
            ("Dim_Fecha", "Fecha_ID", "Fact_Sensibilidad_Ingresos", "Fecha_inicio_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Fact_Sensibilidad_Ingresos", "Fecha_conteo_ID", "1:*", False),
            ("Dim_Semana", "Semana_ID", "Fact_Diaria", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Semanal", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Conteos", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Extrapolacion", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Ingreso_Diario", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Ingreso_Semanal", "Semana_ID", "1:*", True),
            ("Dim_Semana", "Semana_ID", "Fact_Sensibilidad_Ingresos", "Semana_ID", "1:*", True),
            ("Dim_Modelo", "Modelo_ID", "Matriz_Q", "Modelo_ID", "1:*", True),
            ("Dim_Modelo", "Modelo_ID", "Vectores_r_p", "Modelo_ID", "1:*", True),
            ("Dim_Modelo", "Modelo_ID", "Potencias_Q", "Modelo_ID", "1:*", True),
            ("Dim_Modelo", "Modelo_ID", "Control_Fenologia", "Modelo_ID", "1:*", True),
            ("Dim_Fecha", "Fecha_ID", "Control_Fenologia", "Fecha_ID", "1:*", True),
        ]
    )
    for tabla in (
        "Fact_Diaria", "Fact_Semanal", "Fact_Conteos", "Fact_Extrapolacion",
        "Fact_Ingreso_Diario", "Fact_Ingreso_Semanal", "Fact_Ingreso_Intervalo",
        "Fact_Sensibilidad_Ingresos",
    ):
        relaciones.append(
            ("Dim_Modelo", "Modelo_ID", tabla, "Modelo_ID", "1:*", False)
        )
    columnas = [
        "Tabla_dimension", "Campo_dimension", "Tabla_hechos", "Campo_hechos",
        "Cardinalidad", "Relacion_activa_sugerida",
    ]
    datos = pd.DataFrame(relaciones, columns=columnas)
    datos["Direccion_filtro"] = "Única, dimensión hacia hechos"
    return datos


def construir_tablas_power_bi(
    config: ConfiguracionModelo,
    matrices_por_modelo: dict[str, MatricesTransicion],
    potencias: pd.DataFrame,
    resultados: pd.DataFrame,
    datos_conteos: pd.DataFrame,
    auditoria_conteos: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    cobertura_finca: pd.DataFrame,
    calendario: pd.DataFrame,
    estadisticas_fenologia: pd.DataFrame,
    ingresos_diarios: pd.DataFrame,
    ingresos_semanales: pd.DataFrame,
    ingresos_intervalos: pd.DataFrame,
    auditoria_fenologia: pd.DataFrame,
) -> tuple[str, dict[str, str], dict[str, pd.DataFrame]]:
    ejecucion_id, modelos_id = crear_ids_modelo(
        config, matrices_por_modelo, estadisticas_fenologia
    )
    fact_diaria = construir_fact_diaria(resultados, ejecucion_id, modelos_id)
    fact_semanal = construir_fact_semanal(resultados, ejecucion_id, modelos_id)
    fact_sensibilidad_ingresos = construir_fact_sensibilidad_ingresos(fact_semanal)
    control_ingresos = construir_control_ingresos(fact_sensibilidad_ingresos)
    control_extrapolacion = construir_control_extrapolacion(fact_semanal)
    fact_conteos = construir_fact_conteos(
        auditoria_conteos, extrapolacion, ejecucion_id, modelos_id
    )
    fact_extrapolacion = construir_fact_extrapolacion(
        extrapolacion, ejecucion_id, modelos_id
    )
    fact_cobertura_finca = construir_fact_cobertura_finca(
        cobertura_finca, ejecucion_id, modelos_id
    )
    fact_ingreso_diario = _agregar_claves_ingreso(
        ingresos_diarios, "DIARIO", ejecucion_id, modelos_id
    )
    fact_ingreso_semanal = _agregar_claves_ingreso(
        ingresos_semanales, "SEMANAL", ejecucion_id, modelos_id
    )
    fact_ingreso_intervalo = _agregar_claves_ingreso(
        ingresos_intervalos, "INTERVALO", ejecucion_id, modelos_id
    )
    dim_fecha = construir_dim_fecha(
        calendario, resultados, ingresos_diarios, auditoria_fenologia
    )
    matriz_q, vectores = construir_matrices(matrices_por_modelo, modelos_id)
    dim_modelo = construir_dim_modelo(
        config, ejecucion_id, modelos_id, estadisticas_fenologia
    )
    control_fenologia = construir_control_fenologia(
        auditoria_fenologia, ejecucion_id, modelos_id
    )
    tablas = {
        "Fact_Diaria": fact_diaria,
        "Fact_Semanal": fact_semanal,
        "Fact_Sensibilidad_Ingresos": fact_sensibilidad_ingresos,
        "Fact_Conteos": fact_conteos,
        "Fact_Extrapolacion": fact_extrapolacion,
        "Fact_Cobertura_Finca": fact_cobertura_finca,
        "Dim_Fecha": dim_fecha,
        "Dim_Semana": construir_dim_semana(dim_fecha),
        "Dim_Periodo": construir_dim_periodo(),
        "Dim_Finca": construir_dim_finca(datos_conteos),
        "Dim_Bloque": construir_dim_bloque(datos_conteos, resultados),
        "Dim_Modelo": dim_modelo,
        "Matriz_Q": matriz_q,
        "Vectores_r_p": vectores,
        "Potencias_Q": preparar_potencias(potencias, modelos_id),
        "Control_Fenologia": control_fenologia,
        "Control_Ingresos": control_ingresos,
        "Control_Extrapolacion": control_extrapolacion,
        "Control_Calidad": construir_control_calidad(
            auditoria_conteos,
            extrapolacion,
            fact_semanal,
            cobertura_finca,
            vectores,
            dim_modelo,
            control_fenologia,
            config.fecha_cambio_matriz,
        ),
        "Relaciones": construir_relaciones(),
    }
    return ejecucion_id, modelos_id, tablas

# ---------------------------------------------------------------------------
# Capa final V8. Estas funciones amplían el modelo sin alterar las funciones
# históricas anteriores, lo que conserva compatibilidad con integraciones.
# ---------------------------------------------------------------------------


def construir_fact_operacion_diaria(
    resultados: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    """Hecho diario operacional con bloques directos e imputados."""

    datos = resultados.copy()
    datos["Ejecucion_ID"] = ejecucion_id
    datos["Modelo_ID"] = datos["Modelo_clave"].map(modelos_id)
    if datos["Modelo_ID"].isna().any():
        raise ValueError("Hay proyecciones operacionales sin Modelo_ID.")
    datos["Bloque_ID"] = [
        _bloque_id(f, b) for f, b in zip(datos["Finca"], datos["Bloque"])
    ]
    datos["Fecha_ID"] = datos["Fecha"].map(_fecha_id)
    datos["Fecha_conteo_ID"] = datos["Fecha_conteo"].map(_fecha_id)
    datos["Semana_ID"] = datos["Fecha"].map(_semana_id)
    datos["Semana_conteo_ID"] = datos["Fecha_conteo"].map(_semana_id)
    datos["Operacion_Diaria_ID"] = [
        f"{cid}|{fid}" for cid, fid in zip(datos["Conteo_ID"], datos["Fecha_ID"])
    ]
    claves = [
        "Operacion_Diaria_ID", "Ejecucion_ID", "Modelo_ID", "Conteo_ID",
        "Modelo_clave", "Periodo_modelo", "Bloque_ID", "Fecha_ID",
        "Fecha_conteo_ID", "Semana_ID", "Semana_conteo_ID", "Finca",
        "Bloque", "Fecha", "Fecha_conteo", "Horizonte_dias", "Orden_dia",
    ]
    excluir = {"Semana_conteo", "Semana_proyectada", "Dia_semana", *claves}
    obsoletas = {
        c for c in datos.columns
        if "LS3" in c
        or "real_estimado" in c.lower()
        or "historial_ingreso" in c.lower()
        or c in {
            "Ventana_ingreso_real_completa",
            "Dias_con_ingreso_real_ventana",
            "Ingreso_real_estimado_disponible",
            "Desviacion_ingreso_muestra",
            "Error_absoluto_ingreso_pct",
            "Fecha_ultima_disponibilidad_ingreso",
        }
    }
    datos = datos.drop(columns=list(obsoletas), errors="ignore")
    if "Metodo_pronostico_ingreso" in datos.columns:
        datos.loc[datos["Bloque_muestreado"].fillna(False), "Metodo_pronostico_ingreso"] = (
            "FIJO_PORCENTAJE_RC_CONTEO"
        )
    metricas = [c for c in datos.columns if c not in excluir]
    return datos[claves + metricas].sort_values(
        ["Finca", "Bloque", "Fecha_conteo", "Fecha"]
    ).reset_index(drop=True)


def construir_fact_operacion_semanal(
    resultados: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    """Una fila operacional por finca, bloque y semana de origen."""

    filas: list[dict[str, object]] = []
    for conteo_id, grupo in resultados.groupby("Conteo_ID", sort=True):
        grupo = grupo.sort_values("Fecha")
        primera = grupo.iloc[0]
        inicio = pd.Timestamp(grupo["Fecha"].min())
        fin = pd.Timestamp(grupo["Fecha"].max())
        fecha_conteo = pd.Timestamp(primera["Fecha_conteo"])
        evaluable = bool(grupo["Ventana_evaluable"].all() and len(grupo) == 7)
        real_parcial = grupo["Corte_real_bloque"].sum(min_count=1)
        real = float(real_parcial) if evaluable else np.nan
        proyectado = float(grupo["Corte_proyectado_bloque"].sum())
        simple_col = "Corte_proyectado_media_simple_sensibilidad_bloque"
        median_col = "Corte_proyectado_mediana_sensibilidad_bloque"
        simple = (
            float(grupo[simple_col].sum(min_count=1))
            if simple_col in grupo.columns and grupo[simple_col].notna().any()
            else proyectado
        )
        median = (
            float(grupo[median_col].sum(min_count=1))
            if median_col in grupo.columns and grupo[median_col].notna().any()
            else proyectado
        )
        def err(pred):
            return abs(pred - real) if pd.notna(real) else np.nan
        modelo_clave = str(primera["Modelo_clave"])
        tipo = str(primera.get("Tipo_proyeccion", "BLOQUE_MUESTREADO"))
        filas.append(
            {
                "Operacion_Semanal_ID": f"{conteo_id}|{_semana_id(inicio)}",
                "Ejecucion_ID": ejecucion_id,
                "Modelo_ID": modelos_id[modelo_clave],
                "Modelo_clave": modelo_clave,
                "Periodo_modelo": primera["Periodo_modelo"],
                "Conteo_ID": conteo_id,
                "Bloque_ID": _bloque_id(primera["Finca"], primera["Bloque"]),
                "Finca": primera["Finca"],
                "Bloque": primera["Bloque"],
                "Fecha_conteo_ID": _fecha_id(fecha_conteo),
                "Fecha_inicio_ID": _fecha_id(inicio),
                "Semana_ID": _semana_id(inicio),
                "Semana_conteo_ID": _semana_id(fecha_conteo),
                "Fecha_conteo": fecha_conteo,
                "Fecha_inicio_semana": inicio,
                "Fecha_fin_semana": fin,
                "Tipo_proyeccion": tipo,
                "Bloque_muestreado": bool(primera.get("Bloque_muestreado", True)),
                "Pronostico_markov_directo": tipo == "BLOQUE_MUESTREADO",
                "Metodo_estimacion_bloque": primera.get("Metodo_estimacion_bloque", ""),
                "Camas_totales_activas": float(primera["Camas_totales_activas"]),
                "Camas_muestreadas": float(primera.get("Camas_muestreadas", 0.0)),
                "Cobertura_camas_pct": primera.get("Cobertura_camas_pct", np.nan),
                "N_bloques_activos_semana": primera.get("N_bloques_activos_semana", np.nan),
                "N_bloques_muestreados_semana": primera.get("N_bloques_muestreados_semana", np.nan),
                "N_bloques_no_muestreados_semana": primera.get("N_bloques_no_muestreados_semana", np.nan),
                "Corte_proyectado_bloque": proyectado,
                "Corte_proyectado_media_simple_sensibilidad_bloque": simple,
                "Corte_proyectado_mediana_sensibilidad_bloque": median,
                "Corte_real_parcial_bloque": float(real_parcial) if pd.notna(real_parcial) else np.nan,
                "Corte_real_bloque": real,
                "Desviacion_tallos": proyectado - real if pd.notna(real) else np.nan,
                "Error_absoluto_tallos": err(proyectado),
                "Error_absoluto_media_simple_sensibilidad": err(simple),
                "Error_absoluto_mediana_sensibilidad": err(median),
                "Ventana_evaluable": evaluable,
                "Tipo_evaluacion_ventana": primera["Tipo_evaluacion_ventana"],
                "Dias_con_corte_real": int(grupo["Corte_real_disponible"].sum()),
                "Dias_faltantes_corte": int(7 - grupo["Corte_real_disponible"].sum()),
            }
        )
    return pd.DataFrame(filas).sort_values(
        ["Finca", "Bloque", "Fecha_conteo"]
    ).reset_index(drop=True)


def construir_control_imputacion(fact_operacion: pd.DataFrame) -> pd.DataFrame:
    """Compara métodos de imputación únicamente en bloques sin conteo."""

    imp = fact_operacion.loc[
        (~fact_operacion["Bloque_muestreado"]) & fact_operacion["Ventana_evaluable"]
    ].copy()
    filas: list[dict[str, object]] = []
    for alcance, grupo in [("TOTAL", imp), *[
        (finca, imp.loc[imp["Finca"].eq(finca)])
        for finca in sorted(imp["Finca"].dropna().unique())
    ]]:
        if grupo.empty:
            continue
        den = float(grupo["Corte_real_bloque"].abs().sum())
        for metodo, col in (
            ("PONDERADA_POR_CAMAS_OFICIAL", "Error_absoluto_tallos"),
            ("MEDIA_SIMPLE_TASA_POR_CAMA_SENSIBILIDAD", "Error_absoluto_media_simple_sensibilidad"),
            ("MEDIANA_TASA_POR_CAMA_SENSIBILIDAD", "Error_absoluto_mediana_sensibilidad"),
        ):
            filas.append(
                {
                    "Alcance": alcance,
                    "Metodo_imputacion": metodo,
                    "N_bloques_semana_evaluables": int(len(grupo)),
                    "WAPE": float(grupo[col].sum() / den) if den else np.nan,
                    "Uso_oficial": metodo == "PONDERADA_POR_CAMAS_OFICIAL",
                }
            )
    return pd.DataFrame(filas)


def _agregar_modelo_id_tabla(
    df: pd.DataFrame,
    ejecucion_id: str,
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    salida = df.copy()
    salida["Ejecucion_ID"] = ejecucion_id
    salida["Modelo_ID"] = salida["Modelo_clave"].map(modelos_id)
    cols = ["Ejecucion_ID", "Modelo_ID", "Modelo_clave", "Periodo_modelo", "Finca"]
    restantes = [c for c in salida.columns if c not in cols]
    return salida[cols + restantes].reset_index(drop=True)


def construir_control_calidad_final(
    auditoria: pd.DataFrame,
    auditoria_causal: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    fact_semanal: pd.DataFrame,
    fact_causal: pd.DataFrame,
    fact_operacion: pd.DataFrame,
    cobertura_finca: pd.DataFrame,
    vectores: pd.DataFrame,
    dim_modelo: pd.DataFrame,
    ingresos_intervalos: pd.DataFrame,
    transiciones: pd.DataFrame,
) -> pd.DataFrame:
    """Controles duros que deben revisarse antes de cargar Power BI."""

    seleccionados = int(auditoria["Conteo_seleccionado"].sum())
    evals = int(fact_semanal["Ventana_evaluable"].sum())
    faltantes = int(fact_semanal["Tipo_evaluacion_ventana"].eq("NO_EVALUABLE").sum())
    futuras = int(fact_semanal["Tipo_evaluacion_ventana"].eq("FUTURA").sum())
    imp = fact_operacion.loc[~fact_operacion["Bloque_muestreado"]]
    retro_no_causal = int(
        fact_semanal.loc[fact_semanal["Ventana_evaluable"], "Matriz_disponible_fecha_conteo"]
        .eq(False).sum()
    )
    ingreso_fijo_ok = bool(
        fact_semanal["Metodo_pronostico_ingreso"]
        .eq("FIJO_PORCENTAJE_RC_CONTEO")
        .all()
    )
    porcentajes_config = pd.to_numeric(
        dim_modelo["Porcentaje_ingreso_RC_diario"], errors="coerce"
    ).dropna().unique()
    porcentaje_esperado = float(porcentajes_config[0]) if len(porcentajes_config) == 1 else np.nan
    porcentaje_observado = pd.to_numeric(
        fact_semanal["Ingreso_pronosticado_pct_RC_dia"], errors="coerce"
    )
    mascara_pct = porcentaje_observado.notna()
    desviacion_pct_ingreso = (
        float((porcentaje_observado.loc[mascara_pct] - porcentaje_esperado).abs().max())
        if mascara_pct.any() and pd.notna(porcentaje_esperado)
        else 0.0
    )
    anomal = int(
        transiciones["Tipo_transicion"].isin(
            ["RETROCESO", "SALTO_ADELANTE", "SALIDA_DESDE_TERMINAL"]
        ).sum()
    ) if not transiciones.empty else 0
    controles = [
        ("CONTEOS", "Conteos recibidos", len(auditoria), "OK", ""),
        ("CONTEOS", "Pronósticos directos seleccionados", seleccionados, "OK", "Una fila de origen por bloque y semana; el valor depende de los insumos"),
        ("EVALUACION", "Ventanas directas evaluables", evals, "OK", "Exige 7 cortes reales en la semana objetivo; el valor depende de los insumos"),
        ("EVALUACION", "Ventanas con corte diario faltante", faltantes, "CONTROL", "Quedan fuera de WAPE y MAE"),
        ("EVALUACION", "Ventanas futuras", futuras, "CONTROL", "Sin corte real aún"),
        ("EVALUACION", "Semanas calendario objetivo", fact_semanal["Semana_ID"].nunique(), "OK", "Semanas ISO distintas"),
        ("OPERACION", "Bloques-semana imputados", int(len(imp)), "CONTROL", "Fuera de la evaluación Markov"),
        ("OPERACION", "Imputaciones sin Semana_conteo_ID", int(imp["Semana_conteo_ID"].isna().sum()), "OK" if not imp["Semana_conteo_ID"].isna().any() else "ERROR", "Debe ser cero"),
        ("EXTRAPOLACION", "Factores fijados en 1", int(extrapolacion["Factor_ajustado"].sum()), "CONTROL", "Muestreo supera camas activas"),
        ("MATRICES", "Matrices generadas", len(dim_modelo), "OK", "Una matriz por finca y periodo disponible"),
        ("MATRICES", "Columnas Q+r+p válidas", int(vectores["Control_suma_uno"].sum()), "OK" if vectores["Control_suma_uno"].all() else "ERROR", f"{len(vectores)} columnas"),
        ("CAUSALIDAD", "Ventanas evaluables retrospectivas no causales", retro_no_causal, "CONTROL", "La matriz contiene observaciones fenológicas posteriores al conteo"),
        ("CAUSALIDAD", "Pronósticos del backtest causal", len(fact_causal), "OK", "Usa la última matriz disponible en la fecha"),
        ("CAUSALIDAD", "Ventanas evaluables del backtest causal", int(fact_causal["Ventana_evaluable"].sum()), "OK", "Universo honesto de validación temporal"),
        ("INGRESOS", "Pronósticos con método de ingreso fijo", int(fact_semanal["Metodo_pronostico_ingreso"].eq("FIJO_PORCENTAJE_RC_CONTEO").sum()), "OK" if ingreso_fijo_ok else "ERROR", "Todos los pronósticos deben usar b = alpha * RC del conteo"),
        ("INGRESOS", "Desviación máxima del porcentaje fijo", desviacion_pct_ingreso, "OK" if desviacion_pct_ingreso <= 1e-12 else "ERROR", f"Porcentaje configurado: {porcentaje_esperado:.6f}" if pd.notna(porcentaje_esperado) else "Configuración ambigua"),
        ("FENOLOGIA", "Transiciones anómalas", anomal, "CONTROL" if anomal else "OK", "Retrocesos, saltos o salidas desde terminal"),
        ("FENOLOGIA", "Matrices con 30 tallos", int((dim_modelo["N_tallos_fenologia"] == 30).sum()), "CONTROL", "Tamaño muestral limitado, interpretar incertidumbre"),
    ]
    return pd.DataFrame([
        {"Control_ID": i, "Categoria": c, "Metrica": m, "Valor": float(v), "Estado": e, "Detalle": d}
        for i, (c, m, v, e, d) in enumerate(controles, 1)
    ])


def construir_relaciones_final() -> pd.DataFrame:
    """Relaciones sugeridas para el tablero definitivo."""

    hechos_bloque = [
        "Fact_Diaria", "Fact_Semanal", "Fact_Backtest_Causal",
        "Fact_Benchmark", "Fact_Operacion_Diaria", "Fact_Operacion_Semanal",
        "Fact_Conteos", "Fact_Extrapolacion", "Fact_Sensibilidad_Ingresos",
    ]
    relaciones: list[tuple] = []
    for tabla in hechos_bloque:
        relaciones.append(("Dim_Bloque", "Bloque_ID", tabla, "Bloque_ID", "1:*", True))
        relaciones.append(("Dim_Modelo", "Modelo_ID", tabla, "Modelo_ID", "1:*", False))
    relaciones.extend([
        ("Dim_Finca", "Finca", "Dim_Bloque", "Finca", "1:*", True),
        ("Dim_Finca", "Finca", "Dim_Modelo", "Finca", "1:*", True),
        ("Dim_Finca", "Finca", "Fact_Cobertura_Finca", "Finca", "1:*", True),
        ("Dim_Semana", "Semana_ID", "Fact_Cobertura_Finca", "Semana_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Fact_Cobertura_Finca", "Modelo_ID", "1:*", False),
        ("Dim_Modelo", "Modelo_ID", "Matriz_Q", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Vectores_r_p", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Potencias_Q", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Grupos_Duracion", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Probabilidades_Grupo", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Clasificacion_Tallos", "Modelo_ID", "1:*", True),
        ("Dim_Modelo", "Modelo_ID", "Transiciones_Fenologia", "Modelo_ID", "1:*", True),
    ])
    fecha_activa = {
        "Fact_Diaria": "Fecha_ID",
        "Fact_Semanal": "Fecha_inicio_ID",
        "Fact_Backtest_Causal": "Fecha_inicio_ID",
        "Fact_Benchmark": "Fecha_inicio_ID",
        "Fact_Operacion_Diaria": "Fecha_ID",
        "Fact_Operacion_Semanal": "Fecha_inicio_ID",
        "Fact_Conteos": "Fecha_ID",
        "Fact_Extrapolacion": "Fecha_conteo_ID",
        "Fact_Sensibilidad_Ingresos": "Fecha_inicio_ID",
    }
    semana_activa = {
        "Fact_Diaria": "Semana_ID", "Fact_Semanal": "Semana_ID",
        "Fact_Backtest_Causal": "Semana_ID", "Fact_Benchmark": "Semana_ID",
        "Fact_Operacion_Diaria": "Semana_ID", "Fact_Operacion_Semanal": "Semana_ID",
        "Fact_Conteos": "Semana_ID", "Fact_Extrapolacion": "Semana_ID",
        "Fact_Sensibilidad_Ingresos": "Semana_ID",
    }
    for tabla, campo in fecha_activa.items():
        relaciones.append(("Dim_Fecha", "Fecha_ID", tabla, campo, "1:*", True))
    for tabla, campo in semana_activa.items():
        relaciones.append(("Dim_Semana", "Semana_ID", tabla, campo, "1:*", True))

    # Periodo_modelo es una dimensión independiente. Evita depender de la
    # relación inactiva Dim_Modelo -> hechos para filtrar ABRIL/JULIO.
    for tabla in hechos_bloque + ["Fact_Cobertura_Finca"]:
        relaciones.append(("Dim_Periodo", "Periodo_modelo", tabla, "Periodo_modelo", "1:*", True))
    cols = ["Tabla_dimension", "Campo_dimension", "Tabla_hechos", "Campo_hechos", "Cardinalidad", "Relacion_activa_sugerida"]
    out = pd.DataFrame(relaciones, columns=cols)
    out["Direccion_filtro"] = "Única, dimensión hacia hechos"
    return out.drop_duplicates().reset_index(drop=True)



def construir_control_matrices(
    matrices_por_modelo: dict[str, MatricesTransicion],
    modelos_id: dict[str, str],
    estadisticas: pd.DataFrame,
    horizonte: int,
) -> pd.DataFrame:
    """Valida estocasticidad, no negatividad y convergencia de Q."""

    meta = estadisticas.set_index("Modelo_clave")
    filas: list[dict[str, object]] = []
    for clave, matriz in sorted(matrices_por_modelo.items()):
        eig = np.linalg.eigvals(matriz.Q)
        radio = float(np.max(np.abs(eig)))
        qh = np.linalg.matrix_power(matriz.Q, horizonte)
        sumas = matriz.Q.sum(axis=0) + matriz.r.ravel() + matriz.p.ravel()
        prob_absorbida = 1.0 - qh.sum(axis=0)
        fila_meta = meta.loc[clave]
        filas.append(
            {
                "Modelo_ID": modelos_id[clave],
                "Modelo_clave": clave,
                "Periodo_modelo": fila_meta["Periodo_modelo"],
                "Finca": fila_meta["Finca"],
                "Metodo_matriz": fila_meta["Metodo_matriz"],
                "Probabilidad_minima": float(
                    min(matriz.Q.min(), matriz.r.min(), matriz.p.min())
                ),
                "Desviacion_max_suma_columna": float(np.max(np.abs(sumas - 1.0))),
                "Radio_espectral_Q": radio,
                "Converge_Q": bool(radio < 1.0),
                "Max_abs_Q_horizonte": float(np.max(np.abs(qh))),
                "Horizonte_control": int(horizonte),
                "Prob_absorcion_min_horizonte": float(np.min(prob_absorbida)),
                "Prob_absorcion_max_horizonte": float(np.max(prob_absorbida)),
            }
        )
    return pd.DataFrame(filas)


def construir_control_duracion_estados(
    probabilidades: pd.DataFrame,
    matrices_por_modelo: dict[str, MatricesTransicion],
    modelos_id: dict[str, str],
) -> pd.DataFrame:
    """Compara duración observada con la duración implícita del Q consolidado."""

    filas: list[dict[str, object]] = []
    for (clave, estado), grupo in probabilidades.groupby(
        ["Modelo_clave", "Estado"], sort=True
    ):
        episodios = float(grupo["N_episodios_estado"].sum())
        exposiciones = float(grupo["Exposiciones_dia"].sum())
        observado = exposiciones / episodios if episodios else np.nan
        idx = ESTADOS.index(estado)
        permanecer = float(matrices_por_modelo[clave].Q[idx, idx])
        implicito = 1.0 / (1.0 - permanecer) if permanecer < 1.0 else np.inf
        periodo, finca = clave.split("|", 1)
        filas.append(
            {
                "Modelo_ID": modelos_id[clave],
                "Modelo_clave": clave,
                "Periodo_modelo": periodo,
                "Finca": finca,
                "Estado": estado,
                "N_episodios_estado": int(episodios),
                "Exposiciones_dia": int(exposiciones),
                "Duracion_observada_media_dias": observado,
                "P_permanecer_consolidada": permanecer,
                "Duracion_geometrica_implicita_dias": implicito,
                "Diferencia_dias": implicito - observado if pd.notna(observado) else np.nan,
            }
        )
    return pd.DataFrame(filas)


def construir_control_ingreso_diagnostico(
    fact_semanal: pd.DataFrame,
    intervalos: pd.DataFrame,
) -> pd.DataFrame:
    """Resume la magnitud de ingresos y residuales de reconstrucción."""

    filas: list[dict[str, object]] = []
    for alcance in ["TOTAL", *sorted(fact_semanal["Finca"].dropna().unique())]:
        fs = fact_semanal if alcance == "TOTAL" else fact_semanal.loc[fact_semanal["Finca"].eq(alcance)]
        ints = intervalos if alcance == "TOTAL" else intervalos.loc[intervalos["Finca"].eq(alcance)]
        ev = fs.loc[fs["Ventana_evaluable"]]
        aporte = float(ev["Aporte_ingresos_corte_bloque"].sum())
        proy = float(ev["Corte_proyectado_bloque"].sum())
        filas.append(
            {
                "Alcance": alcance,
                "N_intervalos_historicos": int(len(ints)),
                "Pct_ingresos_negativos_truncados": float(ints["Ingreso_negativo_truncado"].mean()) if len(ints) else np.nan,
                "Residual_RC_medio_por_cama": float(ints["Residual_conteo_RC_por_cama"].mean()) if len(ints) else np.nan,
                "Residual_SS_medio_por_cama": float(ints["Residual_conteo_SS_por_cama"].mean()) if len(ints) else np.nan,
                "Residual_AP_medio_por_cama": float(ints["Residual_conteo_AP_por_cama"].mean()) if len(ints) else np.nan,
                "Pct_residual_SS_negativo": float(ints["Residual_conteo_SS_por_cama"].lt(0).mean()) if len(ints) else np.nan,
                "Pct_residual_AP_negativo": float(ints["Residual_conteo_AP_por_cama"].lt(0).mean()) if len(ints) else np.nan,
                "N_pronosticos_prior_20pct": int(fs["Metodo_pronostico_ingreso"].eq("PRIOR_PORCENTAJE_RC").sum()),
                "N_ingreso_dia_supera_RC_conteo": int(fs["Ingreso_pronosticado_pct_RC_dia"].gt(1).sum()),
                "Aporte_ingresos_pct_corte_evaluable": aporte / proy if proy else np.nan,
            }
        )
    return pd.DataFrame(filas)


def construir_control_cobertura_error(fact_semanal: pd.DataFrame) -> pd.DataFrame:
    """Evalúa error por bandas de cobertura de camas dentro del bloque."""

    datos = fact_semanal.loc[fact_semanal["Ventana_evaluable"]].copy()
    datos["Cobertura_muestra_bloque_pct"] = (
        datos["Camas_muestreadas"] / datos["Camas_totales_activas"]
    )
    bins = [-np.inf, 0.10, 0.25, 0.50, 0.75, np.inf]
    labels = ["<=10%", "10-25%", "25-50%", "50-75%", ">75%"]
    datos["Banda_cobertura"] = pd.cut(
        datos["Cobertura_muestra_bloque_pct"], bins=bins, labels=labels,
        include_lowest=True,
    )
    filas: list[dict[str, object]] = []
    for banda, grupo in datos.groupby("Banda_cobertura", observed=True, sort=False):
        den = float(grupo["Corte_real_bloque"].abs().sum())
        error = grupo["Corte_proyectado_bloque"] - grupo["Corte_real_bloque"]
        filas.append(
            {
                "Banda_cobertura": str(banda),
                "N_ventanas": int(len(grupo)),
                "Cobertura_media_pct": float(grupo["Cobertura_muestra_bloque_pct"].mean()),
                "WAPE": float(error.abs().sum() / den) if den else np.nan,
                "Sesgo_pct": float(error.sum() / den) if den else np.nan,
            }
        )
    return pd.DataFrame(filas)


def construir_tablas_power_bi(
    config: ConfiguracionModelo,
    matrices_por_modelo: dict[str, MatricesTransicion],
    potencias: pd.DataFrame,
    resultados: pd.DataFrame,
    resultados_operacionales: pd.DataFrame,
    resultados_causales: pd.DataFrame,
    datos_conteos: pd.DataFrame,
    auditoria_conteos: pd.DataFrame,
    auditoria_causal: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    cobertura_finca: pd.DataFrame,
    calendario: pd.DataFrame,
    estadisticas_fenologia: pd.DataFrame,
    ingresos_diarios: pd.DataFrame,
    ingresos_semanales: pd.DataFrame,
    ingresos_intervalos: pd.DataFrame,
    auditoria_fenologia: pd.DataFrame,
    grupos_duracion: pd.DataFrame,
    probabilidades_grupo: pd.DataFrame,
    clasificaciones_tallos: pd.DataFrame,
    transiciones_fenologia: pd.DataFrame,
) -> tuple[str, dict[str, str], dict[str, pd.DataFrame]]:
    """Construye el modelo tabular definitivo para Power BI."""

    ejecucion_id, modelos_id = crear_ids_modelo(
        config, matrices_por_modelo, estadisticas_fenologia
    )
    fact_diaria = construir_fact_diaria(resultados, ejecucion_id, modelos_id)
    fact_semanal = construir_fact_semanal(resultados, ejecucion_id, modelos_id)
    fact_diaria = enriquecer_causalidad_matriz(fact_diaria, estadisticas_fenologia)
    fact_semanal = enriquecer_causalidad_matriz(fact_semanal, estadisticas_fenologia)

    fact_causal = construir_fact_semanal(resultados_causales, ejecucion_id, modelos_id)
    fact_causal = enriquecer_causalidad_matriz(fact_causal, estadisticas_fenologia)
    fact_causal["Escenario_backtest"] = "CAUSAL_ULTIMA_MATRIZ_DISPONIBLE"

    fact_operacion_diaria = construir_fact_operacion_diaria(
        resultados_operacionales, ejecucion_id, modelos_id
    )
    fact_operacion_semanal = construir_fact_operacion_semanal(
        resultados_operacionales, ejecucion_id, modelos_id
    )
    fact_operacion_diaria = enriquecer_causalidad_matriz(
        fact_operacion_diaria, estadisticas_fenologia
    )
    fact_operacion_semanal = enriquecer_causalidad_matriz(
        fact_operacion_semanal, estadisticas_fenologia
    )

    fact_sensibilidad_ingresos = construir_fact_sensibilidad_ingresos(fact_semanal)
    control_ingresos = construir_control_ingresos(fact_sensibilidad_ingresos)
    control_extrapolacion = construir_control_extrapolacion(fact_semanal)
    control_imputacion = construir_control_imputacion(fact_operacion_semanal)

    fact_benchmark = construir_fact_benchmark(fact_semanal, datos_conteos)
    control_benchmark = construir_control_benchmark(fact_benchmark)
    control_causalidad = construir_control_causalidad(fact_semanal, fact_causal)
    control_matrices = construir_control_matrices(
        matrices_por_modelo, modelos_id, estadisticas_fenologia, config.horizonte_matriz
    )
    control_duracion = construir_control_duracion_estados(
        probabilidades_grupo, matrices_por_modelo, modelos_id
    )
    control_cobertura_error = construir_control_cobertura_error(fact_semanal)

    fact_conteos = construir_fact_conteos(
        auditoria_conteos, extrapolacion, ejecucion_id, modelos_id
    )
    fact_extrapolacion = construir_fact_extrapolacion(
        extrapolacion, ejecucion_id, modelos_id
    )
    fact_cobertura_finca = construir_fact_cobertura_finca(
        cobertura_finca, ejecucion_id, modelos_id
    )
    dim_fecha = construir_dim_fecha(
        calendario, resultados_operacionales, pd.DataFrame(), auditoria_fenologia
    )
    matriz_q, vectores = construir_matrices(matrices_por_modelo, modelos_id)
    dim_modelo = construir_dim_modelo(
        config, ejecucion_id, modelos_id, estadisticas_fenologia
    )
    # Sobrescribe metadatos obsoletos de versiones anteriores.
    dim_modelo["Metodologia_ID"] = METODO_MATRIZ
    dim_modelo["Metodologia"] = "M3 por grupos de duración, probabilidades por exposiciones diarias"
    dim_modelo["Version_salida"] = "9.0.0"
    dim_modelo["Metodo_extrapolacion_finca"] = "TASA_PONDERADA_CAMAS_BLOQUES_MUESTREADOS"
    mapa_disp = estadisticas_fenologia.set_index("Modelo_clave")["Fecha_disponibilidad_matriz"]
    mapa_ini = estadisticas_fenologia.set_index("Modelo_clave")["Fecha_inicio_fenologia"]
    mapa_fin = estadisticas_fenologia.set_index("Modelo_clave")["Fecha_fin_fenologia"]
    dim_modelo["Fecha_inicio_fenologia"] = dim_modelo["Modelo_clave"].map(mapa_ini)
    dim_modelo["Fecha_fin_fenologia"] = dim_modelo["Modelo_clave"].map(mapa_fin)
    dim_modelo["Fecha_disponibilidad_matriz"] = dim_modelo["Modelo_clave"].map(mapa_disp)
    dim_modelo["Advertencia_backtest"] = "Filtrar o consultar Control_Causalidad para validación temporal"

    control_fenologia = construir_control_fenologia(
        auditoria_fenologia, ejecucion_id, modelos_id
    )
    grupos = _agregar_modelo_id_tabla(grupos_duracion, ejecucion_id, modelos_id)
    probabilidades = _agregar_modelo_id_tabla(probabilidades_grupo, ejecucion_id, modelos_id)
    clasificacion = _agregar_modelo_id_tabla(clasificaciones_tallos, ejecucion_id, modelos_id)
    transiciones = _agregar_modelo_id_tabla(transiciones_fenologia, ejecucion_id, modelos_id)
    control_transiciones = construir_control_transiciones(transiciones_fenologia)
    if not control_transiciones.empty:
        control_transiciones = _agregar_modelo_id_tabla(
            control_transiciones, ejecucion_id, modelos_id
        )

    tablas = {
        "Fact_Diaria": fact_diaria,
        "Fact_Semanal": fact_semanal,
        "Fact_Backtest_Causal": fact_causal,
        "Fact_Benchmark": fact_benchmark,
        "Fact_Sensibilidad_Ingresos": fact_sensibilidad_ingresos,
        "Fact_Operacion_Diaria": fact_operacion_diaria,
        "Fact_Operacion_Semanal": fact_operacion_semanal,
        "Fact_Conteos": fact_conteos,
        "Fact_Extrapolacion": fact_extrapolacion,
        "Fact_Cobertura_Finca": fact_cobertura_finca,
        "Dim_Fecha": dim_fecha,
        "Dim_Semana": construir_dim_semana(dim_fecha),
        "Dim_Periodo": construir_dim_periodo(),
        "Dim_Finca": construir_dim_finca(datos_conteos),
        "Dim_Bloque": construir_dim_bloque(datos_conteos, resultados_operacionales),
        "Dim_Modelo": dim_modelo,
        "Matriz_Q": matriz_q,
        "Vectores_r_p": vectores,
        "Potencias_Q": preparar_potencias(potencias, modelos_id),
        "Grupos_Duracion": grupos,
        "Probabilidades_Grupo": probabilidades,
        "Clasificacion_Tallos": clasificacion,
        "Transiciones_Fenologia": transiciones,
        "Control_Fenologia": control_fenologia,
        "Control_Transiciones": control_transiciones,
        "Control_Ingresos": control_ingresos,
        "Control_Extrapolacion": control_extrapolacion,
        "Control_Imputacion": control_imputacion,
        "Control_Benchmark": control_benchmark,
        "Control_Causalidad": control_causalidad,
        "Control_Matrices": control_matrices,
        "Control_Duracion_Estados": control_duracion,
        "Control_Cobertura_Error": control_cobertura_error,
    }
    tablas["Control_Calidad"] = construir_control_calidad_final(
        auditoria_conteos, auditoria_causal, extrapolacion, fact_semanal,
        fact_causal, fact_operacion_semanal, cobertura_finca, vectores,
        dim_modelo, ingresos_intervalos, transiciones_fenologia,
    )
    tablas["Relaciones"] = construir_relaciones_final()
    return ejecucion_id, modelos_id, tablas
