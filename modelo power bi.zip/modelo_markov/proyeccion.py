"""Proyección diaria de conteos, ingresos, cortes y pérdidas."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .entradas import COLUMNAS_CONTEO
from .ingresos import VECTOR_ENTRADA_RC, pronosticar_tasa_ingreso
from .modelos import MatricesTransicion
from .vigencias import obtener_matriz


DIAS = ("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")


def etiqueta_semana(fecha: pd.Timestamp) -> str:
    iso = pd.Timestamp(fecha).isocalendar()
    return f"{int(iso.year)}-S{int(iso.week):02d}"


def _crear_mapas_reales(datos_conteos: pd.DataFrame) -> tuple[dict, dict, dict]:
    reales = (
        datos_conteos.groupby(["Finca", "Bloque", "Fecha"], as_index=False)[
            "Cantidad"
        ]
        .sum(min_count=1)
    )
    mapa_corte = {
        (fila.Finca, fila.Bloque, pd.Timestamp(fila.Fecha)): fila.Cantidad
        for fila in reales.itertuples(index=False)
    }
    max_fecha = {
        (finca, bloque): pd.Timestamp(grupo["Fecha"].max())
        for (finca, bloque), grupo in datos_conteos.groupby(["Finca", "Bloque"])
    }
    mascara = datos_conteos[list(COLUMNAS_CONTEO)].notna().all(axis=1)
    mapa_conteo = {}
    for fila in datos_conteos.loc[mascara].itertuples(index=False):
        mapa_conteo[(fila.Finca, fila.Bloque, pd.Timestamp(fila.Fecha))] = {
            "RC": float(fila.conteo_RC),
            "SS": float(fila.conteo_SS),
            "AP": float(fila.conteo_AP),
            "CO": float(fila.conteo_CO),
        }
    return mapa_corte, mapa_conteo, max_fecha


def _mapa_ingresos_reales(ingresos_diarios: pd.DataFrame | None) -> dict:
    if ingresos_diarios is None or ingresos_diarios.empty:
        return {}
    return {
        (fila.Finca, fila.Bloque, pd.Timestamp(fila.Fecha)): {
            "por_cama": float(fila.Ingreso_RC_estimado_por_cama_dia),
            "fecha_disponibilidad": pd.Timestamp(fila.Fecha_disponibilidad),
            "truncado": bool(fila.Ingreso_negativo_truncado),
        }
        for fila in ingresos_diarios.itertuples(index=False)
    }


def generar_resultados_diarios(
    datos_conteos: pd.DataFrame,
    auditoria_conteos: pd.DataFrame,
    extrapolacion: pd.DataFrame,
    matrices_por_modelo: dict[str, MatricesTransicion],
    ingresos_diarios: pd.DataFrame | None = None,
    ingresos_semanales: pd.DataFrame | None = None,
    ventana_ingresos_semanas: int = 4,
    porcentaje_ingreso_inicial: float = 0.0,
) -> pd.DataFrame:
    """Proyecta los siete días de la semana posterior a cada conteo."""

    origenes = auditoria_conteos.loc[
        auditoria_conteos["Conteo_seleccionado"]
    ].copy()
    origenes = origenes.merge(
        extrapolacion,
        on=["Conteo_ID", "Finca", "Bloque"],
        how="left",
        validate="one_to_one",
        suffixes=("", "_factor"),
    )
    if origenes["Factor_extrapolacion"].isna().any():
        raise ValueError("Falta extrapolación para uno o más conteos seleccionados.")

    mapa_corte, mapa_conteo, max_fecha = _crear_mapas_reales(datos_conteos)
    mapa_ingreso = _mapa_ingresos_reales(ingresos_diarios)
    historial = ingresos_semanales if ingresos_semanales is not None else pd.DataFrame()
    filas: list[dict[str, object]] = []

    for origen in origenes.itertuples(index=False):
        matriz = obtener_matriz(matrices_por_modelo, origen.Modelo_clave)
        Q = matriz.Q
        r = matriz.r.ravel()
        p = matriz.p.ravel()
        fecha_conteo = pd.Timestamp(origen.Fecha)
        inicio = pd.Timestamp(origen.Fecha_inicio_objetivo)
        fin = inicio + pd.Timedelta(days=6)
        fechas_objetivo = [inicio + pd.Timedelta(days=i) for i in range(7)]
        reales_ventana = [
            mapa_corte.get((origen.Finca, origen.Bloque, fecha), np.nan)
            for fecha in fechas_objetivo
        ]
        dias_con_real = sum(pd.notna(valor) for valor in reales_ventana)
        ventana_completa = bool(dias_con_real == 7)
        fecha_max_bloque = max_fecha[(origen.Finca, origen.Bloque)]
        if ventana_completa:
            tipo_evaluacion = "COMPLETA"
            motivo_no_evaluable = ""
        elif dias_con_real == 0 and inicio > fecha_max_bloque:
            tipo_evaluacion = "FUTURA"
            motivo_no_evaluable = "SEMANA_FUTURA_SIN_CORTES_REGISTRADOS"
        else:
            tipo_evaluacion = "NO_EVALUABLE"
            motivo_no_evaluable = "CORTE_DIARIO_FALTANTE"

        pronostico = pronosticar_tasa_ingreso(
            historial,
            finca=origen.Finca,
            bloque=origen.Bloque,
            fecha_conteo=fecha_conteo,
            conteo_rc=float(origen.conteo_RC),
            camas_muestreadas=float(origen.Camas_muestreadas),
            ventana_semanas=ventana_ingresos_semanas,
            porcentaje_inicial=porcentaje_ingreso_inicial,
        )
        ingreso_muestra = float(pronostico["Ingreso_RC_pronosticado_muestra"])
        ingreso_por_cama = float(
            pronostico["Ingreso_RC_pronosticado_por_cama"]
        )
        pronostico_ls3 = pronosticar_tasa_ingreso(
            historial,
            finca=origen.Finca,
            bloque=origen.Bloque,
            fecha_conteo=fecha_conteo,
            conteo_rc=float(origen.conteo_RC),
            camas_muestreadas=float(origen.Camas_muestreadas),
            ventana_semanas=ventana_ingresos_semanas,
            porcentaje_inicial=porcentaje_ingreso_inicial,
            columna_tasa="Ingreso_RC_estimado_LS3_por_cama_dia",
            sufijo_metodo="_LS3_AUDITORIA",
        )
        ingreso_ls3_muestra = float(
            pronostico_ls3["Ingreso_RC_pronosticado_muestra"]
        )
        ingreso_ls3_por_cama = float(
            pronostico_ls3["Ingreso_RC_pronosticado_por_cama"]
        )
        factor = float(origen.Factor_extrapolacion)
        estado = np.array(
            [origen.conteo_RC, origen.conteo_SS, origen.conteo_AP], dtype=float
        )
        estado_sin_ingresos = estado.copy()
        estado_ls3 = estado.copy()
        ingresos_reales_objetivo = [
            mapa_ingreso.get((origen.Finca, origen.Bloque, fecha))
            for fecha in fechas_objetivo
        ]
        dias_ingreso_real = sum(x is not None for x in ingresos_reales_objetivo)

        fecha = fecha_conteo + pd.Timedelta(days=1)
        while fecha <= fin:
            estado_pre_corte = estado.copy()
            estado_pre_corte_ls3 = estado_ls3.copy()
            corte_muestra = float(r @ estado_pre_corte)
            corte_ls3_muestra = float(r @ estado_pre_corte_ls3)
            perdida_muestra = float(p @ estado_pre_corte)
            corte_sin_ingresos = float(r @ estado_sin_ingresos)
            estado = Q @ estado_pre_corte + VECTOR_ENTRADA_RC * ingreso_muestra
            estado_ls3 = (
                Q @ estado_pre_corte_ls3
                + VECTOR_ENTRADA_RC * ingreso_ls3_muestra
            )
            estado_sin_ingresos = Q @ estado_sin_ingresos

            if fecha >= inicio:
                orden = int((fecha - inicio).days) + 1
                corte_real = mapa_corte.get(
                    (origen.Finca, origen.Bloque, fecha), np.nan
                )
                corte_real_disponible = bool(pd.notna(corte_real))
                desviacion_disponible = (
                    corte_muestra * factor - float(corte_real)
                    if corte_real_disponible
                    else np.nan
                )
                error_evaluable = (
                    desviacion_disponible if ventana_completa else np.nan
                )
                error_pct = (
                    abs(error_evaluable) / abs(float(corte_real))
                    if pd.notna(error_evaluable) and float(corte_real) != 0
                    else np.nan
                )
                conteo_real = mapa_conteo.get(
                    (origen.Finca, origen.Bloque, fecha)
                )
                rc_real = conteo_real["RC"] if conteo_real else np.nan
                ss_real = conteo_real["SS"] if conteo_real else np.nan
                ap_real = conteo_real["AP"] if conteo_real else np.nan
                co_real = conteo_real["CO"] if conteo_real else np.nan
                total_real = (
                    rc_real + ss_real + ap_real if conteo_real else np.nan
                )
                total_proyectado = float(estado.sum())
                desviacion_conteo = (
                    total_proyectado - total_real
                    if pd.notna(total_real)
                    else np.nan
                )
                error_conteo_pct = (
                    abs(desviacion_conteo) / abs(total_real)
                    if pd.notna(desviacion_conteo) and total_real != 0
                    else np.nan
                )
                ingreso_real = mapa_ingreso.get(
                    (origen.Finca, origen.Bloque, fecha)
                )
                ingreso_real_por_cama = (
                    ingreso_real["por_cama"] if ingreso_real else np.nan
                )
                ingreso_real_muestra = (
                    ingreso_real_por_cama * float(origen.Camas_muestreadas)
                    if pd.notna(ingreso_real_por_cama)
                    else np.nan
                )
                desviacion_ingreso = (
                    ingreso_muestra - ingreso_real_muestra
                    if pd.notna(ingreso_real_muestra)
                    else np.nan
                )
                error_ingreso_pct = (
                    abs(desviacion_ingreso) / abs(ingreso_real_muestra)
                    if pd.notna(desviacion_ingreso) and ingreso_real_muestra != 0
                    else np.nan
                )
                filas.append(
                    {
                        "Conteo_ID": origen.Conteo_ID,
                        "Modelo_clave": origen.Modelo_clave,
                        "Periodo_modelo": origen.Periodo_modelo,
                        "Finca": origen.Finca,
                        "Bloque": origen.Bloque,
                        "Semana_conteo": etiqueta_semana(fecha_conteo),
                        "Semana_proyectada": etiqueta_semana(inicio),
                        "Fecha_conteo": fecha_conteo,
                        "Fecha": fecha,
                        "Dia_semana": DIAS[orden - 1],
                        "Orden_dia": orden,
                        "Horizonte_dias": int((fecha - fecha_conteo).days),
                        "Conteo_RC": float(origen.conteo_RC),
                        "Conteo_SS": float(origen.conteo_SS),
                        "Conteo_AP": float(origen.conteo_AP),
                        "Conteo_CO": float(origen.conteo_CO),
                        "Camas_totales_activas": float(
                            origen.Camas_totales_activas
                        ),
                        "Camas_muestreadas": float(origen.Camas_muestreadas),
                        "Factor_extrapolacion_teorico": float(
                            origen.Factor_extrapolacion_teorico
                        ),
                        "Factor_extrapolacion": factor,
                        "Factor_ajustado": bool(origen.Factor_ajustado),
                        "Motivo_factor": origen.Motivo_factor,
                        "Ingreso_RC_pronosticado_por_cama": ingreso_por_cama,
                        "Ingreso_RC_pronosticado_muestra": ingreso_muestra,
                        "Ingreso_RC_pronosticado_bloque": ingreso_muestra * factor,
                        "Ingreso_RC_pronosticado_LS3_por_cama": ingreso_ls3_por_cama,
                        "Ingreso_RC_pronosticado_LS3_muestra": ingreso_ls3_muestra,
                        "Ingreso_RC_pronosticado_LS3_bloque": ingreso_ls3_muestra * factor,
                        "Metodo_pronostico_ingreso_LS3": pronostico_ls3[
                            "Metodo_pronostico_ingreso"
                        ],
                        "Ingreso_RC_real_estimado_por_cama": ingreso_real_por_cama,
                        "Ingreso_RC_real_estimado_muestra": ingreso_real_muestra,
                        "Ingreso_RC_real_estimado_bloque": (
                            ingreso_real_muestra * factor
                            if pd.notna(ingreso_real_muestra)
                            else np.nan
                        ),
                        "Desviacion_ingreso_muestra": desviacion_ingreso,
                        "Error_absoluto_ingreso_pct": error_ingreso_pct,
                        "Ingreso_real_estimado_disponible": bool(ingreso_real),
                        "Metodo_pronostico_ingreso": pronostico[
                            "Metodo_pronostico_ingreso"
                        ],
                        "N_semanas_historial_ingreso": int(
                            pronostico["N_semanas_historial_ingreso"]
                        ),
                        "N_dias_historial_ingreso": int(
                            pronostico["N_dias_historial_ingreso"]
                        ),
                        "Fecha_ultima_disponibilidad_ingreso": pronostico[
                            "Fecha_ultima_disponibilidad_ingreso"
                        ],
                        "Estado_RC_pre_corte_muestra": float(estado_pre_corte[0]),
                        "Estado_SS_pre_corte_muestra": float(estado_pre_corte[1]),
                        "Estado_AP_pre_corte_muestra": float(estado_pre_corte[2]),
                        "Conteo_RC_proyectado_muestra": float(estado[0]),
                        "Conteo_SS_proyectado_muestra": float(estado[1]),
                        "Conteo_AP_proyectado_muestra": float(estado[2]),
                        "Conteo_total_proyectado_muestra": total_proyectado,
                        "Conteo_RC_proyectado_bloque": float(estado[0]) * factor,
                        "Conteo_SS_proyectado_bloque": float(estado[1]) * factor,
                        "Conteo_AP_proyectado_bloque": float(estado[2]) * factor,
                        "Conteo_total_proyectado_bloque": total_proyectado * factor,
                        "Conteo_RC_sin_ingresos_muestra": float(
                            estado_sin_ingresos[0]
                        ),
                        "Conteo_SS_sin_ingresos_muestra": float(
                            estado_sin_ingresos[1]
                        ),
                        "Conteo_AP_sin_ingresos_muestra": float(
                            estado_sin_ingresos[2]
                        ),
                        "Conteo_RC_real_muestra": rc_real,
                        "Conteo_SS_real_muestra": ss_real,
                        "Conteo_AP_real_muestra": ap_real,
                        "Conteo_CO_real_muestra": co_real,
                        "Conteo_total_real_muestra": total_real,
                        "Desviacion_conteo_RC_muestra": (
                            float(estado[0]) - rc_real
                            if pd.notna(rc_real)
                            else np.nan
                        ),
                        "Desviacion_conteo_SS_muestra": (
                            float(estado[1]) - ss_real
                            if pd.notna(ss_real)
                            else np.nan
                        ),
                        "Desviacion_conteo_AP_muestra": (
                            float(estado[2]) - ap_real
                            if pd.notna(ap_real)
                            else np.nan
                        ),
                        "Desviacion_conteo_total_muestra": desviacion_conteo,
                        "Error_absoluto_conteo_total_pct": error_conteo_pct,
                        "Conteo_real_disponible": bool(conteo_real),
                        "Corte_proyectado_sin_ingresos_muestra": corte_sin_ingresos,
                        "Corte_proyectado_sin_ingresos_bloque": (
                            corte_sin_ingresos * factor
                        ),
                        "Corte_proyectado_muestra": corte_muestra,
                        "Corte_proyectado_bloque": corte_muestra * factor,
                        "Corte_proyectado_LS3_muestra": corte_ls3_muestra,
                        "Corte_proyectado_LS3_bloque": corte_ls3_muestra * factor,
                        "Aporte_ingresos_LS3_corte_bloque": (
                            (corte_ls3_muestra - corte_sin_ingresos) * factor
                        ),
                        "Aporte_ingresos_corte_muestra": (
                            corte_muestra - corte_sin_ingresos
                        ),
                        "Aporte_ingresos_corte_bloque": (
                            (corte_muestra - corte_sin_ingresos) * factor
                        ),
                        "Perdida_proyectada_muestra": perdida_muestra,
                        "Perdida_proyectada_bloque": perdida_muestra * factor,
                        "Corte_real_bloque": (
                            float(corte_real) if corte_real_disponible else np.nan
                        ),
                        "Corte_real_evaluable_bloque": (
                            float(corte_real)
                            if corte_real_disponible and ventana_completa
                            else np.nan
                        ),
                        "Desviacion_dia_disponible": desviacion_disponible,
                        "Error_tallos": error_evaluable,
                        "Error_pct": error_pct,
                        "Corte_real_disponible": corte_real_disponible,
                        "Ventana_evaluable": ventana_completa,
                        "Ventana_real_completa": ventana_completa,
                        "Dias_con_corte_real_ventana": dias_con_real,
                        "Dias_faltantes_corte_ventana": 7 - dias_con_real,
                        "Motivo_no_evaluable": motivo_no_evaluable,
                        "Ventana_ingreso_real_completa": bool(
                            dias_ingreso_real == 7
                        ),
                        "Dias_con_ingreso_real_ventana": dias_ingreso_real,
                        "Tipo_evaluacion_ventana": tipo_evaluacion,
                    }
                )
            fecha += pd.Timedelta(days=1)

    resultado = pd.DataFrame(filas)
    resultado["Tipo_proyeccion"] = "BLOQUE_MUESTREADO"
    resultado["Bloque_muestreado"] = True
    resultado["Metodo_estimacion_bloque"] = "MARKOV_MUESTRA_X_FACTOR_CAMAS"
    resultado["Metodo_pronostico_ingreso"] = "FIJO_PORCENTAJE_RC_CONTEO"
    resultado["N_semanas_historial_ingreso"] = 0
    resultado["N_dias_historial_ingreso"] = 0
    resultado["Fecha_ultima_disponibilidad_ingreso"] = pd.NaT
    return resultado.sort_values(
        ["Finca", "Bloque", "Fecha_conteo", "Fecha"]
    ).reset_index(drop=True)


def completar_bloques_no_muestreados(
    resultados_muestreados: pd.DataFrame,
    datos_conteos: pd.DataFrame,
    plano: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Completa la estimación operacional de finca para bloques sin conteo.

    Método oficial de segunda etapa:

        1. Cada bloque muestreado ya está extrapolado a bloque completo.
        2. Se suman las proyecciones de los bloques muestreados.
        3. Se divide esa suma por las camas activas totales de esos bloques.
        4. La tasa resultante se multiplica por las camas activas de cada bloque
           no muestreado.

    Esta es la formulación validada para finca: suma de tallos proyectados en
    bloques muestreados dividida por suma de camas activas de esos bloques.
    La media simple y la mediana de tasas por bloque se conservan únicamente
    como sensibilidad, nunca como método oficial.

    Las filas imputadas son operacionales. Nunca forman parte de Fact_Semanal,
    WAPE, MAE o sesgo del modelo Markov directo.
    """

    if resultados_muestreados.empty:
        return resultados_muestreados.copy(), pd.DataFrame()

    resultados = resultados_muestreados.copy()
    resultados["Semana_conteo_ID"] = resultados["Fecha_conteo"].map(
        lambda fecha: int(pd.Timestamp(fecha).isocalendar().year) * 100
        + int(pd.Timestamp(fecha).isocalendar().week)
    )

    mapa_corte, _, max_fecha = _crear_mapas_reales(datos_conteos)
    filas_imputadas: list[dict[str, object]] = []
    filas_cobertura: list[dict[str, object]] = []

    metricas_bloque = (
        "Ingreso_RC_pronosticado_bloque",
        "Conteo_RC_proyectado_bloque",
        "Conteo_SS_proyectado_bloque",
        "Conteo_AP_proyectado_bloque",
        "Conteo_total_proyectado_bloque",
        "Corte_proyectado_sin_ingresos_bloque",
        "Corte_proyectado_bloque",
        "Aporte_ingresos_corte_bloque",
        "Perdida_proyectada_bloque",
    )

    for (finca, semana_id), grupo_semana in resultados.groupby(
        ["Finca", "Semana_conteo_ID"], sort=True
    ):
        grupo_semana = grupo_semana.copy()
        bloques_muestreados = sorted(
            grupo_semana.loc[grupo_semana["Bloque_muestreado"], "Bloque"]
            .astype(str)
            .unique()
            .tolist()
        )
        if not bloques_muestreados:
            continue

        fechas_conteo = pd.to_datetime(grupo_semana["Fecha_conteo"])
        fecha_referencia = pd.Timestamp(fechas_conteo.max()).normalize()
        fechas_objetivo = sorted(
            pd.to_datetime(grupo_semana["Fecha"]).drop_duplicates().tolist()
        )
        if len(fechas_objetivo) != 7:
            raise ValueError(
                f"La finca {finca}, semana {semana_id}, no tiene siete días "
                "objetivo para completar bloques no muestreados."
            )

        activas = plano.loc[
            plano["Finca"].eq(finca)
            & plano["Fecha_siembra"].le(fecha_referencia)
            & plano["Fecha_erradicacion"].ge(fecha_referencia)
        ].copy()
        camas_por_bloque = (
            activas.groupby("Bloque")["Cama"].nunique().astype(float).to_dict()
        )
        bloques_activos = sorted(
            set(str(x) for x in camas_por_bloque) | set(bloques_muestreados)
        )
        no_muestreados = sorted(set(bloques_activos) - set(bloques_muestreados))

        camas_donantes_por_bloque = (
            grupo_semana.loc[grupo_semana["Bloque_muestreado"]]
            .drop_duplicates("Bloque")
            .set_index("Bloque")["Camas_totales_activas"]
            .astype(float)
        )
        camas_donantes = float(camas_donantes_por_bloque.sum())
        if camas_donantes <= 0:
            raise ValueError(
                f"No hay camas activas donantes para {finca}, semana {semana_id}."
            )

        camas_no_muestreadas = float(sum(camas_por_bloque[b] for b in no_muestreados))
        camas_total = camas_donantes + camas_no_muestreadas
        n_activos = len(bloques_activos)
        n_muestreados = len(bloques_muestreados)
        n_no_muestreados = len(no_muestreados)

        periodos = grupo_semana["Periodo_modelo"].dropna().astype(str).unique()
        modelos = grupo_semana["Modelo_clave"].dropna().astype(str).unique()
        if len(periodos) != 1 or len(modelos) != 1:
            raise ValueError(
                f"La finca {finca}, semana {semana_id}, mezcla matrices de "
                "vigencia y no se puede imputar de forma unívoca."
            )
        periodo = periodos[0]
        modelo_clave = modelos[0]

        # Tasa semanal oficial de finca. La fórmula validada pondera de forma
        # natural por camas activas: suma de proyección / suma de camas.
        # Media simple y mediana quedan como sensibilidad.
        sem_bloque = (
            grupo_semana.loc[grupo_semana["Bloque_muestreado"]]
            .groupby("Bloque", as_index=False)
            .agg(
                Corte_proyectado_bloque=("Corte_proyectado_bloque", "sum"),
                Camas=("Camas_totales_activas", "first"),
            )
        )
        sem_bloque["Tasa_corte_por_cama"] = (
            sem_bloque["Corte_proyectado_bloque"] / sem_bloque["Camas"]
        )
        tasa_semana_media_simple = float(sem_bloque["Tasa_corte_por_cama"].mean())
        tasa_semana_oficial = float(
            sem_bloque["Corte_proyectado_bloque"].sum() / sem_bloque["Camas"].sum()
        )
        tasa_semana_mediana = float(sem_bloque["Tasa_corte_por_cama"].median())
        proy_muestreados_semana = float(sem_bloque["Corte_proyectado_bloque"].sum())
        proy_no_muestreados_semana = tasa_semana_oficial * camas_no_muestreadas
        proy_no_muestreados_media = tasa_semana_media_simple * camas_no_muestreadas
        proy_no_muestreados_mediana = tasa_semana_mediana * camas_no_muestreadas

        filas_cobertura.append(
            {
                "Cobertura_ID": f"{finca}|{semana_id}",
                "Finca": finca,
                "Semana_conteo_ID": int(semana_id),
                "Semana_conteo": etiqueta_semana(fecha_referencia),
                "Fecha_referencia_conteo": fecha_referencia,
                "Fecha_inicio_proyeccion": pd.Timestamp(fechas_objetivo[0]),
                "Fecha_fin_proyeccion": pd.Timestamp(fechas_objetivo[-1]),
                "Periodo_modelo": periodo,
                "Modelo_clave": modelo_clave,
                "N_bloques_activos": n_activos,
                "N_bloques_muestreados": n_muestreados,
                "N_bloques_no_muestreados": n_no_muestreados,
                "Camas_activas_total": camas_total,
                "Camas_activas_bloques_muestreados": camas_donantes,
                "Camas_activas_bloques_no_muestreados": camas_no_muestreadas,
                "Cobertura_bloques_pct": n_muestreados / n_activos if n_activos else np.nan,
                "Cobertura_camas_pct": camas_donantes / camas_total if camas_total else np.nan,
                "Bloques_muestreados": ", ".join(bloques_muestreados),
                "Bloques_no_muestreados": ", ".join(no_muestreados),
                "Corte_proyectado_bloques_muestreados_semana": proy_muestreados_semana,
                "Tasa_corte_proyectado_semanal_por_cama": tasa_semana_oficial,
                "Tasa_corte_media_simple_sensibilidad": tasa_semana_media_simple,
                "Tasa_corte_mediana_sensibilidad": tasa_semana_mediana,
                "Corte_proyectado_bloques_no_muestreados_semana": proy_no_muestreados_semana,
                "Corte_proyectado_no_muestreados_media_simple_sensibilidad": proy_no_muestreados_media,
                "Corte_proyectado_no_muestreados_mediana_sensibilidad": proy_no_muestreados_mediana,
                "Corte_proyectado_finca_semana": proy_muestreados_semana + proy_no_muestreados_semana,
                "Corte_proyectado_finca_media_simple_sensibilidad": proy_muestreados_semana + proy_no_muestreados_media,
                "Corte_proyectado_finca_mediana_sensibilidad": proy_muestreados_semana + proy_no_muestreados_mediana,
                "Metodo_extrapolacion_finca": "TASA_PONDERADA_CAMAS_BLOQUES_MUESTREADOS",
            }
        )

        mascara_semana = (
            resultados["Finca"].eq(finca)
            & resultados["Semana_conteo_ID"].eq(semana_id)
        )
        resultados.loc[mascara_semana, "N_bloques_activos_semana"] = n_activos
        resultados.loc[mascara_semana, "N_bloques_muestreados_semana"] = n_muestreados
        resultados.loc[mascara_semana, "N_bloques_no_muestreados_semana"] = n_no_muestreados
        resultados.loc[mascara_semana, "Camas_activas_finca_semana"] = camas_total
        resultados.loc[mascara_semana, "Camas_activas_bloques_muestreados_semana"] = camas_donantes
        resultados.loc[mascara_semana, "Camas_activas_bloques_no_muestreados_semana"] = camas_no_muestreadas
        resultados.loc[mascara_semana, "Cobertura_camas_pct"] = (
            camas_donantes / camas_total if camas_total else np.nan
        )
        resultados.loc[mascara_semana, "Cobertura_bloques_pct"] = (
            n_muestreados / n_activos if n_activos else np.nan
        )

        if not no_muestreados:
            continue

        inicio = pd.Timestamp(fechas_objetivo[0])
        fechas_ventana = [inicio + pd.Timedelta(days=i) for i in range(7)]

        for fecha in fechas_objetivo:
            fecha = pd.Timestamp(fecha)
            grupo_dia = grupo_semana.loc[
                grupo_semana["Fecha"].eq(fecha) & grupo_semana["Bloque_muestreado"]
            ].copy()
            if grupo_dia.empty:
                raise ValueError(
                    f"No hay bloques donantes para {finca}, semana {semana_id}, "
                    f"fecha {fecha:%Y-%m-%d}."
                )

            # Tasa oficial diaria: suma de la métrica en bloques muestreados
            # dividida por la suma de camas activas de esos mismos bloques.
            camas_dia = float(grupo_dia["Camas_totales_activas"].astype(float).sum())
            if camas_dia <= 0:
                raise ValueError(
                    f"No hay camas donantes válidas para {finca}, semana {semana_id}, "
                    f"fecha {fecha:%Y-%m-%d}."
                )
            tasas: dict[str, float] = {}
            for metrica in metricas_bloque:
                tasas[metrica] = float(grupo_dia[metrica].astype(float).sum() / camas_dia)
            tasa_ingreso_por_cama = tasas["Ingreso_RC_pronosticado_bloque"]

            corte_tasas_bloque = (
                grupo_dia["Corte_proyectado_bloque"].astype(float)
                / grupo_dia["Camas_totales_activas"].astype(float)
            )
            tasa_corte_media_simple = float(corte_tasas_bloque.mean())
            tasa_corte_mediana = float(corte_tasas_bloque.median())

            for bloque in no_muestreados:
                camas_bloque = float(camas_por_bloque[bloque])
                corte_estimado = tasas["Corte_proyectado_bloque"] * camas_bloque
                reales_ventana = [
                    mapa_corte.get((finca, bloque, f), np.nan) for f in fechas_ventana
                ]
                dias_con_real = sum(pd.notna(v) for v in reales_ventana)
                ventana_completa = dias_con_real == 7
                fecha_max = max_fecha.get((finca, bloque))
                if ventana_completa:
                    tipo_evaluacion = "COMPLETA"
                    motivo_no_evaluable = ""
                elif fecha_max is None:
                    tipo_evaluacion = "NO_EVALUABLE"
                    motivo_no_evaluable = "SIN_HISTORICO_CORTE_BLOQUE"
                elif dias_con_real == 0 and inicio > pd.Timestamp(fecha_max):
                    tipo_evaluacion = "FUTURA"
                    motivo_no_evaluable = "SEMANA_FUTURA_SIN_CORTES_REGISTRADOS"
                else:
                    tipo_evaluacion = "NO_EVALUABLE"
                    motivo_no_evaluable = "CORTE_DIARIO_FALTANTE"

                corte_real = mapa_corte.get((finca, bloque, fecha), np.nan)
                corte_real_disponible = bool(pd.notna(corte_real))
                desviacion = (
                    corte_estimado - float(corte_real)
                    if corte_real_disponible
                    else np.nan
                )
                error_evaluable = desviacion if ventana_completa else np.nan
                error_pct = (
                    abs(error_evaluable) / abs(float(corte_real))
                    if pd.notna(error_evaluable) and float(corte_real) != 0
                    else np.nan
                )

                orden = int((fecha - inicio).days) + 1
                fila = {columna: np.nan for columna in resultados_muestreados.columns}
                fila.update(
                    {
                        "Conteo_ID": f"IMP|{finca}|{bloque}|{semana_id}",
                        "Modelo_clave": modelo_clave,
                        "Periodo_modelo": periodo,
                        "Finca": finca,
                        "Bloque": bloque,
                        "Semana_conteo_ID": int(semana_id),
                        "Semana_conteo": etiqueta_semana(fecha_referencia),
                        "Semana_proyectada": etiqueta_semana(inicio),
                        "Fecha_conteo": fecha_referencia,
                        "Fecha": fecha,
                        "Dia_semana": DIAS[orden - 1],
                        "Orden_dia": orden,
                        "Horizonte_dias": int((fecha - fecha_referencia).days),
                        "Camas_totales_activas": camas_bloque,
                        "Camas_muestreadas": 0.0,
                        "Factor_extrapolacion_teorico": np.nan,
                        "Factor_extrapolacion": np.nan,
                        "Factor_ajustado": False,
                        "Motivo_factor": "BLOQUE_NO_MUESTREADO",
                        "Ingreso_RC_pronosticado_por_cama": tasa_ingreso_por_cama,
                        "Ingreso_RC_pronosticado_muestra": np.nan,
                        "Ingreso_RC_pronosticado_bloque": tasa_ingreso_por_cama * camas_bloque,
                        "Ingreso_RC_real_estimado_por_cama": np.nan,
                        "Ingreso_RC_real_estimado_muestra": np.nan,
                        "Ingreso_RC_real_estimado_bloque": np.nan,
                        "Desviacion_ingreso_muestra": np.nan,
                        "Error_absoluto_ingreso_pct": np.nan,
                        "Ingreso_real_estimado_disponible": False,
                        "Metodo_pronostico_ingreso": "IMPUTADO_TASA_FINCA",
                        "N_semanas_historial_ingreso": 0,
                        "N_dias_historial_ingreso": 0,
                        "Fecha_ultima_disponibilidad_ingreso": pd.NaT,
                        "Conteo_real_disponible": False,
                        "Corte_real_bloque": float(corte_real) if corte_real_disponible else np.nan,
                        "Corte_real_evaluable_bloque": (
                            float(corte_real) if corte_real_disponible and ventana_completa else np.nan
                        ),
                        "Desviacion_dia_disponible": desviacion,
                        "Error_tallos": error_evaluable,
                        "Error_pct": error_pct,
                        "Corte_real_disponible": corte_real_disponible,
                        "Ventana_evaluable": ventana_completa,
                        "Ventana_real_completa": ventana_completa,
                        "Dias_con_corte_real_ventana": dias_con_real,
                        "Dias_faltantes_corte_ventana": 7 - dias_con_real,
                        "Motivo_no_evaluable": motivo_no_evaluable,
                        "Ventana_ingreso_real_completa": False,
                        "Dias_con_ingreso_real_ventana": 0,
                        "Tipo_evaluacion_ventana": tipo_evaluacion,
                        "Tipo_proyeccion": "BLOQUE_NO_MUESTREADO_IMPUTADO",
                        "Bloque_muestreado": False,
                        "Metodo_estimacion_bloque": "TASA_PONDERADA_CAMAS_FINCA",
                        "N_bloques_activos_semana": n_activos,
                        "N_bloques_muestreados_semana": n_muestreados,
                        "N_bloques_no_muestreados_semana": n_no_muestreados,
                        "Camas_activas_finca_semana": camas_total,
                        "Camas_activas_bloques_muestreados_semana": camas_donantes,
                        "Camas_activas_bloques_no_muestreados_semana": camas_no_muestreadas,
                        "Cobertura_camas_pct": camas_donantes / camas_total if camas_total else np.nan,
                        "Cobertura_bloques_pct": n_muestreados / n_activos if n_activos else np.nan,
                        "Tasa_corte_proyectado_por_cama_finca": tasas["Corte_proyectado_bloque"],
                        "Corte_proyectado_media_simple_sensibilidad_bloque": tasa_corte_media_simple * camas_bloque,
                        "Corte_proyectado_mediana_sensibilidad_bloque": tasa_corte_mediana * camas_bloque,
                    }
                )
                for metrica in metricas_bloque:
                    fila[metrica] = tasas[metrica] * camas_bloque
                filas_imputadas.append(fila)

    # Para filas directas, expone la tasa oficial de finca por fecha.
    for (finca, semana_id, fecha), grupo_dia in resultados.groupby(
        ["Finca", "Semana_conteo_ID", "Fecha"], sort=False
    ):
        donantes = grupo_dia.loc[grupo_dia["Bloque_muestreado"]]
        if donantes.empty:
            continue
        camas_donantes_dia = float(donantes["Camas_totales_activas"].astype(float).sum())
        tasa = float(
            donantes["Corte_proyectado_bloque"].astype(float).sum()
            / camas_donantes_dia
        )
        mascara = (
            resultados["Finca"].eq(finca)
            & resultados["Semana_conteo_ID"].eq(semana_id)
            & resultados["Fecha"].eq(fecha)
        )
        resultados.loc[mascara, "Tasa_corte_proyectado_por_cama_finca"] = tasa

    if filas_imputadas:
        imputadas = pd.DataFrame(filas_imputadas)
        todas = list(dict.fromkeys([*resultados.columns, *imputadas.columns]))
        resultados = resultados.reindex(columns=todas)
        imputadas = imputadas.reindex(columns=todas)
        resultados = pd.concat([resultados, imputadas], ignore_index=True)

    cobertura = pd.DataFrame(filas_cobertura)
    return (
        resultados.sort_values(
            ["Finca", "Semana_conteo_ID", "Bloque", "Fecha"]
        ).reset_index(drop=True),
        cobertura.sort_values(["Finca", "Semana_conteo_ID"]).reset_index(drop=True),
    )
