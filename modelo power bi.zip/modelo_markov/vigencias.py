"""Selección de la matriz según finca y fecha del conteo."""

from __future__ import annotations

from datetime import date

import pandas as pd

from .modelos import MatricesTransicion


PERIODO_ABRIL = "ABRIL"
PERIODO_JULIO = "JULIO"


def periodo_modelo(fecha: object, fecha_cambio: date) -> str:
    """Devuelve el periodo de matriz usando la fecha del conteo."""

    cambio = pd.Timestamp(fecha_cambio).normalize()
    return (
        PERIODO_JULIO
        if pd.Timestamp(fecha).normalize() >= cambio
        else PERIODO_ABRIL
    )


def clave_modelo(finca: object, periodo: str) -> str:
    """Crea una clave interna estable para una matriz temporal."""

    return f"{str(periodo).strip().upper()}|{str(finca).strip().upper()}"


def clave_modelo_fecha(
    finca: object,
    fecha: object,
    fecha_cambio: date,
) -> str:
    """Crea la clave de matriz correspondiente a una fecha de conteo."""

    periodo = periodo_modelo(fecha, fecha_cambio)
    return clave_modelo(finca, periodo)


def asignar_modelo_a_conteos(
    datos: pd.DataFrame,
    fecha_cambio: date,
    columna_fecha: str = "Fecha",
) -> pd.DataFrame:
    """Añade periodo y clave de matriz a una tabla de conteos."""

    salida = datos.copy()
    salida["Periodo_modelo"] = salida[columna_fecha].map(
        lambda fecha: periodo_modelo(fecha, fecha_cambio)
    )
    salida["Modelo_clave"] = [
        clave_modelo(finca, periodo)
        for finca, periodo in zip(salida["Finca"], salida["Periodo_modelo"])
    ]
    return salida


def obtener_matriz(
    matrices_por_modelo: dict[str, MatricesTransicion],
    modelo_clave: str,
) -> MatricesTransicion:
    """Obtiene una matriz y falla con un mensaje trazable si no existe."""

    try:
        return matrices_por_modelo[modelo_clave]
    except KeyError as exc:
        raise ValueError(f"No existe la matriz temporal {modelo_clave}.") from exc
