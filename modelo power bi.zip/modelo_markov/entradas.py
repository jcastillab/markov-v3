"""Lectura, normalización y validación de los insumos multifinca."""

from __future__ import annotations

import re
import unicodedata
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from .configuracion import ConfiguracionModelo


COLUMNAS_CONTEO = ("conteo_RC", "conteo_SS", "conteo_AP")
CORRECCIONES_ESTADO = {
    "R1C": "RC1",
    "R2C": "RC2",
    "R3C": "RC3",
    "R4C": "RC4",
}


def normalizar_texto(valor: Any) -> str:
    """Normaliza un identificador textual."""

    if pd.isna(valor):
        return ""
    return re.sub(r"\s+", " ", str(valor).strip()).upper()


def normalizar_bloque(valor: Any) -> str:
    """Conserva bloques numéricos y alfanuméricos como texto estable."""

    if pd.isna(valor):
        return ""
    if isinstance(valor, (int, np.integer)):
        return str(int(valor))
    if isinstance(valor, (float, np.floating)) and float(valor).is_integer():
        return str(int(valor))
    texto = normalizar_texto(valor).replace(" ", "")
    if re.fullmatch(r"\d+\.0", texto):
        return texto[:-2]
    return texto


def descomponer_finca_bloque(etiqueta: str) -> tuple[str, str | None]:
    """Separa etiquetas como ``LA PRADERA BQ 23``."""

    texto = normalizar_texto(etiqueta)
    patron = re.compile(r"^(.*?)(?:\s+(?:BQ|BL|BLOQUE)\s+)([A-Z0-9]+)$")
    coincidencia = patron.match(texto)
    if coincidencia is None:
        return texto, None
    return coincidencia.group(1).strip(), normalizar_bloque(coincidencia.group(2))


def normalizar_finca(valor: Any) -> str:
    """Homologa los nombres que aparecen en las fuentes del proyecto."""

    finca, _ = descomponer_finca_bloque(normalizar_texto(valor))
    equivalencias = {
        "LA PRADERA": "PRADERA",
        "PRADERA": "PRADERA",
        "ALMER": "ALMER",
        "SANTA HELENA": "SANTA HELENA",
    }
    return equivalencias.get(finca, finca)


def normalizar_estado(valor: Any) -> str | None:
    """Homologa los subestados a RC, SS, AP, PC y L."""

    if pd.isna(valor):
        return None
    texto = normalizar_texto(valor).replace(" ", "")
    texto = CORRECCIONES_ESTADO.get(texto, texto)
    if not texto:
        return None
    if texto == "X":
        return "L"
    if texto == "PC":
        return "PC"
    if texto == "PE" or texto.startswith("RC"):
        return "RC"
    if texto.startswith("SP"):
        return "AP"
    if texto.startswith("S"):
        return "SS"
    return None


def _semana_id(fecha: pd.Timestamp) -> int:
    iso = pd.Timestamp(fecha).isocalendar()
    return int(iso.year) * 100 + int(iso.week)


def _lunes_siguiente(fecha: pd.Timestamp) -> pd.Timestamp:
    fecha = pd.Timestamp(fecha)
    return fecha + pd.Timedelta(days=7 - fecha.weekday())


def validar_rutas(config: ConfiguracionModelo) -> None:
    """Comprueba que todos los insumos existan."""

    rutas = (
        config.ruta_fenologia_abril,
        config.ruta_fenologia_julio,
        config.ruta_conteos,
        config.ruta_camas_muestreadas,
        config.ruta_plano_siembra,
        config.ruta_calendario,
    )
    for ruta in rutas:
        if not Path(ruta).exists():
            raise FileNotFoundError(f"No se encontró el archivo: {ruta}")


def leer_archivos(config: ConfiguracionModelo) -> tuple[dict[str, pd.DataFrame], ...]:
    """Lee las dos fenologías, conteos, camas, plano y calendario."""

    validar_rutas(config)
    fenologias = {
        "ABRIL": pd.read_excel(
            config.ruta_fenologia_abril,
            sheet_name=config.hoja_fenologia_abril,
        ),
        "JULIO": pd.read_excel(
            config.ruta_fenologia_julio,
            sheet_name=config.hoja_fenologia_julio,
        ),
    }
    conteos = pd.read_excel(config.ruta_conteos)
    camas = pd.read_excel(config.ruta_camas_muestreadas)
    plano = pd.read_excel(config.ruta_plano_siembra)
    calendario = pd.read_excel(config.ruta_calendario)
    return fenologias, conteos, camas, plano, calendario


def _columnas_tallos(datos: pd.DataFrame) -> list[str]:
    fijas = {"FINCA", "DIA", "FECHA", "_FINCA_MODELO"}
    return [
        columna
        for columna in datos.columns
        if normalizar_texto(columna) not in fijas
        and not normalizar_texto(columna).startswith("UNNAMED:")
    ]


def rellenar_vacios_aislados(
    datos: pd.DataFrame,
    columnas_tallos: list[str],
    columna_fecha: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Rellena un vacío aislado con el estado anterior."""

    resultado = datos.copy()
    original = datos[columnas_tallos].copy()
    auditoria: list[dict[str, object]] = []
    for indice in range(1, len(original) - 1):
        for columna in columnas_tallos:
            actual = original.iloc[indice][columna]
            anterior = original.iloc[indice - 1][columna]
            posterior = original.iloc[indice + 1][columna]
            if pd.notna(actual) or pd.isna(anterior) or pd.isna(posterior):
                continue
            resultado.at[resultado.index[indice], columna] = anterior
            auditoria.append(
                {
                    "Fecha": resultado.iloc[indice][columna_fecha],
                    "Tallo": str(columna),
                    "Estado_anterior": anterior,
                    "Estado_posterior": posterior,
                    "Estado_rellenado": anterior,
                }
            )
    return resultado, pd.DataFrame(auditoria)


def preparar_fenologia(
    df: pd.DataFrame,
    finca: str,
) -> tuple[pd.DataFrame, str, list[str], pd.DataFrame]:
    """Filtra una trayectoria fenológica y normaliza sus tallos."""

    datos = df.copy()
    datos.columns = [str(columna).strip() for columna in datos.columns]
    mapa = {normalizar_texto(columna): columna for columna in datos.columns}
    faltantes = [nombre for nombre in ("FINCA", "FECHA") if nombre not in mapa]
    if faltantes:
        raise ValueError("Faltan columnas en fenología: " + ", ".join(faltantes))

    columna_finca = mapa["FINCA"]
    columna_fecha = mapa["FECHA"]
    datos["_Finca_modelo"] = datos[columna_finca].map(normalizar_finca)
    datos[columna_fecha] = pd.to_datetime(datos[columna_fecha], errors="coerce")
    datos = datos.loc[datos["_Finca_modelo"].eq(normalizar_finca(finca))].copy()
    datos = datos.dropna(subset=[columna_fecha])
    if datos.empty:
        raise ValueError(f"No hay fenología para {finca} en la hoja seleccionada.")

    columnas_originales = _columnas_tallos(datos)
    marcos: list[pd.DataFrame] = []
    auditorias: list[pd.DataFrame] = []
    for etiqueta, cohorte in datos.groupby(columna_finca, sort=True):
        cohorte = cohorte.sort_values(columna_fecha).reset_index(drop=True)
        if cohorte[columna_fecha].duplicated().any():
            raise ValueError(
                f"Hay fechas duplicadas en la cohorte fenológica {etiqueta}."
            )
        id_cohorte = normalizar_texto(etiqueta)
        columnas_tallos = [
            columna
            for columna in columnas_originales
            if cohorte[columna].notna().any()
        ]
        ajustes: list[dict[str, object]] = []
        for columna in columnas_tallos:
            originales = cohorte[columna].copy()
            for indice, valor in originales.items():
                etiqueta_estado = normalizar_texto(valor).replace(" ", "")
                if etiqueta_estado in CORRECCIONES_ESTADO:
                    ajustes.append(
                        {
                            "Finca": normalizar_finca(finca),
                            "Cohorte": id_cohorte,
                            "Fecha": cohorte.loc[indice, columna_fecha],
                            "Tallo": str(columna),
                            "Tipo_ajuste": "NORMALIZACION_ETIQUETA",
                            "Estado_original": etiqueta_estado,
                            "Estado_corregido": CORRECCIONES_ESTADO[
                                etiqueta_estado
                            ],
                            "Estado_modelo": "RC",
                        }
                    )
                if (
                    etiqueta_estado
                    and etiqueta_estado not in {"G", "DG"}
                    and normalizar_estado(valor) is None
                ):
                    raise ValueError(
                        "Estado fenológico no reconocido: "
                        f"{etiqueta_estado}, {etiqueta}, "
                        f"{cohorte.loc[indice, columna_fecha]:%Y-%m-%d}, "
                        f"tallo {columna}."
                    )
            cohorte[columna] = originales.map(normalizar_estado)

        cohorte, vacios = rellenar_vacios_aislados(
            cohorte,
            columnas_tallos,
            columna_fecha,
        )
        if not vacios.empty:
            vacios["Finca"] = normalizar_finca(finca)
            vacios["Cohorte"] = id_cohorte
            vacios["Tipo_ajuste"] = "VACIO_AISLADO"
            vacios["Estado_original"] = ""
            vacios["Estado_corregido"] = vacios["Estado_rellenado"]
            vacios["Estado_modelo"] = vacios["Estado_rellenado"]
            auditorias.append(
                vacios[
                    [
                        "Finca", "Cohorte", "Fecha", "Tallo", "Tipo_ajuste",
                        "Estado_original", "Estado_corregido", "Estado_modelo",
                    ]
                ]
            )
        if ajustes:
            auditorias.append(pd.DataFrame(ajustes))

        renombres = {
            columna: f"{id_cohorte}|{str(columna)}"
            for columna in columnas_tallos
        }
        marco = cohorte[[columna_fecha, *columnas_tallos]].rename(
            columns=renombres
        )
        marcos.append(marco)

    combinado = marcos[0]
    for marco in marcos[1:]:
        combinado = combinado.merge(
            marco,
            on=columna_fecha,
            how="outer",
            validate="one_to_one",
        )
    combinado = combinado.sort_values(columna_fecha).reset_index(drop=True)
    columnas_tallos = [
        columna for columna in combinado.columns if columna != columna_fecha
    ]
    if not columnas_tallos:
        raise ValueError(f"No se detectaron tallos válidos para {finca}.")
    auditoria = (
        pd.concat(auditorias, ignore_index=True)
        if auditorias
        else pd.DataFrame(
            columns=[
                "Finca", "Cohorte", "Fecha", "Tallo", "Tipo_ajuste",
                "Estado_original", "Estado_corregido", "Estado_modelo",
            ]
        )
    )
    return combinado, columna_fecha, columnas_tallos, auditoria


def preparar_conteos(
    df: pd.DataFrame,
    fincas: tuple[str, ...],
    flor: str,
    variedad: str,
) -> pd.DataFrame:
    """Limpia conteos y cortes sin convertir ausencias en cero."""

    datos = df.copy()
    datos.columns = [str(columna).strip() for columna in datos.columns]
    requeridas = {"Finca", "Bloque", "Fecha", "Cantidad", *COLUMNAS_CONTEO}
    faltantes = sorted(requeridas - set(datos.columns))
    if faltantes:
        raise ValueError("Faltan columnas en conteos: " + ", ".join(faltantes))
    if "conteo_CO" not in datos.columns:
        datos["conteo_CO"] = 0.0

    datos["Finca_original"] = datos["Finca"]
    datos["Finca"] = datos["Finca"].map(normalizar_finca)
    datos["Bloque"] = datos["Bloque"].map(normalizar_bloque)
    datos["Fecha"] = pd.to_datetime(datos["Fecha"], errors="coerce").dt.normalize()
    for columna in ("Cantidad", *COLUMNAS_CONTEO, "conteo_CO"):
        datos[columna] = pd.to_numeric(datos[columna], errors="coerce")
    if "Flor" in datos.columns:
        datos = datos.loc[datos["Flor"].map(normalizar_texto).eq(flor)].copy()
    if "Variedad" in datos.columns:
        datos = datos.loc[
            datos["Variedad"].map(normalizar_texto).eq(variedad)
        ].copy()
    alcance = {normalizar_finca(finca) for finca in fincas}
    datos = datos.dropna(subset=["Fecha"])
    datos = datos.loc[datos["Finca"].isin(alcance)].copy()
    if datos.empty:
        raise ValueError("No hay registros para las fincas solicitadas.")

    origen = datos[list(COLUMNAS_CONTEO)].notna().any(axis=1)
    incompletas = origen & datos[list(COLUMNAS_CONTEO)].isna().any(axis=1)
    if incompletas.any():
        filas = datos.loc[incompletas, ["Finca", "Bloque", "Fecha"]]
        detalle = ", ".join(
            f"{f.Finca}/{f.Bloque}/{f.Fecha.date()}" for f in filas.itertuples()
        )
        raise ValueError("Hay conteos fenológicos incompletos: " + detalle)
    datos["Semana_ID"] = datos["Fecha"].map(_semana_id)
    return datos.sort_values(["Finca", "Bloque", "Fecha"]).reset_index(drop=True)


def auditar_conteos_semanales(datos: pd.DataFrame) -> pd.DataFrame:
    """Marca el último conteo de cada finca, bloque y semana como origen."""

    mascara = datos[list(COLUMNAS_CONTEO)].notna().all(axis=1)
    eventos = datos.loc[mascara].copy()
    eventos = eventos.sort_values(["Finca", "Bloque", "Semana_ID", "Fecha"])
    eventos["N_conteos_bloque_semana"] = eventos.groupby(
        ["Finca", "Bloque", "Semana_ID"]
    )["Fecha"].transform("size")
    ultima_fecha = eventos.groupby(
        ["Finca", "Bloque", "Semana_ID"]
    )["Fecha"].transform("max")
    eventos["Conteo_seleccionado"] = eventos["Fecha"].eq(ultima_fecha)
    eventos["Motivo_seleccion"] = np.where(
        eventos["Conteo_seleccionado"],
        np.where(
            eventos["N_conteos_bloque_semana"].gt(1),
            "ULTIMO_CONTEO_SEMANA",
            "UNICO_CONTEO_SEMANA",
        ),
        "DESCARTADO_POR_CONTEO_POSTERIOR_MISMA_SEMANA",
    )
    eventos["Fecha_inicio_objetivo"] = eventos["Fecha"].map(_lunes_siguiente)
    eventos["Semana_objetivo_ID"] = eventos["Fecha_inicio_objetivo"].map(
        _semana_id
    )
    eventos["Conteo_ID"] = [
        f"{finca}|{bloque}|{fecha:%Y%m%d}"
        for finca, bloque, fecha in zip(
            eventos["Finca"], eventos["Bloque"], eventos["Fecha"]
        )
    ]
    columnas = [
        "Conteo_ID",
        "Finca",
        "Bloque",
        "Fecha",
        "Semana_ID",
        "Fecha_inicio_objetivo",
        "Semana_objetivo_ID",
        "conteo_RC",
        "conteo_SS",
        "conteo_AP",
        "conteo_CO",
        "N_conteos_bloque_semana",
        "Conteo_seleccionado",
        "Motivo_seleccion",
    ]
    return eventos[columnas].reset_index(drop=True)


def preparar_camas_muestreadas(
    df: pd.DataFrame,
    anio: int,
    fincas: tuple[str, ...],
) -> pd.DataFrame:
    """Normaliza las camas observadas por finca, bloque y semana."""

    datos = df.copy()
    datos.columns = [str(columna).strip() for columna in datos.columns]
    requeridas = {"Semana", "Finca", "Bloque", "Cantidad_csv"}
    faltantes = sorted(requeridas - set(datos.columns))
    if faltantes:
        raise ValueError(
            "Faltan columnas en camas muestreadas: " + ", ".join(faltantes)
        )
    datos["Semana_original"] = datos["Semana"]
    datos["Finca_original"] = datos["Finca"]
    datos["Semana_numero"] = pd.to_numeric(
        datos["Semana"].astype(str).str.upper().str.extract(r"^S(\d{1,2})$", expand=False),
        errors="coerce",
    )
    datos["Finca"] = datos["Finca"].map(normalizar_finca)
    datos["Bloque"] = datos["Bloque"].map(normalizar_bloque)
    datos["Camas_muestreadas"] = pd.to_numeric(
        datos["Cantidad_csv"], errors="coerce"
    )
    alcance = {normalizar_finca(finca) for finca in fincas}
    datos = datos.loc[
        datos["Semana_numero"].notna()
        & datos["Finca"].isin(alcance)
        & datos["Bloque"].ne("")
        & datos["Camas_muestreadas"].gt(0)
    ].copy()
    datos["Semana_numero"] = datos["Semana_numero"].astype(int)
    datos["Semana_ID"] = int(anio) * 100 + datos["Semana_numero"]
    duplicadas = datos.duplicated(["Finca", "Bloque", "Semana_ID"], keep=False)
    if duplicadas.any():
        pares = datos.loc[duplicadas, ["Finca", "Bloque", "Semana_ID"]]
        raise ValueError(
            "Hay camas muestreadas duplicadas: "
            + ", ".join(
                f"{f.Finca}/{f.Bloque}/{f.Semana_ID}" for f in pares.itertuples()
            )
        )
    return datos[
        [
            "Finca",
            "Bloque",
            "Semana_ID",
            "Semana_numero",
            "Camas_muestreadas",
            "Finca_original",
            "Semana_original",
        ]
    ].sort_values(["Finca", "Bloque", "Semana_ID"]).reset_index(drop=True)


def preparar_plano_siembra(
    df: pd.DataFrame,
    fincas: tuple[str, ...],
    flor: str,
    variedad: str,
) -> pd.DataFrame:
    """Filtra las camas de la variedad y conserva su vigencia."""

    datos = df.copy()
    datos.columns = [str(columna).strip() for columna in datos.columns]
    requeridas = {
        "Finca",
        "Flor",
        "Variedad",
        "Bloque",
        "Cama",
        "Fecha Siembra",
        "Fecha Erradicacion",
    }
    faltantes = sorted(requeridas - set(datos.columns))
    if faltantes:
        raise ValueError("Faltan columnas en plano de siembra: " + ", ".join(faltantes))
    datos["Finca"] = datos["Finca"].map(normalizar_finca)
    datos["Bloque"] = datos["Bloque"].map(normalizar_bloque)
    datos["Cama"] = datos["Cama"].map(normalizar_bloque)
    datos["Flor"] = datos["Flor"].map(normalizar_texto)
    datos["Variedad"] = datos["Variedad"].map(normalizar_texto)
    datos["Fecha_siembra"] = pd.to_datetime(
        datos["Fecha Siembra"], dayfirst=True, errors="coerce"
    ).dt.normalize()
    datos["Fecha_erradicacion"] = pd.to_datetime(
        datos["Fecha Erradicacion"], dayfirst=True, errors="coerce"
    ).dt.normalize()
    alcance = {normalizar_finca(finca) for finca in fincas}
    datos = datos.loc[
        datos["Finca"].isin(alcance)
        & datos["Flor"].eq(flor)
        & datos["Variedad"].eq(variedad)
        & datos["Bloque"].ne("")
        & datos["Cama"].ne("")
        & datos["Fecha_siembra"].notna()
        & datos["Fecha_erradicacion"].notna()
    ].copy()
    if datos.empty:
        raise ValueError("El plano no contiene camas vigentes para el alcance.")
    return datos[
        [
            "Finca",
            "Bloque",
            "Cama",
            "Fecha_siembra",
            "Fecha_erradicacion",
        ]
    ].reset_index(drop=True)


def construir_extrapolacion(
    auditoria_conteos: pd.DataFrame,
    camas_muestreadas: pd.DataFrame,
    plano: pd.DataFrame,
) -> pd.DataFrame:
    """Calcula el factor por evento con la regla de mínimo igual a uno."""

    eventos = auditoria_conteos.loc[
        auditoria_conteos["Conteo_seleccionado"]
    ].copy()
    eventos = eventos.merge(
        camas_muestreadas,
        on=["Finca", "Bloque", "Semana_ID"],
        how="left",
        validate="one_to_one",
    )
    if eventos["Camas_muestreadas"].isna().any():
        faltantes = eventos.loc[
            eventos["Camas_muestreadas"].isna(),
            ["Finca", "Bloque", "Semana_ID"],
        ]
        detalle = ", ".join(
            f"{f.Finca}/{f.Bloque}/{f.Semana_ID}" for f in faltantes.itertuples()
        )
        raise ValueError("Faltan camas muestreadas para: " + detalle)

    filas: list[dict[str, object]] = []
    for evento in eventos.itertuples(index=False):
        activas = plano.loc[
            plano["Finca"].eq(evento.Finca)
            & plano["Bloque"].eq(evento.Bloque)
            & plano["Fecha_siembra"].le(evento.Fecha)
            & plano["Fecha_erradicacion"].ge(evento.Fecha)
        ]
        camas_totales = int(activas["Cama"].nunique())
        if camas_totales <= 0:
            raise ValueError(
                "No hay camas activas en el plano para "
                f"{evento.Finca}/{evento.Bloque}/{evento.Fecha:%Y-%m-%d}."
            )

        # Control de estabilidad de la población de camas entre el conteo y
        # la semana objetivo. El factor oficial sigue anclado al conteo, pero
        # cualquier cambio de camas activas queda visible para auditoría.
        inicio_objetivo = pd.Timestamp(
            getattr(evento, "Fecha_inicio_objetivo", evento.Fecha)
        )
        fin_objetivo = inicio_objetivo + pd.Timedelta(days=6)
        def contar_activas(fecha_ref: pd.Timestamp) -> int:
            sub = plano.loc[
                plano["Finca"].eq(evento.Finca)
                & plano["Bloque"].eq(evento.Bloque)
                & plano["Fecha_siembra"].le(fecha_ref)
                & plano["Fecha_erradicacion"].ge(fecha_ref)
            ]
            return int(sub["Cama"].nunique())

        camas_inicio_objetivo = contar_activas(inicio_objetivo)
        camas_fin_objetivo = contar_activas(fin_objetivo)
        cambio_camas_horizonte = bool(
            camas_inicio_objetivo != camas_totales
            or camas_fin_objetivo != camas_totales
        )
        muestreadas = float(evento.Camas_muestreadas)
        factor_teorico = float(camas_totales / muestreadas)
        supera = bool(muestreadas > camas_totales)
        factor = 1.0 if supera else factor_teorico
        if supera:
            motivo = "MUESTREO_SUPERA_CAMAS_ACTIVAS"
        elif np.isclose(muestreadas, camas_totales):
            motivo = "MUESTREO_IGUAL_CAMAS_ACTIVAS"
        else:
            motivo = "SIN_AJUSTE"
        filas.append(
            {
                "Extrapolacion_ID": evento.Conteo_ID,
                "Conteo_ID": evento.Conteo_ID,
                "Finca": evento.Finca,
                "Bloque": evento.Bloque,
                "Periodo_modelo": getattr(evento, "Periodo_modelo", None),
                "Modelo_clave": getattr(evento, "Modelo_clave", None),
                "Fecha_conteo": pd.Timestamp(evento.Fecha),
                "Fecha_inicio_objetivo": inicio_objetivo,
                "Semana_conteo_ID": int(evento.Semana_ID),
                "Semana_objetivo_ID": _semana_id(inicio_objetivo),
                "Semana_ID": int(evento.Semana_ID),
                "Camas_totales_activas": camas_totales,
                "Camas_activas_inicio_semana_objetivo": camas_inicio_objetivo,
                "Camas_activas_fin_semana_objetivo": camas_fin_objetivo,
                "Cambio_camas_activas_horizonte": cambio_camas_horizonte,
                "Camas_muestreadas": muestreadas,
                "Factor_extrapolacion_teorico": factor_teorico,
                "Factor_extrapolacion": factor,
                "Factor_ajustado": supera,
                "Motivo_factor": motivo,
                "Filas_siembra_activas": int(len(activas)),
                "Camas_activas_duplicadas": int(
                    activas.duplicated(["Cama"], keep=False).sum()
                ),
            }
        )
    resultado = pd.DataFrame(filas)
    if resultado["Conteo_ID"].duplicated().any():
        raise ValueError("La extrapolación no tiene una fila única por conteo.")
    return resultado.sort_values(
        ["Finca", "Bloque", "Fecha_conteo"]
    ).reset_index(drop=True)


def preparar_calendario(df: pd.DataFrame) -> pd.DataFrame:
    """Normaliza el calendario suministrado y valida fechas únicas."""

    datos = df.copy()
    datos.columns = [str(columna).strip() for columna in datos.columns]
    if "Fecha" not in datos.columns:
        raise ValueError("El calendario no contiene la columna Fecha.")
    datos["Fecha"] = pd.to_datetime(datos["Fecha"], errors="coerce").dt.normalize()
    datos = datos.dropna(subset=["Fecha"]).drop_duplicates("Fecha", keep="last")
    datos = datos.sort_values("Fecha").reset_index(drop=True)
    if datos.empty:
        raise ValueError("El calendario no contiene fechas válidas.")
    datos["Semana_ID_calculada"] = datos["Fecha"].map(_semana_id)
    return datos
