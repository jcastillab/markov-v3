"""Auditorías estadísticas, temporales y de calidad del modelo final."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .configuracion import ESTADOS
from .vigencias import clave_modelo


ORDEN_FENO = {"RC": 0, "SS": 1, "AP": 2, "PC": 3}


def auditar_transiciones_fenologia(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_tallos: list[str],
    modelo_clave: str,
    periodo: str,
    finca: str,
) -> pd.DataFrame:
    """Registra transiciones agregadas observadas entre días consecutivos."""

    fechas = pd.to_datetime(datos[columna_fecha], errors="coerce")
    filas: list[dict[str, object]] = []
    for tallo in columnas_tallos:
        valores = datos[tallo].tolist()
        for i in range(1, len(valores)):
            origen = valores[i - 1]
            destino = valores[i]
            if origen is None or destino is None or origen == destino:
                continue
            if pd.isna(origen) or pd.isna(destino):
                continue
            tipo = "OTRA"
            distancia = np.nan
            if origen in {"PC", "L"}:
                tipo = "SALIDA_DESDE_TERMINAL"
            elif destino == "L":
                tipo = "PERDIDA"
            elif origen in ORDEN_FENO and destino in ORDEN_FENO:
                distancia = ORDEN_FENO[destino] - ORDEN_FENO[origen]
                if distancia == 1:
                    tipo = "AVANCE_ESPERADO"
                elif distancia > 1:
                    tipo = "SALTO_ADELANTE"
                elif distancia < 0:
                    tipo = "RETROCESO"
            filas.append(
                {
                    "Modelo_clave": modelo_clave,
                    "Periodo_modelo": periodo,
                    "Finca": finca,
                    "Tallo": str(tallo),
                    "Fecha_origen": pd.Timestamp(fechas.iloc[i - 1]),
                    "Fecha_destino": pd.Timestamp(fechas.iloc[i]),
                    "Estado_origen": origen,
                    "Estado_destino": destino,
                    "Distancia_estados": distancia,
                    "Tipo_transicion": tipo,
                }
            )
    return pd.DataFrame(filas)


def asignar_modelo_causal(
    auditoria_base: pd.DataFrame,
    estadisticas: pd.DataFrame,
) -> pd.DataFrame:
    """Asigna a cada conteo la matriz más reciente disponible en esa fecha."""

    salida = auditoria_base.copy()
    stats = estadisticas.copy()
    stats["Fecha_disponibilidad_matriz"] = pd.to_datetime(
        stats["Fecha_disponibilidad_matriz"]
    )
    periodos: list[object] = []
    claves: list[object] = []
    disponibilidades: list[object] = []
    for fila in salida.itertuples(index=False):
        candidatos = stats.loc[
            stats["Finca"].eq(fila.Finca)
            & stats["Fecha_disponibilidad_matriz"].le(pd.Timestamp(fila.Fecha))
        ].sort_values("Fecha_disponibilidad_matriz")
        if candidatos.empty:
            periodos.append(np.nan)
            claves.append(np.nan)
            disponibilidades.append(pd.NaT)
        else:
            elegido = candidatos.iloc[-1]
            periodo = str(elegido["Periodo_modelo"])
            periodos.append(periodo)
            claves.append(clave_modelo(fila.Finca, periodo))
            disponibilidades.append(elegido["Fecha_disponibilidad_matriz"])
    salida["Periodo_modelo"] = periodos
    salida["Modelo_clave"] = claves
    salida["Fecha_disponibilidad_matriz"] = disponibilidades
    salida["Conteo_seleccionado_original"] = salida["Conteo_seleccionado"]
    sin_matriz = salida["Modelo_clave"].isna()
    salida.loc[sin_matriz, "Conteo_seleccionado"] = False
    salida.loc[sin_matriz, "Motivo_seleccion"] = "SIN_MATRIZ_DISPONIBLE_A_FECHA_CONTEO"
    salida["Backtest_causal"] = ~sin_matriz
    return salida


def enriquecer_causalidad_matriz(
    fact: pd.DataFrame,
    estadisticas: pd.DataFrame,
) -> pd.DataFrame:
    """Añade disponibilidad temporal de la matriz usada a una tabla de hechos."""

    if fact.empty:
        return fact.copy()
    mapa = estadisticas.set_index("Modelo_clave")["Fecha_disponibilidad_matriz"]
    salida = fact.copy()
    salida["Fecha_disponibilidad_matriz"] = salida["Modelo_clave"].map(mapa)
    salida["Fecha_disponibilidad_matriz"] = pd.to_datetime(
        salida["Fecha_disponibilidad_matriz"]
    )
    salida["Matriz_disponible_fecha_conteo"] = (
        pd.to_datetime(salida["Fecha_conteo"]) >= salida["Fecha_disponibilidad_matriz"]
    )
    salida["Tipo_causalidad_matriz"] = np.where(
        salida["Matriz_disponible_fecha_conteo"],
        "CAUSAL",
        "RETROSPECTIVA_NO_CAUSAL",
    )
    if "Fecha_inicio_semana" in salida.columns:
        salida["Lead_dias_hasta_semana_objetivo"] = (
            pd.to_datetime(salida["Fecha_inicio_semana"])
            - pd.to_datetime(salida["Fecha_conteo"])
        ).dt.days.astype("Int64")
    return salida


def _cortes_semana(
    datos_conteos: pd.DataFrame,
    finca: str,
    bloque: str,
    inicio: pd.Timestamp,
) -> tuple[bool, float]:
    fechas = pd.date_range(inicio, periods=7, freq="D")
    sub = datos_conteos.loc[
        datos_conteos["Finca"].eq(finca)
        & datos_conteos["Bloque"].eq(str(bloque))
        & datos_conteos["Fecha"].isin(fechas),
        ["Fecha", "Cantidad"],
    ].copy()
    sub = sub.drop_duplicates("Fecha", keep="last")
    completo = len(sub) == 7 and sub["Cantidad"].notna().all()
    return bool(completo), float(sub["Cantidad"].sum()) if completo else np.nan


def construir_fact_benchmark(
    fact_semanal: pd.DataFrame,
    datos_conteos: pd.DataFrame,
) -> pd.DataFrame:
    """Construye benchmarks causales basados en semanas reales anteriores."""

    filas: list[dict[str, object]] = []
    for fila in fact_semanal.itertuples(index=False):
        valores_previos: list[float] = []
        completos_previos: list[bool] = []
        # La semana inmediatamente anterior a la semana objetivo coincide con
        # la semana del conteo y aún no está completa al emitir el pronóstico.
        # El benchmark causal empieza dos semanas antes de la semana objetivo.
        for k in range(2, 6):
            inicio = pd.Timestamp(fila.Fecha_inicio_semana) - pd.Timedelta(days=7 * k)
            completo, valor = _cortes_semana(
                datos_conteos, str(fila.Finca), str(fila.Bloque), inicio
            )
            completos_previos.append(completo)
            valores_previos.append(valor)

        last1 = valores_previos[0] if completos_previos[0] else np.nan
        avg2 = (
            float(np.mean(valores_previos[:2]))
            if all(completos_previos[:2])
            else np.nan
        )
        avg4 = (
            float(np.mean(valores_previos[:4]))
            if all(completos_previos[:4])
            else np.nan
        )
        real = float(fila.Corte_real_bloque) if pd.notna(fila.Corte_real_bloque) else np.nan
        markov = float(fila.Corte_proyectado_bloque)
        hibrido = 0.5 * markov + 0.5 * last1 if pd.notna(last1) else np.nan

        def error(pred):
            return abs(float(pred) - real) if pd.notna(pred) and pd.notna(real) else np.nan

        filas.append(
            {
                "Benchmark_ID": str(fila.Resumen_semanal_ID),
                "Resumen_semanal_ID": fila.Resumen_semanal_ID,
                "Ejecucion_ID": fila.Ejecucion_ID,
                "Modelo_ID": fila.Modelo_ID,
                "Modelo_clave": fila.Modelo_clave,
                "Periodo_modelo": fila.Periodo_modelo,
                "Bloque_ID": fila.Bloque_ID,
                "Finca": fila.Finca,
                "Bloque": fila.Bloque,
                "Fecha_conteo_ID": fila.Fecha_conteo_ID,
                "Fecha_inicio_ID": fila.Fecha_inicio_ID,
                "Semana_ID": fila.Semana_ID,
                "Fecha_conteo": fila.Fecha_conteo,
                "Fecha_inicio_semana": fila.Fecha_inicio_semana,
                "Ventana_evaluable": fila.Ventana_evaluable,
                "Corte_real_bloque": real,
                "Corte_markov": markov,
                "Benchmark_ultima_semana": last1,
                "Benchmark_promedio_2_semanas": avg2,
                "Benchmark_promedio_4_semanas": avg4,
                "Hibrido_50_50_auditoria": hibrido,
                "Benchmark_ultima_semana_disponible": pd.notna(last1),
                "Error_abs_markov": error(markov),
                "Error_abs_ultima_semana": error(last1),
                "Error_abs_promedio_2": error(avg2),
                "Error_abs_promedio_4": error(avg4),
                "Error_abs_hibrido_50_50": error(hibrido),
            }
        )
    return pd.DataFrame(filas)


def construir_control_benchmark(fact_benchmark: pd.DataFrame) -> pd.DataFrame:
    """Resume WAPE de Markov y benchmarks en universos comparables."""

    filas: list[dict[str, object]] = []
    for alcance, grupo0 in [("TOTAL", fact_benchmark), *[
        (finca, fact_benchmark.loc[fact_benchmark["Finca"].eq(finca)])
        for finca in sorted(fact_benchmark["Finca"].dropna().unique())
    ]]:
        grupo = grupo0.loc[
            grupo0["Ventana_evaluable"]
            & grupo0["Benchmark_ultima_semana_disponible"]
        ].copy()
        if grupo.empty:
            continue
        den = float(grupo["Corte_real_bloque"].abs().sum())
        for nombre, col in (
            ("MARKOV_OFICIAL", "Error_abs_markov"),
            ("ULTIMA_SEMANA_COMPLETA", "Error_abs_ultima_semana"),
            ("HIBRIDO_50_50_AUDITORIA", "Error_abs_hibrido_50_50"),
        ):
            filas.append(
                {
                    "Alcance": alcance,
                    "Escenario": nombre,
                    "N_ventanas_comparables": int(len(grupo)),
                    "WAPE": float(grupo[col].sum() / den) if den else np.nan,
                    "Uso_oficial": nombre == "MARKOV_OFICIAL",
                }
            )
    return pd.DataFrame(filas)


def construir_control_causalidad(
    fact_semanal: pd.DataFrame,
    fact_causal: pd.DataFrame,
) -> pd.DataFrame:
    """Resume la diferencia entre backtest retrospectivo y backtest causal."""

    filas: list[dict[str, object]] = []
    for nombre, fact in (
        ("RETROSPECTIVO_REGLA_CALENDARIO", fact_semanal),
        ("CAUSAL_ULTIMA_MATRIZ_DISPONIBLE", fact_causal),
    ):
        ev = fact.loc[fact["Ventana_evaluable"]].copy()
        den = float(ev["Corte_real_bloque"].abs().sum()) if not ev.empty else 0.0
        error = float(ev["Error_absoluto_tallos"].sum()) if not ev.empty else np.nan
        sesgo_num = float(ev["Desviacion_tallos"].sum()) if not ev.empty else np.nan
        filas.append(
            {
                "Escenario_backtest": nombre,
                "N_pronosticos": int(len(fact)),
                "N_evaluables": int(len(ev)),
                "WAPE": error / den if den else np.nan,
                "Sesgo_pct": sesgo_num / den if den else np.nan,
            }
        )
    return pd.DataFrame(filas)


def construir_control_transiciones(transiciones: pd.DataFrame) -> pd.DataFrame:
    """Resume anomalías de las trayectorias fenológicas por matriz."""

    if transiciones.empty:
        return pd.DataFrame()
    resumen = (
        transiciones.groupby(
            ["Modelo_clave", "Periodo_modelo", "Finca", "Tipo_transicion"],
            as_index=False,
        )
        .size()
        .rename(columns={"size": "N_transiciones"})
    )
    return resumen.sort_values(
        ["Periodo_modelo", "Finca", "Tipo_transicion"]
    ).reset_index(drop=True)



def construir_control_insumos(
    datos_conteos: pd.DataFrame,
    datos_camas: pd.DataFrame,
    datos_plano: pd.DataFrame,
    datos_calendario: pd.DataFrame,
    extrapolacion: pd.DataFrame,
) -> pd.DataFrame:
    """Controles de integridad de los cuatro insumos operacionales."""

    # Solapamiento de vigencias de una misma cama.
    solapamientos = 0
    for _, grupo in datos_plano.groupby(["Finca", "Bloque", "Cama"], sort=False):
        g = grupo.sort_values("Fecha_siembra")
        if len(g) <= 1:
            continue
        prev_fin = pd.Timestamp(g.iloc[0]["Fecha_erradicacion"])
        for fila in g.iloc[1:].itertuples(index=False):
            if pd.Timestamp(fila.Fecha_siembra) <= prev_fin:
                solapamientos += 1
            prev_fin = max(prev_fin, pd.Timestamp(fila.Fecha_erradicacion))

    fechas = pd.to_datetime(datos_calendario["Fecha"]).sort_values().drop_duplicates()
    gaps = int((fechas.diff().dropna() != pd.Timedelta(days=1)).sum())
    cols_conteo = ["conteo_RC", "conteo_SS", "conteo_AP", "conteo_CO"]
    controles = [
        ("CONTEOS_CORTES", "Filas preparadas", len(datos_conteos), "OK"),
        ("CONTEOS_CORTES", "Duplicados finca-bloque-fecha", int(datos_conteos.duplicated(["Finca", "Bloque", "Fecha"]).sum()), "OK"),
        ("CONTEOS_CORTES", "Cortes negativos", int(datos_conteos["Cantidad"].lt(0).sum()), "OK"),
        ("CONTEOS_CORTES", "Cortes faltantes en filas existentes", int(datos_conteos["Cantidad"].isna().sum()), "CONTROL"),
        ("CONTEOS_CORTES", "Conteos negativos", int(sum(datos_conteos[c].lt(0).sum() for c in cols_conteo)), "OK"),
        ("CAMAS_MUESTREADAS", "Filas preparadas", len(datos_camas), "OK"),
        ("CAMAS_MUESTREADAS", "Duplicados finca-bloque-semana", int(datos_camas.duplicated(["Finca", "Bloque", "Semana_ID"]).sum()), "OK"),
        ("CAMAS_MUESTREADAS", "Camas muestreadas no positivas", int(datos_camas["Camas_muestreadas"].le(0).sum()), "OK"),
        ("PLANO_SIEMBRA", "Filas preparadas", len(datos_plano), "OK"),
        ("PLANO_SIEMBRA", "Vigencias exactas duplicadas", int(datos_plano.duplicated(["Finca", "Bloque", "Cama", "Fecha_siembra", "Fecha_erradicacion"]).sum()), "OK"),
        ("PLANO_SIEMBRA", "Solapamientos de vigencia por cama", solapamientos, "OK"),
        ("CALENDARIO", "Fechas distintas", int(fechas.nunique()), "OK"),
        ("CALENDARIO", "Saltos entre fechas consecutivas", gaps, "OK"),
        ("EXTRAPOLACION", "Eventos muestra supera camas activas", int(extrapolacion["Factor_ajustado"].sum()), "CONTROL"),
        ("EXTRAPOLACION", "Eventos con cambio camas activas en horizonte", int(extrapolacion["Cambio_camas_activas_horizonte"].sum()), "CONTROL"),
        ("EXTRAPOLACION", "Camas activas duplicadas en evento", int(extrapolacion["Camas_activas_duplicadas"].sum()), "OK"),
    ]
    filas = []
    for i, (fuente, metrica, valor, esperado) in enumerate(controles, 1):
        es_control = esperado == "CONTROL"
        estado = "CONTROL" if es_control and valor > 0 else ("OK" if valor == 0 or metrica in {"Filas preparadas", "Fechas distintas"} else "ERROR")
        if metrica in {"Filas preparadas", "Fechas distintas"}:
            estado = "OK"
        filas.append({
            "Control_Insumo_ID": i,
            "Fuente": fuente,
            "Metrica": metrica,
            "Valor": float(valor),
            "Estado": estado,
        })
    return pd.DataFrame(filas)
