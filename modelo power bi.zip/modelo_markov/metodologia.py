"""Estimación de la metodología 3 por grupos de duración.

La versión final estima probabilidades Markov homogéneas mediante exposiciones
observadas. Para cada estado se cuentan oportunidades diarias de permanencia y
la transición de salida. Después se ponderan las matrices de cada grupo por la
participación de tallos del grupo.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np
import pandas as pd

from .configuracion import ESTADOS, SIGUIENTE
from .modelos import MatricesTransicion, ResultadoEstimacion


TERMINALES = {"PC", "L"}
METODO_MATRIZ = "M3_EXPOSICIONES_GRUPO"


def clasificar_tallos_por_duracion(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_tallos: Sequence[str],
) -> pd.DataFrame:
    """Clasifica cada tallo desde su primer RC hasta su primer PC o L."""

    fechas = pd.to_datetime(datos[columna_fecha], errors="coerce")
    registros: list[dict[str, object]] = []
    for columna in columnas_tallos:
        valores = datos[columna].tolist()
        indice_rc = next(
            (indice for indice, valor in enumerate(valores) if valor == "RC"),
            None,
        )
        indice_salida = None
        if indice_rc is not None:
            indice_salida = next(
                (
                    indice
                    for indice in range(indice_rc + 1, len(valores))
                    if valores[indice] in TERMINALES
                ),
                None,
            )

        fecha_rc = fechas.iloc[indice_rc] if indice_rc is not None else pd.NaT
        fecha_salida = (
            fechas.iloc[indice_salida] if indice_salida is not None else pd.NaT
        )
        duracion = (
            int((fecha_salida - fecha_rc).days)
            if pd.notna(fecha_rc) and pd.notna(fecha_salida)
            else np.nan
        )
        incluido = bool(pd.notna(duracion) and int(duracion) > 0)
        motivo = None
        if indice_rc is None:
            motivo = "No aparece RC"
        elif indice_salida is None:
            motivo = "No aparece PC ni L después de RC"
        elif not incluido:
            motivo = "Duración no positiva"

        registros.append(
            {
                "Tallo": str(columna),
                "Indice_RC": indice_rc,
                "Fecha_RC": fecha_rc,
                "Indice_salida": indice_salida,
                "Fecha_salida": fecha_salida,
                "Estado_salida": (
                    valores[indice_salida] if indice_salida is not None else None
                ),
                "Duracion_dias": duracion,
                "Incluido_grupo": incluido,
                "Motivo_exclusion": motivo,
            }
        )

    resultado = pd.DataFrame(registros)
    if resultado.empty or not resultado["Incluido_grupo"].any():
        raise ValueError("No hay tallos completos para formar grupos de duración.")
    return resultado


def resumir_grupos(clasificacion: pd.DataFrame) -> pd.DataFrame:
    """Calcula los pesos de los grupos de duración."""

    incluidos = clasificacion.loc[clasificacion["Incluido_grupo"]].copy()
    total = len(incluidos)
    filas: list[dict[str, object]] = []
    for duracion, grupo in incluidos.groupby("Duracion_dias", sort=True):
        filas.append(
            {
                "Duracion_dias": int(duracion),
                "N_tallos_grupo": int(len(grupo)),
                "Participacion_grupo": float(len(grupo) / total),
                "N_PC": int(grupo["Estado_salida"].eq("PC").sum()),
                "N_L": int(grupo["Estado_salida"].eq("L").sum()),
            }
        )
    return pd.DataFrame(filas)


def _episodios_estado(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_grupo: Sequence[str],
    estado: str,
) -> list[dict[str, object]]:
    """Obtiene episodios completos de permanencia y salida de un estado.

    Un salto hacia un estado posterior se considera salida del estado actual.
    La matriz agregada conserva la secuencia RC -> SS -> AP -> PC; los saltos
    observados se auditan por separado en las tablas de calidad de fenología.
    """

    fechas = pd.to_datetime(datos[columna_fecha], errors="coerce")
    posicion = ESTADOS.index(estado)
    destinos_validos = set(ESTADOS[posicion + 1 :]) | TERMINALES
    episodios: list[dict[str, object]] = []

    for columna in columnas_grupo:
        valores = datos[columna].tolist()
        inicio = next(
            (indice for indice, valor in enumerate(valores) if valor == estado),
            None,
        )
        if inicio is None:
            continue
        salida = next(
            (
                indice
                for indice in range(inicio + 1, len(valores))
                if valores[indice] in destinos_validos
            ),
            None,
        )
        if salida is None:
            continue
        fecha_inicio = fechas.iloc[inicio]
        fecha_salida = fechas.iloc[salida]
        if pd.isna(fecha_inicio) or pd.isna(fecha_salida):
            continue
        duracion = int((fecha_salida - fecha_inicio).days)
        if duracion <= 0:
            continue
        episodios.append(
            {
                "Tallo": str(columna),
                "Duracion_estado_dias": duracion,
                "Estado_salida": valores[salida],
            }
        )
    return episodios


def _resumen_exposiciones(episodios: Sequence[dict[str, object]]) -> dict[str, float | int]:
    """Resume exposiciones diarias y transiciones de salida observadas."""

    exposiciones = int(
        sum(int(episodio["Duracion_estado_dias"]) for episodio in episodios)
    )
    permanecer = int(
        sum(max(int(episodio["Duracion_estado_dias"]) - 1, 0) for episodio in episodios)
    )
    perder = int(sum(episodio["Estado_salida"] == "L" for episodio in episodios))
    avanzar = int(len(episodios) - perder)
    if exposiciones <= 0:
        return {
            "N_episodios_estado": int(len(episodios)),
            "Exposiciones_dia": 0,
            "Transiciones_permanecer": 0,
            "Transiciones_avanzar": 0,
            "Transiciones_perder": 0,
            "P_mantener": np.nan,
            "P_avanzar": np.nan,
            "P_perder": np.nan,
        }
    if permanecer + avanzar + perder != exposiciones:
        raise ValueError(
            "La contabilidad de exposiciones no coincide con las transiciones."
        )
    return {
        "N_episodios_estado": int(len(episodios)),
        "Exposiciones_dia": exposiciones,
        "Transiciones_permanecer": permanecer,
        "Transiciones_avanzar": avanzar,
        "Transiciones_perder": perder,
        "P_mantener": float(permanecer / exposiciones),
        "P_avanzar": float(avanzar / exposiciones),
        "P_perder": float(perder / exposiciones),
    }


def _matriz_desde_probabilidades(
    probabilidades: dict[str, tuple[float, float, float]],
) -> MatricesTransicion:
    cantidad = len(ESTADOS)
    Q = np.zeros((cantidad, cantidad), dtype=float)
    r = np.zeros((cantidad, 1), dtype=float)
    p = np.zeros((cantidad, 1), dtype=float)
    posiciones = {estado: indice for indice, estado in enumerate(ESTADOS)}

    for estado in ESTADOS:
        mantener, avanzar, perder = probabilidades[estado]
        origen = posiciones[estado]
        Q[origen, origen] = mantener
        destino = SIGUIENTE[estado]
        if destino in posiciones:
            Q[posiciones[destino], origen] = avanzar
        else:
            r[origen, 0] = avanzar
        p[origen, 0] = perder

    sumas = Q.sum(axis=0) + r.ravel() + p.ravel()
    if np.any(Q < -1e-12) or np.any(r < -1e-12) or np.any(p < -1e-12):
        raise ValueError("Q, r o p contienen probabilidades negativas.")
    if not np.allclose(sumas, np.ones(cantidad), atol=1e-10):
        raise ValueError(f"Las columnas de Q, r y p no suman 1: {sumas}")
    return MatricesTransicion(Q=Q, r=r, p=p)


def _probabilidades_globales(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_tallos: Sequence[str],
) -> dict[str, tuple[float, float, float]]:
    """Calcula probabilidades globales para fallback de grupos sin exposición."""

    salida: dict[str, tuple[float, float, float]] = {}
    for estado in ESTADOS:
        resumen = _resumen_exposiciones(
            _episodios_estado(datos, columna_fecha, columnas_tallos, estado)
        )
        if int(resumen["Exposiciones_dia"]) <= 0:
            raise ValueError(f"No hay exposiciones globales para el estado {estado}.")
        salida[estado] = (
            float(resumen["P_mantener"]),
            float(resumen["P_avanzar"]),
            float(resumen["P_perder"]),
        )
    return salida


def _calcular_matriz_grupo(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_grupo: Sequence[str],
    duracion_grupo: int,
    fallback_global: dict[str, tuple[float, float, float]],
) -> tuple[MatricesTransicion, pd.DataFrame]:
    """Estima una matriz de grupo con máxima verosimilitud por exposiciones."""

    probabilidades: dict[str, tuple[float, float, float]] = {}
    detalle: list[dict[str, object]] = []

    for estado in ESTADOS:
        episodios = _episodios_estado(datos, columna_fecha, columnas_grupo, estado)
        resumen = _resumen_exposiciones(episodios)
        fallback = int(resumen["Exposiciones_dia"]) <= 0
        if fallback:
            mantener, avanzar, perder = fallback_global[estado]
        else:
            mantener = float(resumen["P_mantener"])
            avanzar = float(resumen["P_avanzar"])
            perder = float(resumen["P_perder"])
        probabilidades[estado] = (mantener, avanzar, perder)
        detalle.append(
            {
                "Metodo_matriz": METODO_MATRIZ,
                "Duracion_grupo": int(duracion_grupo),
                "Estado": estado,
                **resumen,
                "Fallback_estado": bool(fallback),
                "Fuente_probabilidad": "GLOBAL_FINCA_PERIODO" if fallback else "GRUPO_DURACION",
                "P_mantener_final": mantener,
                "P_avanzar_final": avanzar,
                "P_perder_final": perder,
            }
        )

    return _matriz_desde_probabilidades(probabilidades), pd.DataFrame(detalle)


def estimar_metodologia_3(
    datos: pd.DataFrame,
    columna_fecha: str,
    columnas_tallos: Sequence[str],
) -> ResultadoEstimacion:
    """Estima matrices por duración y las pondera por tamaño de grupo.

    La probabilidad diaria de cada grupo se estima como frecuencia de
    transiciones sobre exposiciones diarias. Esta formulación evita interpretar
    un promedio de supervivencias por edad como una probabilidad Markov de un
    paso.
    """

    clasificacion = clasificar_tallos_por_duracion(
        datos,
        columna_fecha,
        columnas_tallos,
    )
    grupos = resumir_grupos(clasificacion)
    incluidos = clasificacion.loc[clasificacion["Incluido_grupo"]]
    tallos_incluidos = incluidos["Tallo"].tolist()
    fallback_global = _probabilidades_globales(
        datos, columna_fecha, tallos_incluidos
    )

    matrices_por_grupo: dict[int, MatricesTransicion] = {}
    detalles: list[pd.DataFrame] = []
    for grupo in grupos.itertuples(index=False):
        duracion = int(grupo.Duracion_dias)
        tallos = incluidos.loc[
            incluidos["Duracion_dias"].eq(duracion), "Tallo"
        ].tolist()
        matriz, detalle = _calcular_matriz_grupo(
            datos,
            columna_fecha,
            tallos,
            duracion,
            fallback_global,
        )
        matrices_por_grupo[duracion] = matriz
        detalles.append(detalle)

    Q = np.zeros((len(ESTADOS), len(ESTADOS)), dtype=float)
    r = np.zeros((len(ESTADOS), 1), dtype=float)
    p = np.zeros((len(ESTADOS), 1), dtype=float)
    pesos = grupos.set_index("Duracion_dias")["Participacion_grupo"]
    for duracion, matriz in matrices_por_grupo.items():
        peso = float(pesos.loc[duracion])
        Q += peso * matriz.Q
        r += peso * matriz.r
        p += peso * matriz.p

    ponderada = MatricesTransicion(Q=Q, r=r, p=p)
    sumas = Q.sum(axis=0) + r.ravel() + p.ravel()
    if np.any(Q < -1e-12) or np.any(r < -1e-12) or np.any(p < -1e-12):
        raise ValueError("La matriz ponderada contiene probabilidades negativas.")
    if not np.allclose(sumas, np.ones(len(ESTADOS)), atol=1e-10):
        raise ValueError(f"La matriz ponderada no suma 1 por columna: {sumas}")

    return ResultadoEstimacion(
        matrices=ponderada,
        matrices_por_grupo=matrices_por_grupo,
        clasificacion_df=clasificacion,
        grupos_df=grupos,
        probabilidades_df=pd.concat(detalles, ignore_index=True),
    )


def construir_potencias_q(
    matriz_q: np.ndarray,
    horizonte: int,
) -> pd.DataFrame:
    """Devuelve Q elevada desde 1 hasta el horizonte en formato largo."""

    filas: list[dict[str, object]] = []
    for exponente in range(1, horizonte + 1):
        potencia = np.linalg.matrix_power(matriz_q, exponente)
        for indice_destino, destino in enumerate(ESTADOS):
            for indice_origen, origen in enumerate(ESTADOS):
                filas.append(
                    {
                        "Exponente_Q": exponente,
                        "Horizonte_corte_dias": exponente + 1,
                        "Estado_origen": origen,
                        "Estado_destino": destino,
                        "Orden_origen": indice_origen + 1,
                        "Orden_destino": indice_destino + 1,
                        "Probabilidad": float(
                            potencia[indice_destino, indice_origen]
                        ),
                    }
                )
    return pd.DataFrame(filas)
