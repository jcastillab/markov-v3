"""Configuración central del modelo multifinca de metodología 3."""

from dataclasses import dataclass
from datetime import date, datetime
from pathlib import Path


ESTADOS = ("RC", "SS", "AP")
SIGUIENTE = {"RC": "SS", "SS": "AP", "AP": "PC"}
FINCAS_PREDETERMINADAS = ("ALMER", "PRADERA", "SANTA HELENA")


@dataclass
class ConfiguracionModelo:
    """Rutas, alcance y horizonte de una ejecución."""

    ruta_fenologia_abril: Path
    ruta_fenologia_julio: Path
    ruta_conteos: Path
    ruta_camas_muestreadas: Path
    ruta_plano_siembra: Path
    ruta_calendario: Path
    ruta_salida: Path
    hoja_fenologia_abril: str = "Abril"
    hoja_fenologia_julio: str = "JULIO"
    fecha_cambio_matriz: date | str = date(2026, 7, 1)
    fincas: tuple[str, ...] = FINCAS_PREDETERMINADAS
    flor: str = "ROSE"
    variedad: str = "FREEDOM"
    horizonte_matriz: int = 20
    ventana_ingresos_semanas: int = 4
    porcentaje_ingreso_inicial: float = 0.20

    def __post_init__(self) -> None:
        self.ruta_fenologia_abril = Path(self.ruta_fenologia_abril)
        self.ruta_fenologia_julio = Path(self.ruta_fenologia_julio)
        self.ruta_conteos = Path(self.ruta_conteos)
        self.ruta_camas_muestreadas = Path(self.ruta_camas_muestreadas)
        self.ruta_plano_siembra = Path(self.ruta_plano_siembra)
        self.ruta_calendario = Path(self.ruta_calendario)
        self.ruta_salida = Path(self.ruta_salida)
        self.hoja_fenologia_abril = str(self.hoja_fenologia_abril).strip()
        self.hoja_fenologia_julio = str(self.hoja_fenologia_julio).strip()
        if isinstance(self.fecha_cambio_matriz, datetime):
            self.fecha_cambio_matriz = self.fecha_cambio_matriz.date()
        elif not isinstance(self.fecha_cambio_matriz, date):
            self.fecha_cambio_matriz = date.fromisoformat(
                str(self.fecha_cambio_matriz).strip()
            )
        self.fincas = tuple(
            str(finca).strip().upper() for finca in self.fincas if str(finca).strip()
        )
        self.flor = str(self.flor).strip().upper()
        self.variedad = str(self.variedad).strip().upper()
        self.horizonte_matriz = int(self.horizonte_matriz)
        self.ventana_ingresos_semanas = int(self.ventana_ingresos_semanas)
        self.porcentaje_ingreso_inicial = float(self.porcentaje_ingreso_inicial)

        if not self.hoja_fenologia_abril or not self.hoja_fenologia_julio:
            raise ValueError("Las hojas de fenología no pueden estar vacías.")
        if not self.fincas:
            raise ValueError("Debe indicar al menos una finca.")
        if not self.flor or not self.variedad:
            raise ValueError("flor y variedad no pueden estar vacías.")
        if self.horizonte_matriz < 1:
            raise ValueError("horizonte_matriz debe ser mayor o igual a 1.")
        if self.ventana_ingresos_semanas < 1:
            raise ValueError(
                "ventana_ingresos_semanas debe ser mayor o igual a 1."
            )
        if self.porcentaje_ingreso_inicial < 0:
            raise ValueError("porcentaje_ingreso_inicial no puede ser negativo.")

    @property
    def ruta_camas(self) -> Path:
        """Alias de compatibilidad para código externo anterior."""

        return self.ruta_camas_muestreadas

    @property
    def ruta_fenologia(self) -> Path:
        """Alias de lectura para integraciones antiguas."""

        return self.ruta_fenologia_abril

    @property
    def hoja_fenologia(self) -> str:
        """Alias de lectura para integraciones antiguas."""

        return self.hoja_fenologia_abril
